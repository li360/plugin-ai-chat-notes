# kmgr-api 接口设计

> 设计来源：[SCENES.md](./SCENES.md) — 场景 → 数据需求 → API
> 设计原则：API 按**实体**颗粒度设计，不绑定 UI 交互场景。方法只增不减，字段只加不改。

---

## 场景→API 映射（验证完整性）

### 场景一：知识库管理

| 场景 | 映射 API |
|------|---------|
| 1.1 初始化知识库 | `kmgr.initialize(params): KnowledgeBase` |
| 1.2 打开已有知识库 | `kmgr.open(path): KnowledgeBase` |
| 1.3 添加本地文件 | `kmgr.addFiles(params): FileInfo[]` |
| 1.4 批量导入目录 | `kmgr.importDirectory(params): ImportResult` |
| 1.5 变更感知（重扫） | `kmgr.rescan(): RescanResult` |
| 1.6 🟡 远程文件夹 | （FileInfo.origin 预留，当前无独立 API） |
| 1.7 🟡 知识库共享 | （不在当前设计范围） |
| 1.8 🟡 备份/恢复 | `kmgr.backup(path)` / `kmgr.restore(path)`（预留签名） |

### 场景二：分类组织

| 场景 | 映射 API |
|------|---------|
| 2.1 查看分类 | `kmgr.listCategories(): Category[]` / `kmgr.getCategoryTree(): CategoryNode[]` |
| 2.2 创建分类 | `kmgr.createCategory(params): Category` |
| 2.3 拖拽移动文件 | `kmgr.updateFile(id, { categoryId })` |
| 2.4 重命名分类 | `kmgr.updateCategory(id, { displayName })` |
| 2.5 删除分类 | `kmgr.deleteCategory(id, mode)` |
| 2.6 拖拽排序 | `kmgr.reorderCategories(items[])` |
| 2.7 导入自动创建分类 | （由 `importDirectory` 内部完成） |
| 2.8 🟡 AI 分类建议 | （AI 插件消费 listCategories/updateFile） |

### 场景三：标签管理

| 场景 | 映射 API |
|------|---------|
| 3.1 查看标签 | `kmgr.listTags(): Tag[]` / `kmgr.getTagTree(): TagNode[]` |
| 3.2 创建标签 | `kmgr.createTag(params): Tag` |
| 3.3 标签层级 | `kmgr.updateTag(id, { parentId })` |
| 3.4 给文件打标签 | `kmgr.setFileTags(fileIds[], tagIds[]): void` |
| 3.5 拆标签 | `kmgr.removeFileTags(fileIds[], tagIds[]): void` |
| 3.6 编辑标签 | `kmgr.updateTag(id, params)` |
| 3.7 删除标签 | `kmgr.deleteTag(id): void` |
| 3.8 🟡 AI 标签建议 | （AI 插件消费 listTags/setFileTags） |

### 场景四：查找知识

| 场景 | 映射 API |
|------|---------|
| 4.1 按分类浏览 | `kmgr.listFiles({ categoryId, page, pageSize, sort })` |
| 4.2 全文搜索 | `kmgr.searchFiles({ query, page })` |
| 4.3 标签筛选 | `kmgr.listFiles({ tags, tagMode })` |
| 4.4 最近文件 | `kmgr.getRecentFiles(limit)` |
| 4.5 按扩展名过滤 | `kmgr.listFiles({ ext })` |
| 4.6 按时间过滤 | `kmgr.listFiles({ dateFrom, dateTo })` |
| 4.7 高级组合查询 | `kmgr.listFiles({ ...all filters })` |
| 4.8 🟡 语义搜索 | （AI 插件消费 searchFiles + embedding） |
| 4.9 🟡 知识图谱 | （预留 FileRelation，当前无 API） |

### 场景五：统计

| 场景 | 映射 API |
|------|---------|
| 5.1 基础总览 | `kmgr.getStats(): Stats` |
| 5.2 分类分布 | `kmgr.getDistribution("category")` |
| 5.3 扩展名分布 | `kmgr.getDistribution("ext")` |
| 5.4 标签统计 | `kmgr.getDistribution("tag")` |
| 5.5 🟡 时间趋势 | `kmgr.getTrend(duration)`（预留） |
| 5.6 🟡 活跃度 | （需操作日志，不在当前范围） |

### 场景六：配置

| 场景 | 映射 API |
|------|---------|
| 6.1 基础配置 | `kmgr.getSetting(key)` / `kmgr.setSetting(key, value)` |
| 6.2 忽略规则 | `kmgr.setSetting("scan.ignorePaths", [...])` |
| 6.3 文件类型 | `kmgr.setSetting("scan.fileExtensions", [...])` |
| 6.4 知识库信息 | `kmgr.getInfo(): KnowledgeBaseInfo` |
| 6.5 🟡 插件管理 | （不在 kmgr-api 范围） |

---

## KmgrApi 接口定义

```ts
interface KmgrApi {
  // ======================== 知识库 ========================

  /** 初始化知识库  [场景 1.1] */
  initialize(params: InitializeParams): Promise<KnowledgeBase>

  /** 打开已有知识库  [场景 1.2] */
  open(path: string): Promise<KnowledgeBase>

  /** 获取当前知识库信息  [场景 6.4] */
  getInfo(): Promise<KnowledgeBaseInfo>

  // ======================== 文件导入 ========================

  /** 添加文件  [场景 1.3] */
  addFiles(params: AddFilesParams): Promise<FileInfo[]>

  /** 批量导入目录  [场景 1.4、2.7] */
  importDirectory(params: ImportDirectoryParams): Promise<ImportResult>

  /** 重扫变更  [场景 1.5] */
  rescan(): Promise<RescanResult>

  // ======================== 文件读写 ========================

  /** 按条件列出文件  [场景 4.1、4.3、4.5、4.6、4.7] */
  listFiles(params: ListFilesParams): Promise<PaginatedResult<FileInfo>>

  /** 搜索文件  [场景 4.2] */
  searchFiles(params: SearchFilesParams): Promise<PaginatedResult<SearchResultItem>>

  /** 获取单个文件  */
  getFile(id: number): Promise<FileInfo | null>

  /** 更新文件  [场景 2.3] */
  updateFile(id: number, patch: UpdateFilePatch): Promise<FileInfo>

  /** 删除文件 */
  removeFiles(ids: number[]): Promise<number>

  /** 最近文件  [场景 4.4] */
  getRecentFiles(limit: number): Promise<FileInfo[]>

  // ======================== 分类 ========================

  /** 平铺列表  [场景 2.1] */
  listCategories(): Promise<Category[]>

  /** 树形结构  [场景 2.1] */
  getCategoryTree(): Promise<CategoryNode[]>

  /** 创建分类  [场景 2.2] */
  createCategory(params: CreateCategoryParams): Promise<Category>

  /** 更新分类  [场景 2.4] */
  updateCategory(id: number, patch: UpdateCategoryPatch): Promise<Category>

  /** 删除分类  [场景 2.5] */
  deleteCategory(id: number, mode: DeleteMode): Promise<void>

  /** 重排分类  [场景 2.6] */
  reorderCategories(items: ReorderItem[]): Promise<void>

  // ======================== 标签 ========================

  /** 平铺列表  [场景 3.1] */
  listTags(): Promise<Tag[]>

  /** 树形结构  [场景 3.1] */
  getTagTree(): Promise<TagNode[]>

  /** 创建标签  [场景 3.2] */
  createTag(params: CreateTagParams): Promise<Tag>

  /** 更新标签  [场景 3.3、3.6] */
  updateTag(id: number, patch: UpdateTagPatch): Promise<Tag>

  /** 删除标签  [场景 3.7] */
  deleteTag(id: number): Promise<void>

  /** 给文件打标签  [场景 3.4] */
  setFileTags(fileIds: number[], tagIds: number[]): Promise<void>

  /** 拆标签  [场景 3.5] */
  removeFileTags(fileIds: number[], tagIds: number[]): Promise<void>

  /** 获取文件的标签列表 */
  getFileTags(fileId: number): Promise<Tag[]>

  // ======================== 统计 ========================

  /** 基础总览  [场景 5.1] */
  getStats(): Promise<Stats>

  /** 分布统计  [场景 5.2、5.3、5.4] */
  getDistribution(type: DistributionType): Promise<Distribution>

  // ======================== 配置 ========================

  /** 获取配置  [场景 6.1] */
  getSetting(key: string): Promise<Setting | null>

  /** 写入配置  [场景 6.1、6.2、6.3] */
  setSetting(key: string, value: unknown): Promise<void>

  /** 列出所有配置 */
  listSettings(): Promise<Setting[]>

  // ======================== 预留（未来） ========================

  /** 🟡 备份知识库  [场景 1.8] */
  backup?(path: string): Promise<void>

  /** 🟡 恢复知识库  [场景 1.8] */
  restore?(path: string): Promise<void>

  /** 🟡 时间趋势  [场景 5.5] */
  getTrend?(duration: "week" | "month" | "quarter" | "year"): Promise<TrendItem[]>
}
```

---

## 类型定义

### 数据模型

```ts
interface KnowledgeBase {
  id: number
  name: string
  path: string
  type: "local"                  // 🟡 预留 "remote"
  ownerId: string | null         // 🟡 个人标识，共享时标识归属
  version: number                // 🟡 版本号，当前默认 1
  sharedAt: string | null        // 🟡 上次共享发布时间
  shareExpiresAt: string | null  // 🟡 共享有效期
  createdAt: string
  updatedAt: string
}

interface KnowledgeBaseInfo {
  id: number
  name: string
  path: string
  type: "local"
  ownerId: string | null
  version: number
  sharedAt: string | null
  shareExpiresAt: string | null
  dbSize: number
  createdAt: string
  updatedAt: string
}

interface FileInfo {
  id: number
  name: string
  path: string
  ext: string
  size: number
  categoryId: number | null
  origin: "local"                // 🟡 预留 "remote"
  validFrom: string | null       // 🟡 知识生效时间
  validUntil: string | null      // 🟡 知识失效时间
  createdAt: string
  modifiedAt: string
  accessedAt: string
}

interface Category {
  id: number
  name: string
  displayName: string
  parentId: number | null
  sortOrder: number
  isSystem: boolean
  canDelete: boolean
  fileCount: number
}

interface CategoryNode {
  id: number
  name: string
  displayName: string
  parentId: number | null
  sortOrder: number
  isSystem: boolean
  canDelete: boolean
  fileCount: number
  children: CategoryNode[]
}

interface Tag {
  id: number
  name: string
  parentId: number | null
  color: string | null
  icon: string | null
  sortOrder: number
  fileCount: number
}

interface TagNode extends Tag {
  children: TagNode[]
}

interface Setting {
  key: string
  value: unknown
  updatedAt: string
}

interface Stats {
  totalFiles: number
  totalCategories: number
  totalTags: number
  totalSize: number
}

interface Distribution {
  type: DistributionType
  items: DistributionItem[]
}

interface DistributionItem {
  key: string
  label: string
  count: number
  pct: number
}

type DistributionType = "category" | "ext" | "tag"

interface TrendItem {
  period: string                // "2026-01", "2026-02", ...
  added: number
  removed: number
  total: number
}
```

### 请求参数

```ts
interface InitializeParams {
  name: string
  path: string
}

interface AddFilesParams {
  files: AddFileItem[]
}

interface AddFileItem {
  path: string                  // 文件绝对路径
  categoryId?: number           // 可选：指定分类
  tags?: number[]               // 可选：指定标签
}

interface ImportDirectoryParams {
  path: string                  // 目录绝对路径
  recursive: boolean            // 是否递归子目录
  createCategories: boolean     // 是否按子目录创建分类层级
  extensions?: string[]         // 限定文件扩展名（白名单）
  ignorePaths?: string[]        // 忽略路径模式
}

interface ImportResult {
  filesAdded: number
  filesSkipped: number
  categoriesCreated: number
  elapsedMs: number
}

interface RescanResult {
  added: FileInfo[]
  modified: FileInfo[]
  removed: number[]             // 被移除的 fileId 列表
}

interface ListFilesParams {
  categoryId?: number
  tags?: number[]
  tagMode?: "and" | "or"        // 默认 "and"
  ext?: string
  dateFrom?: string
  dateTo?: string
  sort?: ListSort
  page?: number                 // 从 1 开始
  pageSize?: number             // 默认 50
}

type ListSort = "name" | "createdAt" | "modifiedAt" | "size" | "ext"

interface SearchFilesParams {
  query: string
  scope?: "name" | "content" | "all"  // 默认 "all"
  page?: number
  pageSize?: number
}

interface SearchResultItem {
  file: FileInfo
  snippet: string               // 匹配的上下文片段（最多 200 字符）
  relevance: number             // 相关性分数
}

interface PaginatedResult<T> {
  items: T[]
  total: number
  page: number
  pageSize: number
}

interface UpdateFilePatch {
  categoryId?: number | null
}

interface CreateCategoryParams {
  name: string
  displayName?: string
  parentId?: number | null
  sortOrder?: number
}

interface UpdateCategoryPatch {
  displayName?: string
  sortOrder?: number
}

type DeleteMode = "detach" | "cascade"
// detach: 文件移到根（categoryId → null）
// cascade: 级联删除文件

interface ReorderItem {
  id: number
  sortOrder: number
}

interface CreateTagParams {
  name: string
  parentId?: number | null
  color?: string
  icon?: string
  sortOrder?: number
}

interface UpdateTagPatch {
  name?: string
  parentId?: number | null
  color?: string | null
  icon?: string | null
  sortOrder?: number
}
```

---

## 方法汇总

| 分组 | 方法数 | 覆盖场景数 |
|------|--------|-----------|
| 知识库 | 3 | 1.1, 1.2, 6.4 |
| 文件导入 | 3 | 1.3, 1.4, 1.5, 2.7 |
| 文件读写 | 5 | 2.3, 4.1~4.7 |
| 分类 | 6 | 2.1~2.6 |
| 标签 | 8 | 3.1~3.7 |
| 统计 | 2 | 5.1~5.4 |
| 配置 | 3 | 6.1~6.3 |
| 预留 | 2 | 1.8, 5.5 |
| **合计** | **32** | **26 🔴 场景全覆盖** |

---

## 与 workspace 的集成约定

```ts
// workspace 持有 kmgr-api 实例，根据 capability 注入
interface WorkspaceContext {
  // ... 现有字段
  kmgr?: KmgrApi  // 仅当插件声明 capabilities: ["kmgr:read"] 或 ["kmgr:write"] 时注入
}

// 插件中
const { kmgr } = useWorkspace()
if (kmgr) {
  const stats = await kmgr.getStats()
}
```

---

## 设计铁律（本文件）

1. API 方法按**实体**命名，不按场景命名（如 `listFiles` 而非 `browseByCategory`）
2. 方法**只增不减**，字段**只加不改**
3. 返回**完整对象**，不因场景裁剪字段
4. 分页列表统一用 `PaginatedResult<T>` 包装
5. 所有方法返回 `Promise`，不假定同步/异步