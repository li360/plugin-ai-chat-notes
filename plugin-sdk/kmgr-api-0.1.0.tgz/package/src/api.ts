/**
 * kmgr-api 核心接口 — 纯类型契约，零运行时依赖
 *
 * 所有方法返回 Promise，通过 Tauri IPC 在 Rust 核心引擎中执行。
 * workspace 根据插件 capabilities 决定是否注入此接口。
 */
import type {
  BacklinkItem,
  Category,
  CategoryNode,
  DeleteMode,
  DirectoryEntry,
  Distribution,
  DistributionType,
  FileInfo,
  FolderInfo,
  FolderType,
  FilePackageResolve,
  FragmentInfo,
  FragmentParam,
  HealthCheckResult,
  ImportResult,
  KnowledgeBase,
  KnowledgeBaseInfo,
  LibraryEntry,
  LibraryInfo,
  LinkGraph,
  LinkRecord,
  PackageInfo,
  PackageScanResult,
  PackageSearchResult,
  PaginatedResult,
  PathClassify,
  PluginData,
  RegisterPackageParams,
  RescanResult,
  ApplyRescanParams,
  SearchResultItem,
  Setting,
  FileGeo,
  FileGeoPoint,
  UpsertFileGeoParams,
  UpsertFileGeoByPathParams,
  Stats,
  Tag,
  TagNode,
  TrendItem,
  SharedFragmentInfo,
  SharedFragmentContent,
  FragmentVersionInfo,
  PackageSharedRef,
  SharedRefParam,
  CreateSharedFragmentParams,
  DeleteSharedFragmentResult,
  SharedResourceInfo,
  PackageResourceRef,
  ResourceRefParam,
  CreateSharedResourceParams,
  DeleteSharedResourceResult,
  ResourceRefInfo,
  CssStyleInfo,
  CssStyleScope,
  SaveCssStyleParams,
  ActiveStyle,
  CssStyleScanResult,
  RelocateOutcome,
  BackupInfo,
  FileBackupInfo,
  FileOpEntry,
  FileVersionInfo,
  FileVersionContent,
  DiffLine,
  RecordFileVersionParams,
  MailFetchResult,
  MailAccount,
  ImapFolderInfo,
  ImapFolderMapping,
} from "./types"
import type {
  AddFilesParams,
  CreateCategoryParams,
  CreateTagParams,
  ImportDirectoryParams,
  InitializeParams,
  ListFilesParams,
  ReorderItem,
  SearchFilesParams,
  UpdateCategoryPatch,
  UpdateFilePatch,
  UpdateTagPatch,
} from "./params"

/** 知识管理 API — 所有方法均通过 Tauri IPC 调用，返回 Promise */
export interface KmgrApi {
  // ======================== 知识库 ========================

  /**
   * 初始化知识库 — 创建新的 SQLite 数据库文件
   *
   * @param params - 知识库名称和存放路径
   * @returns 创建完成的知识库信息，version 初始为 1
   * @scene 1.1
   */
  initialize(params: InitializeParams): Promise<KnowledgeBase>

  /**
   * 打开已有知识库
   *
   * @param path - SQLite 数据库文件所在目录的绝对路径
   * @returns 知识库基本信息
   * @scene 1.2
   */
  open(path: string): Promise<KnowledgeBase>

  /**
   * 获取当前知识库详情（含运行时信息）
   *
   * @returns 知识库信息，含数据库文件大小
   * @scene 6.4
   */
  getInfo(): Promise<KnowledgeBaseInfo>

  // ======================== 库注册表（App 级） ========================

  /**
   * 列出所有已知的库 — 来自 AppData 下的 libraries.json 注册表
   *
   * @returns 库注册表条目列表，按添加时间降序
   */
  listLibraries(): Promise<LibraryEntry[]>

  /**
   * 添加库到注册表 — 创建或打开库时自动调用
   *
   * @param entry - 库名称、路径、类型
   */
  addLibrary(entry: { name: string; path: string; type: "local" }): Promise<void>

  /**
   * 从注册表中移除库 — 不删除实际数据库文件
   *
   * @param path - 库路径
   */
  removeLibrary(path: string): Promise<void>

  /**
   * 查询库详情 — 组合文件系统信息和注册表信息
   *
   * 用于在 UI 中展示库的数据库文件路径、大小、添加时间等。
   * 不依赖当前已打开的库，可查询任意路径。
   *
   * @param path - 库根目录路径
   * @returns 库信息（含 dbPath、dbSize、addedAt 等）
   */
  getLibraryInfo(path: string): Promise<LibraryInfo>

  /**
   * 获取应用数据目录路径 — 用于在「关于」页展示配置文件位置
   *
   * AppData 目录下包含 libraries.json（库注册表）、shortcuts.json（快捷键配置）等。
   *
   * @returns AppData 目录绝对路径
   */
  getAppDataDir(): Promise<string>

  /**
   * 获取应用版本号 — 用于在「关于」页展示
   *
   * @returns 应用版本号（如 "0.1.0"）
   */
  getAppVersion(): Promise<string>

  /**
   * 用系统默认关联程序打开当前库的 SQLite 数据库文件
   *
   * 调用系统 shell 以默认 .db 关联程序打开（如 DB Browser for SQLite）。
   * 用于「库信息」Dialog 中的 SQLite 查看入口。若系统未安装关联程序，会返回错误。
   */
  openDbExternal(): Promise<void>

  // ======================== 库内文件夹 ========================

  /**
   * 列出当前知识库的所有文件夹
   *
   * @returns 按 sortOrder 排序的文件夹列表
   */
  listFolders(): Promise<FolderInfo[]>

  /**
   * 分类路径归属 — 「库内」判定（0.26 新理念，2026-08-08）
   *
   * 库内 = 在任一注册文件夹内（含收件箱），不含库根。前端所有「库内/库外」
   * 判断统一调用本方法，禁止用库根物理前缀自行匹配（注册文件夹可位于库根外）。
   *
   * @param path - 待判定的绝对路径
   * @returns { inKb, folderId, insideKbRoot }
   */
  classifyPath(path: string): Promise<PathClassify>

  /**
   * 创建文件夹
   *
   * @param params - 文件夹名称、路径、类型、排序
   * @returns 创建完成的文件夹信息
   */
  createFolder(params: { name: string; path: string; folderType?: FolderType; sortOrder?: number }): Promise<FolderInfo>

  /**
   * 更新文件夹属性
   *
   * @param id - 文件夹 ID
   * @param patch - 需要修改的字段
   * @returns 更新后的文件夹信息
   */
  updateFolder(id: number, patch: { name?: string; path?: string; folderType?: FolderType; sortOrder?: number }): Promise<FolderInfo>

  /**
   * 删除文件夹
   *
   * @param id - 文件夹 ID
   */
  deleteFolder(id: number): Promise<void>

  /**
   * 移动文件夹（应用内移动）— 物理移动 + 事务化 DB 更新（v7 文件夹自治）
   *
   * 身份校验通过后移动磁盘目录并更新 DB 路径；失败时自动回移。
   *
   * @param folderId - 文件夹 ID
   * @param newPath - 目标路径（绝对路径）
   * @returns 移动后的文件夹信息
   */
  moveFolder(folderId: number, newPath: string): Promise<FolderInfo>

  /**
   * 重新定位文件夹（应用外移动后）— 仅改 DB 指针，身份校验 + 事务化更新（S3）
   *
   * 身份校验失败（目标目录无身份 / 身份不符）时返回对应的 outcome 分支，
   * 由调用方弹窗确认后带 `force: true` 重试；强制时以磁盘身份为准更新 DB。
   *
   * @param folderId - 文件夹 ID
   * @param newPath - 新位置绝对路径
   * @param force - 是否强制（跳过身份校验，以磁盘身份为准）
   */
  relocateFolder(folderId: number, newPath: string, force?: boolean): Promise<RelocateOutcome>

  /**
   * 统计文件夹登记的包数量（relocate 强制确认弹窗显示「N 个包」）
   *
   * 同时统计 v7 前的旧数据（folder_id 为空、dir_path 前缀匹配）。
   *
   * @param folderId - 文件夹 ID
   */
  countFolderPackages(folderId: number): Promise<number>

  /**
   * 为缺失身份的文件夹补 `.gewu/folder.json` 并回填 folder_uuid（S4 迁移工具）
   *
   * 遍历 folder_uuid 为空且磁盘目录存在的注册文件夹，生成身份文件并回填 DB。
   *
   * @returns 补全身份的文件夹数量
   */
  ensureFolderIdentities(): Promise<number>

  /**
   * 列出库根直属包（S4 库根纯索引清单视图）— `folder_id IS NULL` 的包
   *
   * 库根直属包是历史"移入知识库"落到库根的 .pack，不属于任何注册文件夹。
   */
  listRootPackages(): Promise<PackageInfo[]>

  /**
   * 备份数据库到库根 `.gewu/backup-<时间戳>/`（S4 迁移工具前置保护）
   *
   * 使用 SQLite VACUUM INTO 生成一致性快照（含 WAL 数据）。
   *
   * @returns 备份目录绝对路径
   */
  backupDatabase(): Promise<string>

  /**
   * 列出库根 `.gewu/backup-*` 备份目录（备份中心数据源，按时间倒序）
   *
   * @returns 备份列表（含目录名、路径、创建时间、大小）；从未备份时为空数组
   */
  listBackups(): Promise<BackupInfo[]>

  /**
   * 删除保护 — 把文件/目录移入应用内回收站（.gewu/trash/）并记录
   *
   * 相比系统回收站：留档位于库内 .gewu/trash/，受保留期管理（默认 30 天），
   * 可在备份中心「文件回收站」中恢复或永久删除。与 trashPath（系统回收站）二选一。
   *
   * @param path - 待删除的文件或目录绝对路径
   * @returns 创建的留档记录
   */
  trashToLibrary(path: string): Promise<FileBackupInfo>

  /**
   * 修改保护 — 覆盖保存前把文本类旧文件复制到 .gewu/versions/ 并记录
   *
   * 由 Rust 端 create_file 覆盖写入时自动调用，前端通常无需手动触发。
   * 非文本类或文件不存在时返回 null（跳过留档）。
   *
   * @param path - 即将被覆盖的文件绝对路径
   * @returns 创建的留档记录；跳过（新建/非文本）时为 null
   */
  backupFileVersion(path: string): Promise<FileBackupInfo | null>

  /**
   * 列出文件级留档记录（备份中心「文件回收站」数据源，按创建时间倒序）
   *
   * @param kind - 过滤类型："trash"（回收站）| "version"（版本历史）| 省略/undefined=全部
   * @returns 留档记录列表
   */
  listFileBackups(kind?: "trash" | "version" | null): Promise<FileBackupInfo[]>

  /**
   * 恢复文件留档 — 备份中心「文件回收站」还原
   *
   * - trash（回收站）：把留档移回原路径（原位置冲突时先保护性移动，原路径父目录自动重建）；恢复后记录作废删除
   * - version（版本历史）：把留档内容写回覆盖当前文件；历史留档文件保留，可再次回滚
   *
   * @param id - 留档记录 ID
   */
  restoreFileBackup(id: number): Promise<void>

  /**
   * 永久删除文件留档 — 删除留档磁盘文件 + 数据库记录（不可撤销）
   *
   * @param id - 留档记录 ID
   */
  deleteFileBackup(id: number): Promise<void>

  /**
   * 清理过期文件留档（应用启动时自动调用，也可手动触发）
   *
   * 删除所有 expiresAt 已到期的留档（磁盘 + 记录）。
   *
   * @returns 清理的留档条数
   */
  cleanupExpiredBackups(): Promise<number>

  /**
   * 读取文件操作日志（「设置 → 日志 → 文件操作」数据源）
   *
   * 读取 AppData/logs/file-ops.log（含轮转 .1/.2），按时间倒序返回。
   * 所有磁盘操作（创建/重命名/删除/复制/移动/回收站）均会记录；
   * 备份操作（backup_db）会记录备份路径，便于用户据此找回文件。
   *
   * @param filter - 过滤条件（可选）：op 按操作类型精确过滤、keyword 模糊匹配、limit 条数上限
   * @returns 日志条目列表（最新在前）
   */
  readFileOpsLog(filter?: { op?: string; keyword?: string; limit?: number }): Promise<FileOpEntry[]>

  /**
   * 批量调整文件夹排序
   *
   * @param items - 需要调整的文件夹 { id, sortOrder }
   */
  reorderFolders(items: { id: number; sortOrder: number }[]): Promise<void>

  // ======================== 文件系统浏览 ========================

  /**
   * 列出目录内容
   *
   * @param path - 目录绝对路径
   * @param recursive - 是否递归列出所有子目录内容（默认 false）
   * @returns 目录下的文件和子目录列表，目录在前、文件在后，按名称排序
   */
  listDirectory(path: string, recursive?: boolean): Promise<DirectoryEntry[]>

  /**
   * 在磁盘上创建文件
   *
   * @param path - 文件完整路径
   * @param content - 可选的初始文件内容
   */
  createFile(path: string, content?: string): Promise<void>

  /**
   * 读取文本文件全文 — 通用文本读，直接对应 Tauri `read_text_file`
   *
   * Rust 端按 UTF-8 → GBK → UTF-8 lossy 顺序解码（兼容中文 Windows 常见编码）。
   * 与 createFile 的区别：本方法是「读取已存在文件」的只读入口，不涉及 DB/时间线。
   *
   * @param path - 文件绝对路径
   * @returns 文件文本内容
   */
  readTextFile(path: string): Promise<string>

  /**
   * 读取文件二进制内容 — 返回 Uint8Array，用于图片等非文本文件。
   *
   * 底层调用 Rust `read_file_bytes`（返回 base64），前端解码为字节数组。
   *
   * @param path - 文件绝对路径
   * @returns 文件二进制内容
   */
  readFileBytes(path: string): Promise<Uint8Array>

  /**
   * 写入文本文件全文 — 通用文本写，直接对应 Tauri `write_text_file`
   *
   * 自动递归创建父目录；对已入库的文本类文件，Rust 端会 best-effort 记录文件时间线版本。
   * 用于不经 createFile 语义的直接覆写场景（如改写 .packmeta.json）。
   *
   * @param path - 文件绝对路径
   * @param content - 要写入的完整文本内容（整体覆盖）
   */
  writeTextFile(path: string, content: string): Promise<void>

  // ======================== 文件时间线（版本历史 + diff + 恢复） ========================

  /**
   * 记录文件版本 — 保存后写入新内容，按 content_hash 去重
   *
   * 内容与最新版本相同时跳过（返回 null）。触发点见 file-timeline-spec.md §5.1。
   *
   * @param params - 记录入参（fileId/filePath/content）
   * @returns 新增版本信息；内容未变返回 null
   */
  recordFileVersion(params: RecordFileVersionParams): Promise<FileVersionInfo | null>

  /**
   * 列出文件版本历史 — 按 version DESC 倒序
   *
   * @param fileId - 文件 ID（files.id）
   * @returns 版本列表（不含 content，含 lineCount/source 摘要）
   */
  listFileVersions(fileId: number): Promise<FileVersionInfo[]>

  /**
   * 取指定版本内容
   *
   * @param fileId - 文件 ID
   * @param version - 版本号（必须存在，否则报错）
   * @returns 版本内容（含 meta 信息）
   */
  getFileVersion(fileId: number, version: number): Promise<FileVersionContent>

  /**
   * 当前内容 vs 历史版本的行级 diff（红删绿增）
   *
   * @param fileId - 文件 ID
   * @param version - 历史版本号（diff 的 old 侧）
   * @param currentContent - 当前内容（编辑器内存未落盘内容，自动时间线下用）；省略时读磁盘当前内容（new 侧）
   * @returns diff 行列表（type=add/delete/context，含行号）
   */
  getFileVersionDiff(
    fileId: number,
    version: number,
    currentContent?: string,
  ): Promise<DiffLine[]>

  /**
   * 恢复到指定版本 — 写回文件 + 新增 source='restore' 记录
   *
   * 恢复后可追溯（restoredFromVersion）且可再次回滚；恢复后列表会刷新。
   *
   * @param fileId - 文件 ID
   * @param version - 目标版本号
   * @returns 恢复产生的新版本信息
   */
  restoreFileVersion(fileId: number, version: number): Promise<FileVersionInfo>

  /**
   * 删除指定版本（T12）— 最新版本拒绝删除；删除后版本号保留空洞不重排
   *
   * @param fileId - 文件 ID
   * @param version - 要删除的版本号（不得为最新版本）
   */
  deleteFileVersion(fileId: number, version: number): Promise<void>

  /**
   * 批量保留最近 N 个版本，删除更早的（T12）
   *
   * @param fileId - 文件 ID
   * @param keepLatest - 保留的最近版本个数（至少 1，最新版本永远保留）
   * @returns 删除的版本条数
   */
  pruneFileVersions(fileId: number, keepLatest: number): Promise<number>

  /**
   * 全库批量清理（T14）— 每个仍存在的文件保留最近 N 个版本，删除更早的（孤儿版本不动）
   *
   * @param keepLatest - 每个文件保留的最近版本个数（至少 1）
   * @returns 删除的版本总条数
   */
  pruneAllFileVersions(keepLatest: number): Promise<number>

  /**
   * 在磁盘上创建目录（递归创建父目录）
   *
   * @param path - 目录完整路径
   */
  createDirectory(path: string): Promise<void>

  /**
   * 在磁盘上重命名文件
   *
   * @param oldPath - 原文件路径
   * @param newPath - 新文件路径
   */
  renameFile(oldPath: string, newPath: string): Promise<void>

  /**
   * 在磁盘上删除文件
   *
   * @param path - 文件路径
   */
  deleteFile(path: string): Promise<void>

  /**
   * 复制文件或目录（支持递归复制目录）— 文件操作扩展
   *
   * @param src - 源路径
   * @param dest - 目标路径
   * @param overwrite - 是否覆盖已存在目标，默认 false
   */
  copyPath(src: string, dest: string, overwrite?: boolean): Promise<void>

  /**
   * 移动文件或目录（支持跨磁盘）— 文件操作扩展
   *
   * @param src - 源路径
   * @param dest - 目标路径
   */
  movePath(src: string, dest: string): Promise<void>

  /**
   * 删除文件或目录（目录递归删除）— 文件操作扩展
   *
   * @param path - 路径
   */
  deletePath(path: string): Promise<void>

  /**
   * 移到回收站（可恢复）— 文件操作扩展
   * 与 deletePath 区别：不永久删除，用户可从回收站还原
   *
   * @param path - 路径
   */
  trashPath(path: string): Promise<void>

  /**
   * 目录移动/重命名后批量同步数据库索引路径 — 文件操作扩展
   *
   * @param oldPrefix - 原目录路径
   * @param newPrefix - 新目录路径
   * @returns 受影响的记录数
   */
  syncPathsAfterMove(oldPrefix: string, newPrefix: string): Promise<number>

  /**
   * 按文件系统路径查找 kmgr 文件记录
   *
   * @param path - 文件系统绝对路径
   * @returns 文件记录，未索引则 null
   */
  getFileByPath(path: string): Promise<FileInfo | null>

  // ======================== 文件导入 ========================

  /**
   * 添加文件 — 索引单个或多个文件到知识库
   *
   * @param params - 待添加的文件路径列表，可选分类和标签
   * @returns 成功添加的文件信息列表
   * @scene 1.3
   */
  addFiles(params: AddFilesParams): Promise<FileInfo[]>

  /**
   * 批量导入目录 — 递归扫描并索引整个目录树
   *
   * @param params - 目录路径、递归选项、扩展名白名单等
   * @returns 导入统计（新增/跳过/分类数/耗时）
   * @scene 1.4, 2.7
   */
  importDirectory(params: ImportDirectoryParams): Promise<ImportResult>

  /**
   * 重扫变更 — 对比文件系统与数据库，检测文件的增/改/删
   *
   * @returns 新增、修改、删除三列表
   * @scene 1.5
   */
  rescan(): Promise<RescanResult>

  /**
   * 检测文件系统与数据库差异 — 只读操作，不修改数据库
   *
   * 用 size + mtime 双重判断文件是否 modified。
   * 返回结果后由前端展示 Dialog，用户确认后调用 `applyRescan` 应用修复。
   *
   * @returns 新增、修改、删除三列表（未实际修改数据库）
   */
  detectChanges(): Promise<RescanResult>

  /**
   * 应用重扫结果 — 根据 detectChanges 的检测结果批量修改数据库
   *
   * - added：INSERT 新文件
   * - modified：UPDATE size + modified_at
   * - removed：DELETE files + file_tags 记录
   *
   * @param params - 从 detectChanges 结果中提取的路径和 ID
   * @returns 应用后的最终结果（含已分配的 id）
   */
  applyRescan(params: ApplyRescanParams): Promise<RescanResult>

  // ======================== 文件读写 ========================

  /**
   * 按条件分页列出文件
   *
   * @param params - 支持分类、标签、扩展名、时间范围的组合筛选
   * @returns 分页结果，默认 pageSize=50
   * @scene 4.1, 4.3, 4.5, 4.6, 4.7
   */
  listFiles(params: ListFilesParams): Promise<PaginatedResult<FileInfo>>

  /**
   * 全文搜索文件
   *
   * @param params - 搜索关键词、范围（文件名/内容/全部）
   * @returns 命中的文件及匹配片段，按相关性排序
   * @scene 4.2
   */
  searchFiles(params: SearchFilesParams): Promise<SearchResultItem[]>

  /**
   * 获取单个文件详情
   *
   * @param id - 文件 ID
   * @returns 文件信息，不存在则 null
   */
  getFile(id: number): Promise<FileInfo | null>

  /**
   * 更新文件属性
   *
   * @param id - 文件 ID
   * @param patch - 需要修改的字段（当前仅支持移动分类）
   * @returns 更新后的文件信息
   * @scene 2.3
   */
  updateFile(id: number, patch: UpdateFilePatch): Promise<FileInfo>

  /**
   * 批量删除文件
   *
   * @param ids - 文件 ID 列表
   * @returns 实际删除的文件数
   */
  removeFiles(ids: number[]): Promise<number>

  /**
   * 获取最近打开/操作过的文件
   *
   * @param limit - 返回条数上限
   * @returns 按 accessedAt 降序排列的文件列表
   * @scene 4.4
   */
  getRecentFiles(limit: number): Promise<FileInfo[]>

  // ======================== 分类 ========================

  /**
   * 获取全部分类的平铺列表
   *
   * @returns 按 sortOrder 排序的平铺列表
   * @scene 2.1
   */
  listCategories(): Promise<Category[]>

  /**
   * 获取分类树形结构
   *
   * @returns 递归嵌套的分类树，根节点 parentId 为 null
   * @scene 2.1
   */
  getCategoryTree(): Promise<CategoryNode[]>

  /**
   * 创建分类
   *
   * @param params - 分类名称、父分类、排序权重
   * @returns 创建完成的分类信息
   * @scene 2.2
   */
  createCategory(params: CreateCategoryParams): Promise<Category>

  /**
   * 更新分类属性
   *
   * @param id - 分类 ID
   * @param patch - 需要修改的字段（名称、排序）
   * @returns 更新后的分类信息
   * @scene 2.4
   */
  updateCategory(id: number, patch: UpdateCategoryPatch): Promise<Category>

  /**
   * 删除分类
   *
   * @param id - 分类 ID
   * @param mode - detach=文件移到根，cascade=级联删除文件
   * @scene 2.5
   */
  deleteCategory(id: number, mode: DeleteMode): Promise<void>

  /**
   * 拖拽重排分类顺序
   *
   * @param items - 需要调整的分类 ID 和新 sortOrder 值
   * @scene 2.6
   */
  reorderCategories(items: ReorderItem[]): Promise<void>

  // ======================== 标签 ========================

  /**
   * 获取全部标签的平铺列表
   *
   * @returns 按 sortOrder 排序的平铺列表
   * @scene 3.1
   */
  listTags(): Promise<Tag[]>

  /**
   * 获取标签树形结构
   *
   * @returns 递归嵌套的标签树，根节点 parentId 为 null
   * @scene 3.1
   */
  getTagTree(): Promise<TagNode[]>

  /**
   * 创建标签
   *
   * @param params - 标签名、父标签、颜色、图标等
   * @returns 创建完成的标签信息
   * @scene 3.2
   */
  createTag(params: CreateTagParams): Promise<Tag>

  /**
   * 更新标签属性
   *
   * @param id - 标签 ID
   * @param patch - 需要修改的字段，传 null 可清除可选字段
   * @returns 更新后的标签信息
   * @scene 3.3, 3.6
   */
  updateTag(id: number, patch: UpdateTagPatch): Promise<Tag>

  /**
   * 删除标签 — 同时解除所有文件的关联
   *
   * @param id - 标签 ID
   * @scene 3.7
   */
  deleteTag(id: number): Promise<void>

  /**
   * 给文件打标签 — 批量关联文件和标签
   *
   * @param fileIds - 文件 ID 列表
   * @param tagIds - 标签 ID 列表
   * @scene 3.4
   */
  setFileTags(fileIds: number[], tagIds: number[]): Promise<void>

  /**
   * 拆标签 — 批量解除文件和标签的关联（不删除标签本身）
   *
   * @param fileIds - 文件 ID 列表
   * @param tagIds - 标签 ID 列表
   * @scene 3.5
   */
  removeFileTags(fileIds: number[], tagIds: number[]): Promise<void>

  /**
   * 获取某个文件关联的所有标签
   *
   * @param fileId - 文件 ID
   * @returns 与该文件关联的标签列表
   */
  getFileTags(fileId: number): Promise<Tag[]>

  // ======================== 统计 ========================

  /**
   * 获取知识库基础统计摘要
   *
   * @returns 文件/分类/标签总数及文件总大小
   * @scene 5.1
   */
  getStats(): Promise<Stats>

  /**
   * 获取按维度分组的分布统计
   *
   * @param type - 统计维度：category=按分类，ext=按扩展名，tag=按标签
   * @returns 分布项列表，按 count 降序
   * @scene 5.2, 5.3, 5.4
   */
  getDistribution(type: DistributionType): Promise<Distribution>

  // ======================== 配置 ========================

  /**
   * 读取单个配置项
   *
   * @param key - 配置键，如 "scan.ignorePaths"
   * @returns 配置项，不存在则 null
   * @scene 6.1
   */
  getSetting(key: string): Promise<Setting | null>

  /**
   * 写入配置项 — 不存在则创建，存在则更新
   *
   * @param key - 配置键
   * @param value - 配置值，JSON 可序列化
   * @scene 6.1, 6.2, 6.3
   */
  setSetting(key: string, value: unknown): Promise<void>

  /**
   * 列出所有配置项
   *
   * @returns 所有配置的键值列表
   */
  listSettings(): Promise<Setting[]>

  // ======================== 文件地理信息（地图模块） ========================

  /** 写入或更新文件地理坐标（EXIF 解析回写 / 手动标记） */
  upsertFileGeo(params: UpsertFileGeoParams): Promise<void>

  /** 按文件路径写入地理坐标（EXIF 懒解析主入口）；文件未入库时返回 false */
  upsertFileGeoByPath(params: UpsertFileGeoByPathParams): Promise<boolean>

  /** 查询单个文件的地理信息 — 无记录返回 null */
  getFileGeo(fileId: number): Promise<FileGeo | null>

  /** 列出全部地理点位（JOIN files）— 地图视图打点数据源 */
  listFileGeoPoints(): Promise<FileGeoPoint[]>

  /** 删除单个文件的地理信息 */
  deleteFileGeo(fileId: number): Promise<void>

  // ======================== 插件数据 ========================

  /**
   * 读取插件数据项 — 不存在返回 null
   *
   * @param pluginId - 插件 ID（对应 PluginManifest.id）
   * @param key - 数据键
   * @returns 数据项，不存在则 null
   */
  readPluginData(pluginId: string, key: string): Promise<PluginData | null>

  /**
   * 写入插件数据项 — 不存在则创建，存在则更新
   *
   * @param pluginId - 插件 ID
   * @param key - 数据键
   * @param value - 数据值，JSON 可序列化
   */
  writePluginData(pluginId: string, key: string, value: unknown): Promise<void>

  /**
   * 列出指定插件的所有数据项 — 按 key 排序
   *
   * @param pluginId - 插件 ID
   * @returns 该插件的所有数据项列表
   */
  listPluginData(pluginId: string): Promise<PluginData[]>

  /**
   * 删除指定插件的某个数据项 — 不存在视为成功
   *
   * @param pluginId - 插件 ID
   * @param key - 数据键
   */
  deletePluginData(pluginId: string, key: string): Promise<void>

  // ======================== 包与双链（Phase 1） ========================

  /**
   * 按包名模糊搜索 — 自动绑定当前库
   *
   * @param query - 搜索关键词（LIKE 匹配 title）
   * @returns 匹配的包列表（最多 50 条），按 title 升序
   */
  searchPackages(query: string): Promise<PackageSearchResult[]>

  /**
   * 按包名精确查找 — 同名时返回第一个（D1 决策）
   *
   * @param title - 包名（精确匹配）
   * @returns 包信息，不存在则 null
   */
  getPackageByTitle(title: string): Promise<PackageInfo | null>

  /**
   * 按目录路径查找包
   *
   * @param dirPath - 包目录相对库根的路径
   * @returns 包信息，不存在则 null
   */
  getPackageByPath(dirPath: string): Promise<PackageInfo | null>

  /**
   * 按绝对路径查找包（v7 语义，0.26 新理念）— 移动/删除 .pack 前定位 uuid 用
   *
   * 内部先做「库内」判定（classify_path），再按归属（folder_id 或库根）
   * 构造对应相对路径精确匹配，可定位位于注册文件夹内（dir_path 相对文件夹）的包。
   *
   * @param absPath - 包目录的绝对路径
   * @returns 包信息，不存在则 null
   */
  getPackageByAbsPath(absPath: string): Promise<PackageInfo | null>

  /**
   * 计算包在磁盘上的绝对路径（v7 语义）— 前端「库根 + dirPath」手工拼接的统一替代入口。
   *
   * folderId 有值时 = 所属文件夹.path + dirPath；否则 = 库根 + dirPath。
   * 注册文件夹内包的 dirPath 相对所属文件夹，按库根拼接会得到错误路径
   * （片段/样式/导出读取失败）。包不存在返回 null。
   *
   * @param uuid - 包 uuid
   * @returns 包目录绝对路径，包不存在则 null
   */
  getPackageAbsPath(uuid: string): Promise<string | null>

  /**
   * 注册或更新包 — 库扫描时调用（D6 决策）
   *
   * uuid 已存在则刷新 title/dirPath/mainFile/updated_at，保留 created_at。
   * library_id 自动从当前库注入。
   *
   * @param params - 包 UUID、标题、目录路径、主文件
   * @returns 注册完成的包信息
   */
  registerPackage(params: RegisterPackageParams): Promise<PackageInfo>

  /**
   * 按绝对路径注册包 — 自动判定「库内」归属（0.26 新理念，2026-08-08）
   *
   * `params.dirPath` 传包目录的**绝对路径**。Rust 端内部：
   * - classify_path 判定归属（任一注册文件夹内 → folder_id；库根物理内 → 无）
   * - 校验包必须位于库内，否则报错
   * - 计算相对 dir_path（folder_id 有值 → 相对所属文件夹；否则 → 相对库根）
   * - 写入 folder_id（与 scan 流程一致）
   *
   * 替代前端「相对库根前缀手算 rel」的旧逻辑（新建/重命名 .pack 用，
   * 旧逻辑在库根外注册文件夹内会把 dir_path 算成绝对路径写坏）。
   *
   * @param params - 包 UUID、标题、目录绝对路径、主文件
   * @returns 注册完成的包信息
   */
  registerPackageByAbs(params: RegisterPackageParams): Promise<PackageInfo>

  /**
   * 移动包 — 按「库内」定义更新 dir_path + folder_id 归属（0.26 新理念）
   *
   * `newPath` 为包的**新绝对路径**，Rust 端自动判定归属并计算相对路径：
   * - 任一注册文件夹内 → dir_path 相对该文件夹 + folder_id 归属
   * - 库根物理内（迁移期直属包）→ dir_path 相对库根 + folder_id 清空
   * - 库外 → 报错
   *
   * 替代前端手算相对路径后调用 updatePackagePath 的旧逻辑
   * （旧逻辑只认库根前缀，目标在库根外注册文件夹时会写坏 dir_path）。
   *
   * @param uuid - 包 UUID
   * @param newPath - 包的新绝对路径
   */
  movePackage(uuid: string, newPath: string): Promise<PackageInfo>

  /**
   * 删除包 — 删除包记录 + 清理链接
   *
   * source 链接删除（源包没了，链接无意义）；
   * target 链接降级（target_package_uuid 置 NULL, resolved=0, R8 优雅降级）。
   *
   * @param uuid - 包 UUID
   */
  deletePackage(uuid: string): Promise<void>

  /**
   * 库健康检查 — 只读检测，列出所有问题项
   *
   * 检测项：未注册包、已删除包、路径不一致、未解析双链、主文件缺失。
   * 修复由前端组合调用已有 API（scanPackages / deletePackage / movePackage / resolvePendingLinks）。
   *
   * @returns 健康检查结果
   */
  healthCheck(): Promise<HealthCheckResult>

  /**
   * 同步源包的所有双链 — 事务原子替换
   *
   * 先删除源包的所有旧链接，再批量插入新链接。
   * 每条链接插入时尝试解析 targetPackageUuid（按 targetName 精确匹配同库包）。
   * 解析成功 resolved=true，否则 resolved=false（D2 红色虚线 + tooltip）。
   *
   * @param sourceUuid - 源包 UUID
   * @param links - 链接记录列表
   */
  syncLinks(sourceUuid: string, links: LinkRecord[]): Promise<void>

  /**
   * 查询目标包的所有反向链接
   *
   * JOIN packages 表获取源包标题；源包已删除时 sourceTitle 为空字符串（R8 优雅降级）。
   *
   * @param targetUuid - 目标包 UUID
   * @returns 反向链接列表，按 created_at 降序
   */
  getBacklinks(targetUuid: string): Promise<BacklinkItem[]>

  /**
   * 重新解析未解析的链接 — 包重命名后调用（D3 决策）
   *
   * 找出当前库内 resolved=false 的链接，按 targetName 重新匹配 packages 表。
   *
   * @returns 成功重解析的链接数量
   */
  resolvePendingLinks(): Promise<number>

  /**
   * 导出全库知识图谱 — 全部包节点 + 已解析双链 + 悬挂链接
   *
   * 一次性返回图谱渲染所需数据（知识组织「图谱」页签用），
   * 边按「源包→目标包」去重，悬挂链接按「源包 + 目标名」去重。
   *
   * @returns 图谱数据（节点 / 已解析边 / 悬挂链接）
   */
  getLinkGraph(): Promise<LinkGraph>

  /**
   * 扫描库目录，全量注册 .pack 包到数据库（D6 决策）
   *
   * 递归遍历库根目录，对每个 `.pack` 后缀文件夹读取 `.packmeta.json` 并注册。
   * uuid 已存在则更新（自动处理 R9 路径恢复），`.packmeta.json` 无效则跳过。
   *
   * @returns 扫描结果统计（新注册 / 更新 / 跳过 / 耗时）
   */
  scanPackages(): Promise<PackageScanResult>

  /**
   * 扫描指定目录下的 .pack 包并注册 — 限定目录的局部扫描
   *
   * 仅遍历 `dirPath` 指定的目录子树，适用于 file-list 右键文件夹快速注册。
   *
   * @param dirPath - 相对库根的目录路径
   * @returns 扫描结果统计（新注册 / 更新 / 跳过 / 耗时）
   */
  scanPackagesInDir(dirPath: string): Promise<PackageScanResult>

  /**
   * 由绝对文件路径反查所属包 — 保存时确定 syncLinks 的 sourceUuid
   *
   * @param filePath - 文件绝对路径
   * @returns 包信息 + 文件相对包目录的路径；不在包内时返回 null
   */
  resolveFilePackage(filePath: string): Promise<FilePackageResolve | null>

  // ======================== 包片段元数据（P1-5.0 多片段拼接编辑） ========================

  /**
   * 列出包的所有片段 — 按 sortOrder 升序
   *
   * 空列表表示该包尚未同步片段元数据（旧文件或 fragments 字段缺失）。
   * 前端拼接展示时调用以获取片段顺序。
   *
   * @param packageUuid - 包 UUID
   * @returns 片段列表（按 sortOrder 升序）
   */
  listPackageFragments(packageUuid: string): Promise<FragmentInfo[]>

  /**
   * 设置包的片段 — 同步式全量替换（事务原子性）
   *
   * 先删除该包的所有片段记录，再按数组顺序批量插入（sortOrder 从 0 递增）。
   * 调用方不需要传 sortOrder — 由本方法按数组顺序自动填充。
   *
   * 使用场景：
   * - 用户在片段管理 UI 中增删/重排片段后保存
   * - 编辑 .packmeta.json 后同步到 DB
   *
   * @param packageUuid - 包 UUID
   * @param fragments - 片段参数列表（按目标顺序排列）
   */
  setPackageFragments(packageUuid: string, fragments: FragmentParam[]): Promise<void>

  /**
   * 调整包片段顺序 — 按 orderedIds 顺序更新 sortOrder
   *
   * 用户拖拽调整片段顺序后调用。orderedIds 中的 fragmentId 必须已存在于该包，
   * 不存在则整事务回滚，返回 Validation 错误。
   *
   * @param packageUuid - 包 UUID
   * @param orderedIds - 按新顺序排列的 fragmentId 列表（必须包含该包所有片段）
   */
  reorderPackageFragments(packageUuid: string, orderedIds: string[]): Promise<void>

  // ======================== 共享片段（P0-2） ========================

  /**
   * 创建共享片段 — 新建逻辑实体 + version 1
   *
   * fragmentId 由调用方生成（`crypto.randomUUID()`），全局唯一。
   * content 的 SHA-256 哈希由 Rust 内部计算，调用方不感知 hash。
   *
   * @param params - fragmentId、初始内容、显示名
   * @returns 创建完成的片段信息（currentVersion=1）
   */
  createSharedFragment(params: CreateSharedFragmentParams): Promise<SharedFragmentInfo>

  /**
   * 更新共享片段内容 — 新增版本行，currentVersion 递增
   *
   * 旧版本保留（不可变），支持 rollback。内容寻址：相同内容复用同一 version 行。
   *
   * @param fragmentId - 片段逻辑 ID
   * @param newContent - 新内容
   * @returns 更新后的片段信息（currentVersion 递增）
   */
  updateSharedFragment(fragmentId: string, newContent: string): Promise<SharedFragmentInfo>

  /**
   * 获取共享片段内容 — 取 currentVersion 或指定版本
   *
   * @param fragmentId - 片段逻辑 ID
   * @param version - 可选版本号；不传取 currentVersion，传则取指定版本
   * @returns 片段内容（含 version/contentHash/content），不存在返回 null
   */
  getSharedFragment(fragmentId: string, version?: number | null): Promise<SharedFragmentContent | null>

  /**
   * 列出当前库的所有共享片段 — 按 updatedAt 降序
   *
   * @returns 片段列表（不含 content，仅逻辑信息）
   */
  listSharedFragments(): Promise<SharedFragmentInfo[]>

  /**
   * 列出片段的版本历史 — 按 version 降序
   *
   * @param fragmentId - 片段逻辑 ID
   * @returns 版本列表（不含 content，仅 version/contentHash/createdAt）
   */
  listFragmentVersions(fragmentId: string): Promise<FragmentVersionInfo[]>

  /**
   * 查询谁引用了某片段 — 用于删除前检查阻塞列表
   *
   * @param fragmentId - 片段逻辑 ID
   * @returns 引用列表（含 lockedVersion 信息）
   */
  getSharedFragmentRefs(fragmentId: string): Promise<PackageSharedRef[]>

  /**
   * 设置包的共享片段引用 — 全量替换（事务原子性）
   *
   * 先删除该包的所有旧引用，再批量插入新引用。
   * 用于 register_package 内部同步，或前端独立调用管理引用。
   *
   * @param packageUuid - 包 UUID
   * @param refs - 引用列表（全量替换）
   */
  setPackageSharedRefs(packageUuid: string, refs: SharedRefParam[]): Promise<void>

  /**
   * 替换包内「单个文件」的共享片段引用 — 多片段包保存时调用
   *
   * 仅替换 (packageUuid, sourceFile) 维度的引用，**不影响同包其他文件**。
   * 与 `setPackageSharedRefs`（整包全量替换）相对，保存某个 markdown 文件后应使用本方法。
   *
   * @param packageUuid - 包 UUID
   * @param sourceFile - 引用所在文件（相对包目录的 POSIX 路径，如 "chapters/intro.md"）
   * @param refs - 该文件的引用列表（替换该文件的旧引用）
   */
  replaceFileSharedRefs(
    packageUuid: string,
    sourceFile: string,
    refs: SharedRefParam[],
  ): Promise<void>

  /**
   * 查询某包的全部共享片段引用（含各文件的 lockedVersion）— P0-2.3b 版本锁定
   *
   * 按 sourceFile → sortOrder 排序。编辑器保存重建引用前用它继承旧 lockedVersion，
   * 预览/导出渲染时用它构建 fragmentId → lockedVersion 映射。
   *
   * @param packageUuid - 包 UUID
   * @returns 该包的全部引用记录
   */
  getPackageSharedRefs(packageUuid: string): Promise<PackageSharedRef[]>

  /**
   * 更新单条包引用的锁定版本 — P0-2.3b 版本锁定 UI 调用
   *
   * 定位 (packageUuid, sourceFile, fragmentId) 唯一行更新；版本号超出 1..currentVersion
   * 或引用行不存在时后端返回错误。
   *
   * @param packageUuid - 引用方包 UUID
   * @param sourceFile - 引用所在文件（相对包目录 POSIX 路径；历史包级遗留为空串）
   * @param fragmentId - 被引用片段 ID
   * @param lockedVersion - null=跟随最新版本；数字=锁定到该版本
   */
  setSharedRefLockedVersion(
    packageUuid: string,
    sourceFile: string,
    fragmentId: string,
    lockedVersion: number | null,
  ): Promise<void>

  /**
   * 删除共享片段 — 被引用时拒绝，返回引用列表
   *
   * 符合 pack-spec "提示转为私有副本" 语义：被引用时不级联删除，
   * 而是返回 blockingRefs，由前端引导用户先解除引用或转为私有副本。
   *
   * @param fragmentId - 片段逻辑 ID
   * @returns 删除结果（deleted=true 成功 / deleted=false 被引用拒绝 + blockingRefs）
   */
  deleteSharedFragment(fragmentId: string): Promise<DeleteSharedFragmentResult>

  /**
   * 回滚片段到指定版本 — 移动 currentVersion 指针，不删后续版本行
   *
   * 回滚后后续版本仍可通过指定 version 访问，支持"撤销回滚"。
   *
   * @param fragmentId - 片段逻辑 ID
   * @param targetVersion - 目标版本号（必须存在）
   * @returns 更新后的片段信息（currentVersion=targetVersion）
   */
  rollbackFragment(fragmentId: string, targetVersion: number): Promise<SharedFragmentInfo>

  // ======================== 共享资源（P0-4） ========================

  /**
   * 注册共享资源 — 内容寻址幂等去重
   *
   * `hash` 由调用方计算（前端 `crypto.subtle.digest` 或 Rust 端 `util::compute_hash`）。
   * 若 hash 已存在则返回现有记录（不覆盖，保留首次注册的 originalName/storagePath）。
   *
   * @param params - hash、原始文件名、大小、MIME、存储路径
   * @returns 注册完成的资源信息
   */
  registerSharedResource(params: CreateSharedResourceParams): Promise<SharedResourceInfo>

  /**
   * 查询单个共享资源
   *
   * @param hash - 资源 SHA-256 hash
   * @returns 资源信息，不存在返回 null
   */
  getSharedResource(hash: string): Promise<SharedResourceInfo | null>

  /**
   * 列出当前库的所有共享资源 — 按 createdAt 降序
   *
   * @returns 资源列表（不含二进制内容，仅元数据）
   */
  listSharedResources(): Promise<SharedResourceInfo[]>

  /**
   * 设置包的资源引用 — 全量替换（事务原子性）
   *
   * 先删除该包的所有旧引用，再批量插入新引用。
   * 用于 register_package 内部同步，或前端独立调用管理引用。
   *
   * @param packageUuid - 包 UUID
   * @param refs - 引用列表（全量替换）
   */
  setPackageResourceRefs(packageUuid: string, refs: ResourceRefParam[]): Promise<void>

  /**
   * 替换包内「单个文件」的资源引用 — 多片段包保存时调用
   *
   * 仅替换 (packageUuid, sourceFile) 维度的引用，**不影响同包其他文件**。
   * 与 `setPackageResourceRefs`（整包全量替换）相对，保存某个 markdown 文件后应使用本方法。
   *
   * @param packageUuid - 包 UUID
   * @param sourceFile - 引用所在文件（相对包目录的 POSIX 路径，如 "chapters/intro.md"）
   * @param refs - 该文件的资源引用列表（替换该文件的旧引用）
   */
  replaceFileResourceRefs(
    packageUuid: string,
    sourceFile: string,
    refs: ResourceRefParam[],
  ): Promise<void>

  /**
   * 查询包引用的所有资源
   *
   * @param packageUuid - 包 UUID
   * @returns 该包的资源引用列表
   */
  getPackageResourceRefs(packageUuid: string): Promise<PackageResourceRef[]>

  /**
   * 反向查询 — 谁引用了某个资源（含引用方包标题）
   *
   * 用于删除前检查阻塞列表。LEFT JOIN packages 表获取包标题，
   * 包已删除时 packageTitle 为空字符串（与 P0-2 反向查询一致）。
   *
   * @param hash - 资源 SHA-256 hash
   * @returns 引用列表（含引用方包标题）
   */
  getResourceRefs(hash: string): Promise<ResourceRefInfo[]>

  /**
   * 删除共享资源 — 被引用时拒绝，返回引用列表
   *
   * 与 P0-2 共享片段删除语义一致：被引用时不级联删除，
   * 而是返回 blockingRefs，由前端引导用户先解除引用。
   * 注意：DB 层 ON DELETE CASCADE 保证包删除时引用自动清理，
   * 此处拒绝仅针对"资源仍被现存包引用"的场景。
   *
   * @param hash - 资源 SHA-256 hash
   * @returns 删除结果（deleted=true 成功 / deleted=false 被引用拒绝 + blockingRefs）
   */
  deleteSharedResource(hash: string): Promise<DeleteSharedResourceResult>

  /**
   * 修复资源引用路径 — 资源文件移动/重命名时调用
   *
   * 更新 shared_resources.storagePath + 关联的 package_resource_refs.refPath。
   * 用事务保证原子性。返回更新的引用数量。
   * 用于 P0-4.4 健康检查的自动修复流程。
   *
   * @param hash - 资源 SHA-256 hash
   * @param newStoragePath - 新的存储路径（相对库根）
   * @returns 更新的引用数量
   */
  repairResourceRefs(hash: string, newStoragePath: string): Promise<number>

  /**
   * 更新共享资源元数据（重命名显示名）
   *
   * 仅更新 originalName（UI 显示用），不涉及 storagePath / 文件系统。
   * 资源被引用时也可重命名——markdown 引用路径基于 storagePath（`.shared/<hash>.<ext>`），
   * 与 originalName 无关，重命名不影响任何引用关系。
   *
   * @param hash - 资源 SHA-256 hash
   * @param newOriginalName - 新的原始文件名（显示名）
   * @returns 更新后的资源信息
   */
  updateSharedResourceMeta(hash: string, newOriginalName: string): Promise<SharedResourceInfo>

  // ======================== CSS 样式（P-CSS） ========================

  /**
   * 保存 CSS 样式 — 写文件 + DB 索引（原子性：DB 失败回滚删文件）
   *
   * Tauri 端负责：
   * 1. 拼接库根 + sourcePath → 绝对路径
   * 2. 写 CSS 文件到绝对路径（自动创建父目录）
   * 3. 调 Rust 端计算 SHA-256 hash 并 INSERT OR REPLACE 到 css_styles 表
   * 4. DB 失败时回滚删除刚写的文件
   *
   * @param params - 含 id/name/scope/sourcePath/content/isBuiltin 等
   * @returns 保存完成的样式信息（含 contentHash/createdAt/updatedAt）
   */
  saveCssStyle(params: SaveCssStyleParams): Promise<CssStyleInfo>

  /**
   * 查询单个 CSS 样式 — 不存在返回 null
   *
   * @param scope - 作用域："public" 或 "private"
   * @param id - 样式 ID
   * @returns 样式信息，不存在则 null
   */
  getCssStyle(scope: CssStyleScope, id: string): Promise<CssStyleInfo | null>

  /**
   * 按 scope + id 计算样式文件绝对路径 — v7 文件夹自治语义
   *
   * 读取/导出 CSS 内容时调用，替代「库根 + sourcePath」手工拼接：
   * - public → 库根 + source_path
   * - private → 包绝对路径（folder_id 归属）+ source_path（相对包目录）
   * 注册文件夹内包 dir_path 相对文件夹，旧拼接会指向错误位置。
   *
   * @param scope - 作用域："public" 或 "private"
   * @param id - 样式 ID
   * @returns 样式文件的绝对路径
   */
  getCssStyleAbsPath(scope: CssStyleScope, id: string): Promise<string>

  /**
   * 列出当前库所有公共 CSS 样式（内置优先 + name 升序）
   *
   * 用于样式管理面板展示公共样式列表。
   *
   * @returns 公共样式列表（含内置样式）
   */
  listPublicCssStyles(): Promise<CssStyleInfo[]>

  /**
   * 列出指定 .pack 的私有 CSS 样式（按 name 升序）
   *
   * @param packageUuid - 包 UUID
   * @returns 该包的私有样式列表
   */
  listPackageCssStyles(packageUuid: string): Promise<CssStyleInfo[]>

  /**
   * 列出 .pack 可选的所有样式（公共 + 私有）— 样式选择器 UI 使用
   *
   * 返回元组 [public_styles, private_styles]，前端合并展示。
   * 公共样式按 isBuiltin 优先 + name 排序；私有样式按 name 排序。
   *
   * @param packageUuid - 包 UUID
   * @returns [公共样式列表, 该包私有样式列表]
   */
  listStylesForPackage(
    packageUuid: string,
  ): Promise<[CssStyleInfo[], CssStyleInfo[]]>

  /**
   * 删除 CSS 样式 — 删 DB 索引 + 磁盘文件（内置样式拒绝删除）
   *
   * 流程：查 DB 拿 sourcePath → 删 DB → 删磁盘文件（best-effort）。
   * 内置样式（isBuiltin=true）在 Rust 端被拒绝删除。
   *
   * @param scope - 作用域："public" 或 "private"
   * @param id - 样式 ID
   */
  deleteCssStyle(scope: CssStyleScope, id: string): Promise<void>

  /**
   * 设置 .pack 当前选中的 CSS 样式 — 两态语义
   *
   * - 传 ActiveStyle 对象（styleType + id）：设置 active_style
   * - 传 null：清空 active_style（不使用样式）
   *
   * 设置后需同步写回 .packmeta.json 的 active_style 字段（由调用方负责）。
   *
   * @param packageUuid - 包 UUID
   * @param activeStyle - ActiveStyle 对象或 null
   */
  setPackageActiveStyle(
    packageUuid: string,
    activeStyle: ActiveStyle | null,
  ): Promise<void>

  /**
   * 查询 .pack 当前选中的 CSS 样式 — null 表示未设置
   *
   * @param packageUuid - 包 UUID
   * @returns 当前选中的样式引用，未设置则 null
   */
  getPackageActiveStyle(packageUuid: string): Promise<ActiveStyle | null>

  /**
   * 扫描公共 CSS 样式 — 全量同步 `.gewu/styles/` 目录到 DB
   *
   * 扫描 `.gewu/styles/` 下的 `.css` 文件，计算 hash 并 upsert 到 css_styles 表。
   * 已有记录保留 name/description/category/isBuiltin（仅刷新 hash）；
   * 磁盘上已删除的文件对应的 DB 记录也会被清理（内置样式除外）。
   *
   * 库初始化时调用以同步用户手动放入 `.gewu/styles/` 的 CSS 文件。
   *
   * @returns 扫描结果统计（新注册 / 更新 / 删除 / 耗时）
   */
  scanPublicCssStyles(): Promise<CssStyleScanResult>

  // ======================== 邮件收件箱（mail-inbox-spec.md 阶段 1） ========================

  /**
   * 立即收取邮件 — IMAP 拉取 + 去重过滤 + 附件内容寻址入库
   *
   * 附件已在 Rust 侧落盘 `.shared/<hash前16>.<ext>` 并注册 DB；
   * 返回待落盘草稿（正文 HTML/纯文本 + 附件引用路径），由前端完成
   * HTML→Markdown 转换与 md/.pack 文件编排。
   *
   * @param folderUuid - 收件箱文件夹 uuid（多账号：每个收件箱独立配置与凭据）
   */
  mailFetch(folderUuid: string): Promise<MailFetchResult>

  /**
   * 回写邮件落盘结果 — 每封邮件处理完成后调用
   *
   * @param messageId - 邮件 Message-ID（mailFetch 返回的 messageId）
   * @param status - "saved"（落盘成功，永久跳过）或 "failed"（重收时重试）
   * @param filePath - 落盘主文件绝对路径（saved 时必传）
   * @param error - 失败原因（failed 时传）
   */
  mailSaveResult(
    messageId: string,
    status: "saved" | "failed",
    filePath?: string | null,
    error?: string | null,
  ): Promise<void>

  /**
   * 读取某收件箱的邮箱账号配置 — 未配置返回 null
   *
   * @param folderUuid - 收件箱文件夹 uuid
   */
  mailAccountGet(folderUuid: string): Promise<MailAccount | null>

  /**
   * 新建/覆盖某收件箱的邮箱账号配置（folder_uuid 唯一 UPSERT）
   *
   * 授权码不走此方法，另经 `mailCredentialSet` 写入 Windows 凭据管理器。
   */
  mailAccountSave(params: {
    folderUuid: string
    host: string
    port: number
    ssl: boolean
    mailUser: string
    imapFolder: string
    fetchLimit: number
    /** 收取过滤：仅未读 */
    unseenOnly: boolean
    /** 收取过滤：最近 N 天（0 = 不限） */
    sinceDays: number
    /** 收取过滤：关键词（发件人或主题，空串 = 不过滤） */
    keyword: string
    /** 勾选收取的 IMAP 文件夹映射（空数组 = 仅收 imapFolder） */
    imapFolders: ImapFolderMapping[]
  }): Promise<void>

  /**
   * 删除某收件箱的邮箱账号配置（收件箱文件夹删除时级联调用）
   *
   * @returns 是否实际删除了行
   */
  mailAccountDelete(folderUuid: string): Promise<boolean>

  /** 列出全部已配置邮箱账号（定时收信遍历收件箱用） */
  mailAccountList(): Promise<MailAccount[]>

  /**
   * 写入/覆盖授权码到 Windows 凭据管理器（keyring，不落 DB/明文）
   *
   * @param folderUuid - 收件箱文件夹 uuid（凭据条目名，每收件箱独立）
   */
  mailCredentialSet(folderUuid: string, password: string): Promise<void>

  /**
   * 查询授权码是否已配置 — 不返回明文
   *
   * @param folderUuid - 收件箱文件夹 uuid（凭据条目名）
   */
  mailCredentialConfigured(folderUuid: string): Promise<boolean>

  /**
   * 测试连接 — 用表单当前值连接并登录
   *
   * @param password - 授权码；为空时回退 keyring 已存凭据（支持先测后存）
   */
  mailTestConnection(params: {
    folderUuid: string
    host: string
    port: number
    ssl: boolean
    user: string
    imapFolder: string
    password?: string | null
  }): Promise<void>

  /**
   * LIST 列出 IMAP 服务器上的文件夹（供邮箱设置勾选多文件夹收取）
   *
   * 用表单当前连接参数（支持保存前先获取）；password 缺省时回退 keyring 已存授权码。
   */
  mailListImapFolders(params: {
    folderUuid: string
    host: string
    port: number
    ssl: boolean
    user: string
    password?: string | null
  }): Promise<ImapFolderInfo[]>

  // ======================== 🟡 预留（未来） ========================

  /**
   * 获取网页标题 — 通过 HTTP GET 请求目标 URL，解析 <title> 标签
   *
   * @param url - 目标网页 URL
   * @returns 页面标题，无法获取时返回 null
   */
  fetchPageTitle(url: string): Promise<string | null>

  /**
   * 🟡 备份知识库到指定路径
   *
   * @param path - 备份目标路径
   * @scene 1.8
   */
  backup?(path: string): Promise<void>

  /**
   * 🟡 从指定路径恢复知识库
   *
   * @param path - 备份文件路径
   * @scene 1.8
   */
  restore?(path: string): Promise<void>

  /**
   * 🟡 获取文件数量时间趋势
   *
   * @param duration - 统计周期：week | month | quarter | year
   * @returns 按时间段聚合的新增/删除/总量
   * @scene 5.5
   */
  getTrend?(duration: "week" | "month" | "quarter" | "year"): Promise<TrendItem[]>
}