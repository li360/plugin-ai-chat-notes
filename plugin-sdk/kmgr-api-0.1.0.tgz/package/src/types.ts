/**
 * kmgr-api 数据模型类型
 * 纯 TypeScript 类型，零运行时依赖。与 SCENES.md 中的模型一一对应。
 */

/** 库注册表条目 — 来自 AppData 下的 libraries.json，记录用户创建/打开过的库 */
export interface LibraryEntry {
  /** 库名称 */
  name: string
  /** 库路径（SQLite 文件所在目录的绝对路径） */
  path: string
  /** 库类型，当前仅 "local" */
  type: "local"
  /** 添加到注册表的时间，ISO 8601 */
  addedAt: string
}

/** 知识库 — 对应一个 SQLite 数据库文件 */
export interface KnowledgeBase {
  /** 自增主键 */
  id: number
  /** 知识库名称，如 "我的知识库" */
  name: string
  /** SQLite 文件所在目录的绝对路径 */
  path: string
  /** 知识库类型，当前仅 "local"，🟡 未来扩 "remote" */
  type: "local"
  /** 🟡 个人标识，单用户为 null，共享时用于标识归属 */
  ownerId: string | null
  /** 🟡 版本号，每次发布/共享后递增，初始 1 */
  version: number
  /** 🟡 上次共享发布时间，ISO 8601 */
  sharedAt: string | null
  /** 🟡 共享有效期截止时间，ISO 8601 */
  shareExpiresAt: string | null
  /** 创建时间，ISO 8601 */
  createdAt: string
  /** 最后更新时间，ISO 8601 */
  updatedAt: string
}

/** 知识库详情，含运行时信息（如数据库文件大小） */
export interface KnowledgeBaseInfo {
  id: number
  name: string
  path: string
  type: "local"
  ownerId: string | null
  version: number
  sharedAt: string | null
  shareExpiresAt: string | null
  /** SQLite 数据库文件大小（bytes） */
  dbSize: number
  /** 数据库文件完整路径 — 优先 `.gewu/kmgr.db`（新结构），其次 `kmgr.db`（旧结构） */
  dbPath: string
  createdAt: string
  updatedAt: string
}

/** 库信息查询结果 — 用于 UI 展示库的数据库/元数据位置 */
export interface LibraryInfo {
  /** 库名称（来自注册表，未注册时为空字符串） */
  name: string
  /** 库根目录路径 */
  path: string
  /** 数据库文件完整路径（`<path>/kmgr.db`） */
  dbPath: string
  /** 数据库文件大小（字节），不存在为 0 */
  dbSize: number
  /** 库根目录是否存在 */
  exists: boolean
  /** 数据库文件是否存在 */
  dbExists: boolean
  /** 添加到注册表的时间（ISO 8601），未注册为 null */
  addedAt: string | null
}

/** 文件信息 — 知识库中被索引的单个文件 */
export interface FileInfo {
  /** 自增主键 */
  id: number
  /** 文件名（不含路径），如 "index.ts" */
  name: string
  /** 文件绝对路径 */
  path: string
  /** 扩展名（小写，含点），如 ".ts" */
  ext: string
  /** 文件大小（bytes） */
  size: number
  /** 所属分类 ID，null 表示未分类 */
  categoryId: number | null
  /** 文件来源，当前仅 "local"，🟡 预留 "remote" */
  origin: "local"
  /** 🟡 知识生效时间（如法条施行日），ISO 8601 */
  validFrom: string | null
  /** 🟡 知识失效时间（如政策废止日），ISO 8601 */
  validUntil: string | null
  /** 首次索引时间，ISO 8601 */
  createdAt: string
  /** 文件系统最后修改时间，ISO 8601 */
  modifiedAt: string
  /** 最近一次打开时间，用于"最近文件"排序 */
  accessedAt: string
}

/** 分类 — 文件的组织方式，支持树形层级 */
export interface Category {
  /** 自增主键 */
  id: number
  /** 唯一标识名，如 "project-a" */
  name: string
  /** 展示名称，如 "项目A" */
  displayName: string
  /** 父分类 ID，null 为根分类 */
  parentId: number | null
  /** 同级排序权重，越小越靠前 */
  sortOrder: number
  /** 是否为系统内置分类（不可删除） */
  isSystem: boolean
  /** 是否允许用户删除 */
  canDelete: boolean
  /** 该分类下的文件数量（聚合计算，非存储字段） */
  fileCount: number
}

/** 分类树节点 — 含子节点递归结构 */
export interface CategoryNode {
  id: number
  name: string
  displayName: string
  parentId: number | null
  sortOrder: number
  isSystem: boolean
  canDelete: boolean
  fileCount: number
  /** 子分类列表 */
  children: CategoryNode[]
}

/** 标签 — 文件的标注方式，支持树形层级和多对多关联 */
export interface Tag {
  /** 自增主键 */
  id: number
  /** 唯一标签名，如 "rust" */
  name: string
  /** 父标签 ID，null 为根标签 */
  parentId: number | null
  /** 标签颜色，如 "#ff4757" */
  color: string | null
  /** 标签图标（emoji） */
  icon: string | null
  /** 同级排序权重 */
  sortOrder: number
  /** 该标签关联的文件数量（聚合计算） */
  fileCount: number
}

/** 标签树节点 — 含子节点递归结构 */
export interface TagNode extends Tag {
  /** 子标签列表 */
  children: TagNode[]
}

/** 配置项 — key-value 模式，value 为 JSON 可序列化的任意值 */
export interface Setting {
  /** 配置键，如 "scan.ignorePaths" */
  key: string
  /** 配置值，JSON 可序列化 */
  value: unknown
  /** 最后更新时间，ISO 8601 */
  updatedAt: string
}

/** 文件地理信息（file_geo 表一行）— 图片 EXIF GPS / 手动位置 / 笔记位置 */
export interface FileGeo {
  /** 关联的文件 ID */
  fileId: number
  /** 纬度（WGS84） */
  latitude: number
  /** 经度（WGS84） */
  longitude: number
  /** 海拔（米），无此信息时为 null */
  altitude: number | null
  /** 数据来源：exif / manual / frontmatter */
  source: string
  /** 解析时文件的 modified_at（变化时触发重新解析） */
  fileModifiedAt: string
  /** 入库时间，ISO 8601 */
  parsedAt: string
}

/** 地理点位 — file_geo JOIN files，地图视图打点用 */
export interface FileGeoPoint {
  /** 文件 ID */
  fileId: number
  /** 文件名 */
  name: string
  /** 文件绝对路径 */
  path: string
  /** 扩展名（不含点，小写） */
  ext: string
  /** 纬度（WGS84） */
  latitude: number
  /** 经度（WGS84） */
  longitude: number
  /** 海拔（米） */
  altitude: number | null
  /** 数据来源：exif / manual / frontmatter */
  source: string
}

/** 写入/更新文件地理信息的参数 */
export interface UpsertFileGeoParams {
  /** 文件 ID */
  fileId: number
  /** 纬度（WGS84） */
  latitude: number
  /** 经度（WGS84） */
  longitude: number
  /** 海拔（米），无则 null */
  altitude?: number | null
  /** 数据来源：exif / manual / frontmatter */
  source: string
  /** 文件当前 modified_at（用于 EXIF 失效判断） */
  fileModifiedAt: string
}

/** 按文件路径写入地理信息的参数（EXIF 懒解析回写用，无需先查文件 ID） */
export interface UpsertFileGeoByPathParams {
  /** 文件绝对路径 */
  path: string
  /** 纬度（WGS84） */
  latitude: number
  /** 经度（WGS84） */
  longitude: number
  /** 海拔（米），无则 null */
  altitude?: number | null
  /** 数据来源：exif / manual / frontmatter */
  source: string
}

/** 插件数据项 — 每个插件按 (pluginId, key) 维度存储自有数据 */
export interface PluginData {
  /** 插件 ID（对应 PluginManifest.id） */
  pluginId: string
  /** 数据键 */
  key: string
  /** 数据值，JSON 可序列化 */
  value: unknown
  /** 最后更新时间，ISO 8601 */
  updatedAt: string
}

/** 知识库统计摘要 — 总览面板数据源 */
export interface Stats {
  /** 文件总数 */
  totalFiles: number
  /** 分类总数 */
  totalCategories: number
  /** 标签总数 */
  totalTags: number
  /** 所有文件总大小（bytes） */
  totalSize: number
}

/** 分布统计类型 */
export type DistributionType = "category" | "ext" | "tag"

/** 分布统计 — 按维度分组计数 */
export interface Distribution {
  /** 统计维度 */
  type: DistributionType
  /** 分布项列表，按 count 降序 */
  items: DistributionItem[]
}

/** 分布项 */
export interface DistributionItem {
  /** 唯一键，如分类名、扩展名、标签名 */
  key: string
  /** 展示标签 */
  label: string
  /** 该分组下的文件数量 */
  count: number
  /** 占总文件数的百分比（0-100） */
  pct: number
}

/** 时间趋势项 — 🟡 预留 */
export interface TrendItem {
  /** 时间段标识，如 "2026-01" */
  period: string
  /** 该时间段新增文件数 */
  added: number
  /** 该时间段移除文件数 */
  removed: number
  /** 该时间段末文件总数 */
  total: number
}

/** 列表排序字段 */
export interface ListSort {
  /** 排序字段 */
  field: "createdAt" | "modifiedAt" | "accessedAt" | "name" | "size" | "ext"
  /** 是否升序 */
  asc: boolean
}

/** 删除模式 */
export type DeleteMode = "detach" | "cascade"
// detach: 解除关联，文件移到根（categoryId → null）
// cascade: 级联删除，文件一并删除

/**
 * 分页结果 — 所有列表类 API 的统一返回格式
 * @template T 列表项类型
 */
export interface PaginatedResult<T> {
  /** 当前页数据 */
  items: T[]
  /** 符合条件的总数（非当前页数量） */
  total: number
  /** 当前页码（从 1 开始） */
  page: number
  /** 每页条数 */
  pageSize: number
}

/** 搜索命中项 — 含匹配片段和相关性分数 */
export interface SearchResultItem {
  /** 命中的文件信息 */
  file: FileInfo
  /** 匹配的上下文片段（最多 200 字符） */
  snippet: string
  /** 相关性分数（0-1），越高越相关 */
  relevance: number
}

/** 目录导入结果 */
export interface ImportResult {
  /** 成功添加的文件数 */
  filesAdded: number
  /** 跳过的文件数（扩展名不匹配、已存在等） */
  filesSkipped: number
  /** 自动创建的分类数 */
  categoriesCreated: number
  /** 耗时（毫秒） */
  elapsedMs: number
}

/** 目录条目 — 文件系统浏览结果 */
export interface DirectoryEntry {
  /** 文件/目录名 */
  name: string
  /** 完整路径 */
  path: string
  /** 是否为目录 */
  is_dir: boolean
  /** 文件大小（字节），目录为 0 */
  size: number
  /** 扩展名（如 ".ts"），目录为空 */
  ext: string
  /** 最后修改时间，ISO 8601 */
  modifiedAt: string
}

/** 重扫结果 — 对比文件系统与数据库的差异 */
export interface RescanResult {
  /** 新增的文件 */
  added: FileInfo[]
  /** 内容已变更的文件 */
  modified: FileInfo[]
  /** 已从磁盘删除的文件 ID 列表 */
  removed: number[]
}

/** applyRescan 的参数 — 由前端从 detectChanges 结果中提取 */
export interface ApplyRescanParams {
  /** 要新增的文件路径列表 */
  added: string[]
  /** 要更新的文件 ID 列表 */
  modified: number[]
  /** 要删除的文件 ID 列表 */
  removed: number[]
}

/** 文件夹类型 */
export type FolderType = "inbox" | "workspace" | "archive" | "resource" | "general"

/** 文件夹信息 — 库内的虚拟文件夹 */
export interface FolderInfo {
  id: number
  kbId: number
  name: string
  path: string
  folderType: FolderType
  /** v7 文件夹自治：文件夹身份 uuid（磁盘 .gewu/folder.json），重新定位的唯一凭据 */
  folderUuid?: string
  sortOrder: number
  createdAt: string
  updatedAt: string
}

/**
 * 重新定位结果（S3）— 内部标记枚举，按 kind 分发 UI
 *
 * - "done"：定位成功，携带最新 FolderInfo
 * - "identityMissing"：目标目录无 .gewu/folder.json（需用户确认是否强制）
 * - "identityMismatch"：目标目录身份 uuid 与登记不符（需用户确认是否强制覆盖）
 */
export type RelocateOutcome =
  | (FolderInfo & { kind: "done" })
  | { kind: "identityMissing"; path: string }
  | { kind: "identityMismatch"; foundUuid: string; path: string }

/**
 * 路径分类结果 — 「库内」判定（0.26 新理念，2026-08-08）
 *
 * 库内 = 在任一注册文件夹内（含收件箱），不含库根（纯索引区）。
 * 前端所有「库内/库外」判断统一调用 `classifyPath`，禁止用库根物理前缀自行匹配。
 */
export interface PathClassify {
  /** 是否在任一注册文件夹内（含收件箱）— 内容归属判定基准（包归属、自动索引、移动目标校验） */
  inKb: boolean
  /** 所属注册文件夹 ID — 嵌套注册时取最具体（路径最长）者；不在任何文件夹内为 null */
  folderId: number | null
  /** 物理是否在库根内 — 「打开体验」宽口径判断用（注册文件夹 ∪ 库根物理内不弹导入框） */
  insideKbRoot: boolean
}

// ======================== 包与双链（Phase 1） ========================

/**
 * 包注册信息 — 双链的目标实体
 *
 * uuid 来自 `.packmeta.json` 的 `id` 字段，全局稳定；
 * 包被移动或重命名时 uuid 不变，所有双链自动保持有效。
 */
export interface PackageInfo {
  /** 包 UUID（来自 .packmeta.json 的 id，全局稳定） */
  uuid: string
  /** 所属库 ID */
  libraryId: number
  /** 包名（来自 .packmeta.json 的 title） */
  title: string
  /** 包目录相对库根的路径 */
  dirPath: string
  /** 主片段文件相对路径（来自 fragments[0].file） */
  mainFile: string | null
  /**
   * 当前选中的 CSS 样式类型（P-CSS）
   * - "public"：使用公共样式
   * - "private"：使用本包私有样式
   * - null：未设置样式
   */
  activeStyleType?: "public" | "private" | null
  /**
   * 当前选中的 CSS 样式 ID（P-CSS）
   * 与 activeStyleType 同时为 null 表示未设置样式。
   */
  activeStyleId?: string | null
  /** 注册时间，ISO 8601 */
  createdAt: string
  /** 最后更新时间，ISO 8601 */
  updatedAt: string
}

/** 注册包参数 — 库扫描时调用 */
export interface RegisterPackageParams {
  /** 包 UUID（来自 .packmeta.json 的 id） */
  uuid: string
  /** 包名 */
  title: string
  /** 包目录相对库根的路径 */
  dirPath: string
  /** 主片段文件相对路径 */
  mainFile?: string | null
  /**
   * 共享片段引用列表（P0-2.2）
   * - undefined/省略：不同步引用（向后兼容，前端调用通常省略）
   * - 数组：全量替换该包的引用关系（扫描时从 .packmeta.json 解析传入）
   */
  sharedRefs?: SharedRefParam[]
  /**
   * 包片段元数据列表（P1-5.0）
   * - undefined/省略：不同步片段（向后兼容）
   * - 数组：全量替换该包的片段记录（扫描时从 .packmeta.json fragments[] 解析传入）
   */
  fragments?: FragmentParam[]
  /**
   * 包内私有 CSS 样式元数据列表（P-CSS）
   * - undefined/省略：不同步私有样式（向后兼容）
   * - 数组：全量替换该包的私有样式记录（扫描时从 .packmeta.json private_styles[] 解析传入）
   */
  privateStyles?: PrivateStyleMeta[]
  /**
   * 包当前选中的 CSS 样式（P-CSS）
   * - undefined/省略：不同步 active_style（保留 DB 现状）
   * - null：清空 active_style（不使用样式）
   * - ActiveStyle 对象：设置 active_style
   */
  activeStyle?: ActiveStyle | null
}

/**
 * 备份目录信息 — `listBackups` 返回，描述库根 `.gewu/backup-*` 下的一个数据库备份（备份中心）
 */
export interface BackupInfo {
  /** 目录名（backup-<时间戳>，如 backup-20260808-163000） */
  name: string
  /** 备份目录绝对路径（含 kmgr.db 一致性快照） */
  path: string
  /** 展示用创建时间（从目录名解析，格式 YYYY-MM-DD HH:MM:SS） */
  created_at: string
  /** 备份目录总大小（字节） */
  size: number
}

/**
 * 文件级留档记录（备份中心「文件回收站 / 版本历史」数据源，v0.26.5 新增）
 *
 * 对应 `file_backups` 表一行，是磁盘留档（.gewu/trash/ 与 .gewu/versions/）的索引。
 * 真相在文件系统：trash=删除保护（原文件被移到 .gewu/trash/，恢复即移回原路径）；
 * version=修改保护（覆盖保存前文本类旧文件复制到 .gewu/versions/，恢复即写回覆盖）。
 * 保留期由 settings.file_backup_retention_days 控制（默认 30 天），过期启动时自动清理。
 */
export interface FileBackupInfo {
  /** 自增主键 */
  id: number
  /** 留档类型："trash"（删除保护/回收站）| "version"（修改保护/版本历史） */
  backupType: "trash" | "version"
  /** 原始文件/目录的绝对路径（恢复目标） */
  originalPath: string
  /** 留档存放的绝对路径（.gewu/trash/ 或 .gewu/versions/ 下） */
  backupPath: string
  /** 原始文件名（展示用） */
  fileName: string
  /** 留档大小（字节；目录为递归总大小） */
  fileSize: number
  /** 留档创建时间（YYYY-MM-DD HH:MM:SS） */
  createdAt: string
  /** 过期时间（YYYY-MM-DD HH:MM:SS），到期后由启动清理移除 */
  expiresAt: string
}

/**
 * 文件操作日志条目 — `readFileOpsLog` 返回（「设置 → 日志 → 文件操作」视图）
 *
 * 对应 Rust 侧 file-ops.log 的一行（格式：时间 [操作] 详情）。
 * 备份记录（backup_db）的 detail 含备份目录路径，用户可据此找回文件。
 */
export interface FileOpEntry {
  /** 日志时间（YYYY-MM-DD HH:MM:SS.mmm） */
  ts: string
  /** 操作类型（create_directory / create_file / rename_file / delete_file / copy_path / move_path / delete_path / trash_path / backup_db 等） */
  op: string
  /** 操作详情（源/目标/结果/备份路径等） */
  detail: string
}

/**
 * 文件版本元信息 — `listFileVersions` 返回，不含 content 节省流量
 *
 * 对应 Rust 侧 FileVersionInfo（file-timeline-spec.md）。
 * file_id 为软引用：文件删除后版本保留为孤儿（T5），file_path 快照仍可定位。
 */
export interface FileVersionInfo {
  /** 版本记录自增主键 */
  id: number
  /** 关联 files.id（软引用，文件删除后悬空） */
  fileId: number
  /** 版本创建时文件绝对路径快照（孤儿版本恢复凭据） */
  filePath: string
  /** 文件内版本号（从 1 递增） */
  version: number
  /** content 的 SHA-256 hex（去重） */
  contentHash: string
  /** 产生来源："save"（保存）| "restore"（恢复） */
  source: string
  /** source="restore" 时指向来源版本号 */
  restoredFromVersion?: number | null
  /** 内容行数（列表摘要展示「+N 行」用） */
  lineCount: number
  /** 版本创建时间（YYYY-MM-DD HH:MM:SS） */
  createdAt: string
}

/** 文件版本内容 — `getFileVersion` 返回，含具体 content（平铺结构） */
export interface FileVersionContent extends FileVersionInfo {
  /** 版本内容 */
  content: string
}

/** diff 行 — `getFileVersionDiff` 返回 */
export interface DiffLine {
  /** "add"（当前新增，绿）| "delete"（历史被删，红）| "context"（上下文） */
  type: "add" | "delete" | "context"
  /** 历史版本侧行号（diff_type="add" 时为 null） */
  oldLine?: number | null
  /** 当前内容侧行号（diff_type="delete" 时为 null） */
  newLine?: number | null
  /** 行内容（不含换行符） */
  text: string
}

/** 记录文件版本入参 — `recordFileVersion` 调用 */
export interface RecordFileVersionParams {
  /** 关联文件 ID（files.id） */
  fileId: number
  /** 文件绝对路径快照（当前路径） */
  filePath: string
  /** 保存后写入磁盘的新内容（用于计算 hash + 落库） */
  content: string
  /** 产生来源，默认 "save" */
  source?: string
}

/**
 * 包片段信息 — `listPackageFragments` 返回，描述包内一个片段的元数据（P1-5.0）
 *
 * 对应 .packmeta.json 的 `fragments[]` 元素，每个片段是一个独立的 markdown 文件。
 * `sortOrder` 控制拼接顺序（升序），`fragmentId` 在包内唯一稳定。
 *
 * 与 `PackageInfo.mainFile` 关系：`mainFile` 仍存 `fragments[0].file`（向后兼容），
 * `package_fragments` 表是补充，提供完整多片段信息。
 */
export interface FragmentInfo {
  /** 片段 ID（来自 .packmeta.json fragments[].id，包内唯一） */
  fragmentId: string
  /** 片段文件名（相对包目录，如 "引言.md"） */
  file: string
  /** 顺序（0, 1, 2, ...），按升序拼接展示 */
  sortOrder: number
  /** 片段类型（如 "markdown"，可空预留扩展） */
  fragmentType?: string
}

/**
 * 设置包片段的入参 — `setPackageFragments` 调用（P1-5.0）
 *
 * 与 `FragmentInfo` 区别：调用方不需要传 `sortOrder`（由 `setPackageFragments`
 * 按数组顺序自动填充 0, 1, 2, ...）。
 */
export interface FragmentParam {
  /** 片段 ID（包内唯一，来自 .packmeta.json fragments[].id） */
  fragmentId: string
  /** 片段文件名（相对包目录） */
  file: string
  /** 片段类型（如 "markdown"，可空预留扩展） */
  fragmentType?: string
}

/**
 * 双链记录 — 源包对目标包的一次引用
 *
 * 对应 markdown 中的 `[[targetName]]` 或 `[[targetName|displayText]]`。
 * targetPackageUuid 与 resolved 由 syncLinks 时自动解析填充。
 */
export interface LinkRecord {
  /** 目标包名（链接原始文本 `[[targetName|...]]`） */
  targetName: string
  /** 显示文本（无别名时同 targetName） */
  displayText: string
  /** 源文件相对路径（同一包内多文件可能都含链接） */
  sourceFilePath: string
}

/** 反向链接条目 — 谁引用了目标包 */
export interface BacklinkItem {
  /** 源包 UUID */
  sourceUuid: string
  /** 源包标题（源包已删除时为空字符串 — R8 优雅降级） */
  sourceTitle: string
  /** 源包目录路径（相对库根，源包已删除时为空字符串） */
  sourceDirPath: string
  /** 源文件相对包目录的路径 */
  sourceFilePath: string
  /** 链接中的目标名 */
  targetName: string
  /** 链接显示文本 */
  displayText: string
}

/** 知识图谱节点 — 一个包对应一个节点（全库，含注册文件夹内的包） */
export interface GraphNode {
  /** 包 UUID */
  uuid: string
  /** 包标题（图谱显示名） */
  title: string
  /** 包目录路径（folderId 存在时相对所属文件夹，否则相对库根） */
  dirPath: string
  /** 归属文件夹 ID — 缺省表示库根直属包 */
  folderId?: number
  /** 主片段文件名 — 点击节点打开用，可能为 null（旧数据） */
  mainFile?: string | null
}

/** 知识图谱边 — 两个包之间已解析的双链（按源包→目标包去重） */
export interface GraphEdge {
  /** 源包 UUID */
  source: string
  /** 目标包 UUID */
  target: string
}

/** 悬挂双链 — 指向尚不存在包名的 [[名字]]（按源包 + 目标名去重） */
export interface GraphDanglingLink {
  /** 源包 UUID */
  source: string
  /** 链接中的目标名（未解析文本） */
  targetName: string
}

/** 知识图谱数据 — 全库包节点 + 已解析边 + 悬挂链接 */
export interface LinkGraph {
  /** 全部包节点 */
  nodes: GraphNode[]
  /** 已解析双链（去重后的有向边） */
  edges: GraphEdge[]
  /** 未解析的悬挂链接 */
  dangling: GraphDanglingLink[]
}

/** 包搜索结果 — 精简字段，用于自动补全 */
export interface PackageSearchResult {
  uuid: string
  title: string
  dirPath: string
}

/**
 * 包扫描结果统计 — 库扫描时全量注册包的执行结果（D6）
 *
 * 由 `scanPackages` 触发，扫描库根目录下所有 `.pack` 文件夹，
 * 读取 `.packmeta.json` 并注册到数据库。
 */
export interface PackageScanResult {
  /** 新注册的包数量 */
  registered: number
  /** 已存在但被刷新（含路径更新 R9）的包数量 */
  updated: number
  /** `.pack` 目录但 `.packmeta.json` 缺失或解析失败的包数量 */
  skipped: number
  /** 扫描耗时（毫秒） */
  durationMs: number
  /** 新注册的包详情列表 */
  registeredItems: PackageScanItem[]
  /** 已更新的包详情列表 */
  updatedItems: PackageScanItem[]
  /** 跳过的包详情列表（含跳过原因） */
  skippedItems: PackageScanItem[]
}

/** 单个包的扫描详情 — 用于在扫描结果 Dialog 中展示具体条目 */
export interface PackageScanItem {
  /** 包目录名（如 `游记.pack`） */
  dirName: string
  /** 包目录相对库根的路径（如 `subdir/游记.pack`） */
  relPath: string
  /** 包标题（来自 `.packmeta.json`，解析失败时为空） */
  title: string
  /** 跳过原因（仅 `skippedItems` 中有意义，如「缺少 .packmeta.json」） */
  skipReason: string
}

/**
 * 文件归属解析结果 — 由绝对文件路径反查所属包
 *
 * 保存文件时调用，用于确定 `syncLinks` 的 `sourceUuid` 和 `sourceFilePath`。
 */
export interface FilePackageResolve {
  /** 所属包信息 */
  package: PackageInfo
  /** 文件相对包目录的路径（如 `游记.md` 或 `fragments/背景.md`） */
  sourceFilePath: string
}

/** 路径不一致项 — DB 中 dirPath 与磁盘实际路径不符 */
export interface PathMismatchItem {
  /** 包信息（含旧 dirPath） */
  package: PackageInfo
  /** 磁盘实际路径（相对所属文件夹或库根，v7 文件夹自治） */
  actualPath: string
  /** 磁盘实际绝对路径（平台分隔符归一化）— 供 movePackage 按新归属修复 */
  actualAbsPath: string
}

/** 损坏的共享资源引用项 — 资源被包引用但磁盘文件不存在（P0-4.4） */
export interface BrokenResourceRefItem {
  /** 引用方包 UUID */
  packageUuid: string
  /** 引用方包标题（包已删除时为空字符串） */
  packageTitle: string
  /** 资源 SHA-256 hash */
  resourceHash: string
  /** 资源相对库根的存储路径（如 `.shared/abc.png`） */
  refPath: string
  /** 引用类型（如 `image` / `attachment`） */
  refType: string
}

/** 孤立共享资源项 — 资源存在但无任何包引用（P0-4.4） */
export interface OrphanResourceItem {
  /** 资源 SHA-256 hash */
  hash: string
  /** 原始文件名（首次注册时记录） */
  originalName: string
  /** 文件大小（字节） */
  fileSize: number
  /** 资源相对库根的存储路径（如 `.shared/abc.png`） */
  storagePath: string
}

/**
 * 库健康检查结果 — 只读检测，列出所有问题项
 *
 * 检测项与修复方式：
 * - `unregisteredPacks` 磁盘有 .pack 但 DB 无记录 → 修复：scanPackages
 * - `deletedPackages` DB 有记录但磁盘无 .pack 目录 → 修复：deletePackage
 * - `pathMismatched` DB 中 dirPath 与磁盘实际路径不符 → 修复：movePackage（按实际绝对路径重判 folder_id + dir_path）
 * - `orphanLinksCount` 未解析双链数 → 修复：resolvePendingLinks
 * - `missingMainFiles` 主文件缺失的包列表（不自动修复，仅提示）
 * - `brokenResourceRefs` 资源引用方存在但磁盘文件缺失（P0-4.4，不自动修复，在 resource-manager 中处理）
 * - `orphanResources` 资源存在但无任何包引用（P0-4.4，不自动修复，可在 resource-manager 中删除）
 */
export interface HealthCheckResult {
  /** 未注册包的相对路径列表（磁盘有 .pack，DB 无对应 uuid 记录） */
  unregisteredPacks: string[]
  /** 已删除包列表（DB 有记录，磁盘无对应 .pack 目录） */
  deletedPackages: PackageInfo[]
  /** 路径不一致列表（uuid 在 DB 存在但 dirPath 与磁盘不符） */
  pathMismatched: PathMismatchItem[]
  /** 未解析双链数量（links 表 targetPackageUuid 为 NULL） */
  orphanLinksCount: number
  /** 主文件缺失的包列表（mainFile 不为空但文件不存在，不自动修复） */
  missingMainFiles: PackageInfo[]
  /** 损坏的共享资源引用列表（P0-4.4，资源被引用但磁盘文件缺失） */
  brokenResourceRefs: BrokenResourceRefItem[]
  /** 孤立共享资源列表（P0-4.4，资源存在但无任何包引用） */
  orphanResources: OrphanResourceItem[]
}

// ======================== 共享片段（P0-2） ========================

/**
 * 共享片段逻辑信息 — 身份稳定，不随内容变化
 *
 * `fragmentId` 由调用方生成（前端 `crypto.randomUUID()`），全局唯一。
 * 内容更新时 fragmentId 不变，新增版本行，currentVersion 递增。
 */
export interface SharedFragmentInfo {
  /** 逻辑 UUID（全局稳定，不随内容更新变化） */
  fragmentId: string
  /** 所属库 ID（库隔离） */
  libraryId: number
  /** 显示名（用于 UI 展示） */
  displayName: string
  /** 当前版本号（指向最新版本，update 时递增） */
  currentVersion: number
  /** 创建时间，ISO 8601 */
  createdAt: string
  /** 最后更新时间，ISO 8601 */
  updatedAt: string
}

/** 共享片段内容 — `getSharedFragment` 返回，含具体 content */
export interface SharedFragmentContent {
  /** 片段逻辑 ID */
  fragmentId: string
  /** 实际返回的版本号（currentVersion 或 lockedVersion） */
  version: number
  /** 内容 SHA-256 哈希（内容寻址） */
  contentHash: string
  /** 片段实际内容 */
  content: string
  /** 该版本的创建时间，ISO 8601 */
  createdAt: string
}

/** 版本历史条目 — `listFragmentVersions` 返回，不含 content 节省流量 */
export interface FragmentVersionInfo {
  /** 版本号 */
  version: number
  /** 内容 SHA-256 哈希 */
  contentHash: string
  /** 该版本创建时间，ISO 8601 */
  createdAt: string
}

/** 包引用记录 — 描述某包如何引用一个共享片段 */
export interface PackageSharedRef {
  /** 引用方包 UUID */
  packageUuid: string
  /** 引用所在 markdown 文件（相对包目录 POSIX 路径，如 "main.md"）；空串=历史未知来源 */
  sourceFile?: string
  /** 被引用的片段逻辑 ID */
  fragmentId: string
  /** 锁定版本号：null=跟随最新版本；number=锁定到该版本 */
  lockedVersion: number | null
  /** 显示名（包内自定义） */
  displayName: string
  /** 排序权重 */
  sortOrder: number
  /** 引用创建时间，ISO 8601 */
  createdAt: string
}

/** 设置包引用的入参 — `setPackageSharedRefs` 调用 */
export interface SharedRefParam {
  /** 片段逻辑 ID */
  fragmentId: string
  /** 锁定版本号：null=跟随最新；number=锁定到该版本 */
  lockedVersion?: number | null
  /** 显示名（包内自定义） */
  displayName: string
  /** 排序权重，默认 0 */
  sortOrder?: number
}

/** 创建共享片段入参 — `createSharedFragment` 调用 */
export interface CreateSharedFragmentParams {
  /** 逻辑 UUID（调用方生成，如 `crypto.randomUUID()`） */
  fragmentId: string
  /** 片段初始内容 */
  content: string
  /** 显示名 */
  displayName: string
}

/** 删除共享片段结果 — 被引用时拒绝，返回引用列表 */
export interface DeleteSharedFragmentResult {
  /** 是否已删除（false 表示被引用拒绝） */
  deleted: boolean
  /** 阻止删除的引用列表（deleted=false 时填充） */
  blockingRefs: PackageSharedRef[]
}

// ======================== 共享资源（P0-4） ========================

/**
 * 共享资源信息 — 描述一个入库的二进制资源（内容寻址，无版本链）
 *
 * `hash` 由调用方计算（前端 `crypto.subtle.digest` 或 Rust 端 `util::compute_hash`），
 * 全局唯一（同内容只存一份）。文件系统路径为 `.shared/<hash前16位>.<扩展名>`。
 *
 * 与 P0-2 共享片段的关键差异：
 * - 无版本链：资源替换即覆盖（片段是版本递增）
 * - 文件系统存储：二进制存于 `.shared/` 目录，DB 仅存元数据 + 引用关系
 * - 标准 markdown 引用语法 `![](.shared/xxx)`
 */
export interface SharedResourceInfo {
  /** SHA-256 hex（64 字符）— 主键 */
  hash: string
  /** 所属库 ID（库隔离） */
  libraryId: number
  /** 原始文件名（UI 显示用，文件系统不用） */
  originalName: string
  /** 字节大小 */
  fileSize: number
  /** MIME 类型（如 "image/png"），可为 null */
  mimeType: string | null
  /** 相对库根的存储路径（如 ".shared/a1b2c3d4e5f6g7h8.png"） */
  storagePath: string
  /** 注册时间，ISO 8601 */
  createdAt: string
}

/** 包→资源 引用记录 — 描述某包如何引用一个共享资源 */
export interface PackageResourceRef {
  /** 引用方包 UUID */
  packageUuid: string
  /** 引用所在 markdown 文件（相对包目录 POSIX 路径，如 "main.md"）；空串=历史未知来源 */
  sourceFile?: string
  /** 被引用的资源 hash */
  resourceHash: string
  /** markdown 中引用的相对路径（如 ".shared/a1b2c3d4e5f6g7h8.png"） */
  refPath: string
  /** 引用类型："image" / "attachment" / "link" */
  refType: string
  /** 引用创建时间，ISO 8601 */
  createdAt: string
}

/** 设置包资源引用的入参 — `setPackageResourceRefs` 调用 */
export interface ResourceRefParam {
  /** 资源 SHA-256 hash */
  resourceHash: string
  /** markdown 中引用的相对路径 */
  refPath: string
  /** 引用类型："image" / "attachment" / "link" */
  refType: string
}

/** 创建共享资源入参 — `registerSharedResource` 调用 */
export interface CreateSharedResourceParams {
  /** SHA-256 hex（调用方计算） */
  hash: string
  /** 原始文件名 */
  originalName: string
  /** 字节大小 */
  fileSize: number
  /** MIME 类型，可为 null */
  mimeType?: string | null
  /** 相对库根的存储路径 */
  storagePath: string
}

/** 删除共享资源结果 — 被引用时拒绝，返回引用列表 */
export interface DeleteSharedResourceResult {
  /** 是否已删除（false 表示被引用拒绝） */
  deleted: boolean
  /** 阻止删除的引用列表（deleted=false 时填充） */
  blockingRefs: PackageResourceRef[]
}

/** 反向引用查询结果 — `getResourceRefs` 返回，含引用方包信息 */
export interface ResourceRefInfo {
  /** 引用方包 UUID */
  packageUuid: string
  /** 引用方包标题（包已删除时为空字符串） */
  packageTitle: string
  /** 引用所在 markdown 文件（相对包目录 POSIX 路径）；空串=历史未知来源 */
  sourceFile?: string
  /** 资源 hash */
  resourceHash: string
  /** markdown 中引用的相对路径 */
  refPath: string
  /** 引用类型："image" / "attachment" / "link" */
  refType: string
  /** 引用创建时间，ISO 8601 */
  createdAt: string
}

// ======================== CSS 样式（P-CSS） ========================

/**
 * CSS 样式作用域
 * - "public"：公共样式，存储在库根 `.gewu/styles/` 目录，全库可用
 * - "private"：私有样式，存储在 `.pack/styles/` 子目录，仅本包可用
 */
export type CssStyleScope = "public" | "private"

/**
 * CSS 样式信息 — 公共样式或 .pack 私有样式
 *
 * 对应 `css_styles` 表一行记录。DB 表是文件系统（`.gewu/styles/` 与 `.pack/styles/`）的缓存索引，
 * 真相源是磁盘上的 CSS 文件，DB 仅加速查询。
 *
 * 公共样式由 `scanPublicCssStyles` 全量同步；私有样式由 `registerPackage` 同步。
 * `contentHash` 用于变更检测（文件修改后重新计算 hash 并更新 DB）。
 * `isBuiltin` 标记系统自带样式（首次启动初始化），用户不可删除。
 */
export interface CssStyleInfo {
  /** 样式 ID（同库同 scope 下唯一，如 "builtin-gongwen" 或 "private-1"） */
  id: string
  /** 所属库 ID */
  libraryId: number
  /** 样式名（UI 展示用，如「公文」） */
  name: string
  /** 描述（可空） */
  description?: string | null
  /** 分类（可空，如「内置」/「公文」/「论文」） */
  category?: string | null
  /** 作用域："public" 或 "private" */
  scope: CssStyleScope
  /** scope="private" 时关联的包 UUID；scope="public" 时为 null */
  packageUuid?: string | null
  /**
   * CSS 文件相对库根的路径
   * 公共样式如 `.gewu/styles/builtin-gongwen.css`，私有样式如 `my-pack.pack/styles/private-1.css`
   */
  sourcePath: string
  /** 是否内置样式（系统自带，用户不可删除） */
  isBuiltin: boolean
  /** CSS 内容 SHA-256 hash，用于变更检测 */
  contentHash?: string | null
  /** 创建时间，ISO 8601 */
  createdAt: string
  /** 最后更新时间，ISO 8601 */
  updatedAt: string
}

/**
 * 保存 CSS 样式入参 — `saveCssStyle` 调用
 *
 * 调用方提供 CSS 内容（`content`），Tauri 端负责：
 * 1. 写入文件到 `sourcePath`（绝对路径由库根 + sourcePath 拼接，自动创建父目录）
 * 2. 调 Rust 端计算 SHA-256 hash 并 INSERT OR REPLACE 到 css_styles 表
 * 3. DB 失败时回滚删除刚写的文件
 *
 * `isBuiltin` 省略时默认 false（用户创建）；首次初始化内置样式时传 true。
 */
export interface SaveCssStyleParams {
  /** 样式 ID（同库同 scope 下唯一） */
  id: string
  /** 样式名 */
  name: string
  /** 描述（可空） */
  description?: string | null
  /** 分类（可空） */
  category?: string | null
  /** 作用域："public" 或 "private" */
  scope: CssStyleScope
  /** scope="private" 时必填，关联的包 UUID */
  packageUuid?: string | null
  /** CSS 文件相对库根的路径 */
  sourcePath: string
  /** CSS 内容 */
  content: string
  /** 是否内置样式（首次初始化时为 true，用户创建为 false）；省略时按 false 处理 */
  isBuiltin?: boolean
}

/**
 * .pack 当前选中的 CSS 样式引用
 *
 * `styleType` + `id` 同时为 null 表示「不使用样式」（清空 active_style）。
 * `styleType="public"` + `id="builtin-gongwen"` 表示使用公共样式「公文」。
 * `styleType="private"` + `id="private-1"` 表示使用本包私有样式。
 */
export interface ActiveStyle {
  /** 样式类型："public" 或 "private"；null 表示不使用样式 */
  styleType?: "public" | "private" | null
  /** 样式 ID；null 表示不使用样式 */
  id?: string | null
}

/**
 * .packmeta.json 中 `private_styles[]` 元素的 IPC 层映射
 *
 * `file` 字段是相对包目录的路径（如 `styles/private-1.css`）。
 * 扫描 .pack 时从 .packmeta.json 解析后传给 `registerPackage`，由 Rust 端同步到 css_styles 表。
 */
export interface PrivateStyleMeta {
  /** 样式 ID（包内唯一） */
  id: string
  /** 样式名 */
  name: string
  /** 描述（可空） */
  description?: string | null
  /** CSS 文件相对包目录的路径（如 `styles/private-1.css`） */
  file: string
  /** 创建时间，ISO 8601 */
  createdAt: string
  /** 最后更新时间，ISO 8601 */
  updatedAt: string
}

/**
 * CSS 样式扫描结果 — `scanPublicCssStyles` 返回值
 *
 * 同步 `.gewu/styles/` 目录到 DB 的执行统计。私有样式由 `registerPackage` 同步，不在此扫描。
 */
export interface CssStyleScanResult {
  /** 新注册的样式数（DB 无此 ID） */
  registered: number
  /** 已存在但被刷新的样式数（hash 变化或元数据更新） */
  updated: number
  /** 已删除的样式数（DB 有但 .gewu/styles/ 中不存在，内置样式除外） */
  deleted: number
  /** 扫描耗时（毫秒） */
  durationMs: number
}

// ======================== 邮件收件箱（mail-inbox-spec.md 阶段 1） ========================

/**
 * 邮件附件元数据 — 附件本体已在 Rust 侧落盘 `.shared/` 并注册 DB
 *
 * 前端直接使用 `refPath`（`.shared/<hash前16>.<ext>`）生成 markdown 引用。
 */
export interface MailAttachment {
  /** sha256 hex（64 位） */
  hash: string
  /** 处理后的文件名（已清洗 Windows 非法字符/兜底扩展名） */
  filename: string
  /** MIME 类型 */
  mime: string
  /** 字节大小 */
  size: number
  /** 内嵌图片 Content-ID（不带尖括号），非内嵌附件为 null；用于 cid: 引用改写 */
  cid: string | null
  /** markdown 引用路径，如 `.shared/a1b2c3d4e5f6g7h8.png` */
  refPath: string
}

/**
 * 待落盘邮件草稿 — `mailFetch` 返回的单封邮件
 *
 * 正文：`bodyHtml` 优先（前端 turndown 转 Markdown），无 HTML 时用 `bodyText`。
 */
export interface MailDraft {
  /** Message-ID（缺失时 Rust 侧用内容 hash 兜底，已稳定） */
  messageId: string
  /** messageId 派生短哈希（8 位 hex）— 落盘文件名幂等后缀 */
  shortHash: string
  /** messageId 派生的确定性 UUID（v5）— .packmeta.json 的 id 字段 */
  packId: string
  /** 邮件主题（可能为空串，落盘时兜底「无主题」） */
  subject: string
  /** 发件人显示串，如 `张三 <zhang@x.com>` */
  fromAddr: string
  /** 邮件 Date 头（UTC ISO 字符串） */
  dateSent: string
  /** HTML 正文（优先使用） */
  bodyHtml: string | null
  /** 纯文本正文（bodyHtml 为 null 时的 fallback） */
  bodyText: string | null
  /** 附件集合；非空 → 落盘为 .pack 知识包，空 → 单个 md 文件 */
  attachments: MailAttachment[]
  /** 来源 IMAP 文件夹显示名（多文件夹收取时决定落盘子目录；INBOX 落收件箱根） */
  imapFolderDisplay: string
}

/** 单封邮件失败项 — 已在 DB 登记 failed，重收时自动重试 */
export interface MailErrorItem {
  subject: string
  error: string
}

/** 一次邮件收取的汇总结果 */
export interface MailFetchResult {
  /** 待落盘邮件（前端逐封处理后调 `mailSaveResult` 回写） */
  drafts: MailDraft[]
  /** 已收取跳过数（status=saved，永久去重） */
  skipped: number
  /** 失败项（主题 + 原因） */
  errors: MailErrorItem[]
}

/**
 * 邮箱账号配置 — v12 起存 mail_accounts 表，按收件箱 folder_uuid 一对一
 *
 * 授权码不落 DB，存 Windows 凭据管理器（条目名 = folder_uuid），经 `mailCredentialSet` 单独写入。
 */
export interface MailAccount {
  /** 自增主键 */
  id: number
  /** 绑定的收件箱文件夹 uuid（UNIQUE，一个收件箱至多一个邮箱） */
  folderUuid: string
  /** IMAP 服务器地址，如 imap.qq.com */
  host: string
  /** IMAP 端口（0/缺省回退 993） */
  port: number
  /** 是否 SSL */
  ssl: boolean
  /** 登录账号（邮箱地址） */
  mailUser: string
  /** IMAP 文件夹名（缺省 INBOX） */
  imapFolder: string
  /** 单次收取上限（0/缺省回退 200） */
  fetchLimit: number
  /** 收取过滤：仅未读（IMAP UNSEEN） */
  unseenOnly: boolean
  /** 收取过滤：最近 N 天（0 = 不限） */
  sinceDays: number
  /** 收取过滤：关键词（发件人或主题匹配，空串 = 不过滤） */
  keyword: string
  /** 勾选收取的 IMAP 文件夹映射（空数组 = 仅收 imapFolder） */
  imapFolders: ImapFolderMapping[]
}

/** IMAP 文件夹 → 本地子目录映射（存 mail_accounts.imap_folders JSON 列） */
export interface ImapFolderMapping {
  /** IMAP 文件夹原始名（modified UTF-7，SELECT 时用此值） */
  name: string
  /** 落盘子目录名（空串 = 自动模式：INBOX 落根目录，其余用文件夹显示名） */
  subdir: string
}

/** IMAP 文件夹（LIST 结果项）— name 用于 SELECT，displayName 用于展示与落盘子目录名 */
export interface ImapFolderInfo {
  /** LIST 原始名（SELECT 时必须用此值，可能为 modified UTF-7 编码） */
  name: string
  /** 解码后的 UTF-8 显示名（如「已发送」） */
  displayName: string
  /** 层级分隔符（如 / 或 .，可能为空） */
  delimiter?: string | null
}