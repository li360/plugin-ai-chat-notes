/**
 * kmgr-api 请求参数类型
 * 所有 API 方法的入参，纯 DTO，不含业务逻辑。
 */

/** 初始化知识库参数 */
export interface InitializeParams {
  /** 知识库名称 */
  name: string
  /** SQLite 数据库文件存放目录（绝对路径，可含 %USERPROFILE% 等系统变量） */
  path: string
  /** 用户输入的原始路径形式（可含 %VAR% 系统变量），用于换机/换用户名时精确识别同位置 */
  pathOriginal?: string
}

/** 添加的单个文件描述 */
export interface AddFileItem {
  /** 文件绝对路径 */
  path: string
  /** 可选：指定所属分类 ID */
  categoryId?: number
  /** 可选：指定初始标签 ID 列表 */
  tags?: number[]
}

/** 添加文件参数 */
export interface AddFilesParams {
  /** 待添加的文件列表 */
  files: AddFileItem[]
}

/** 导入目录参数 */
export interface ImportDirectoryParams {
  /** 目录绝对路径 */
  path: string
  /** 是否递归子目录 */
  recursive: boolean
  /** 是否按子目录结构自动创建分类层级 */
  createCategories: boolean
  /** 限定文件扩展名（白名单），如 [".ts", ".rs"]，不传则全部索引 */
  extensions?: string[]
  /** 忽略的路径模式，如 ["node_modules", ".git"] */
  ignorePaths?: string[]
}

/** 文件列表查询参数 — 所有条件可组合使用 */
export interface ListFilesParams {
  /** 按分类筛选 */
  categoryId?: number
  /** 按标签筛选（多个标签的逻辑关系由 tagMode 控制） */
  tags?: number[]
  /** 标签筛选模式：and=同时满足，or=满足任一，默认 and */
  tagMode?: "and" | "or"
  /** 按扩展名筛选，如 ".rs" */
  ext?: string
  /** 按创建时间起始范围，ISO 8601 */
  dateFrom?: string
  /** 按创建时间结束范围，ISO 8601 */
  dateTo?: string
  /** 排序字段 */
  sort?: import("./types").ListSort
  /** 页码，从 1 开始 */
  page?: number
  /** 每页条数，默认 50 */
  pageSize?: number
}

/** 文件搜索参数 */
export interface SearchFilesParams {
  /** 搜索关键词 */
  query: string
  /** 搜索范围：name=文件名，content=文件内容，all=全部，默认 all */
  scope?: "name" | "content" | "all"
  page?: number
  pageSize?: number
}

/** 文件更新补丁 — 只传需要修改的字段 */
export interface UpdateFilePatch {
  /** 移动文件到指定分类，null 移到根 */
  categoryId?: number | null
  /** 文件系统路径（文件移动/重命名后同步索引） */
  path?: string
}

/** 创建分类参数 */
export interface CreateCategoryParams {
  /** 唯一标识名（英文），如 "project-a" */
  name: string
  /** 展示名称（中文），如 "项目A"，不传则取 name */
  displayName?: string
  /** 父分类 ID，null 或 不传 为根分类 */
  parentId?: number | null
  /** 排序权重，越小越靠前 */
  sortOrder?: number
}

/** 分类更新补丁 */
export interface UpdateCategoryPatch {
  /** 新唯一标识名 */
  name?: string
  /** 新展示名称 */
  displayName?: string
  /** 新排序权重 */
  sortOrder?: number
}

/** 排序项 — 拖拽重排时传递完整顺序列表 */
export interface ReorderItem {
  /** 分类/标签 ID */
  id: number
  /** 新的排序权重 */
  sortOrder: number
}

/** 创建标签参数 */
export interface CreateTagParams {
  /** 唯一标签名，如 "rust" */
  name: string
  /** 父标签 ID，null 或 不传 为根标签 */
  parentId?: number | null
  /** 标签颜色，如 "#ff4757" */
  color?: string
  /** 标签图标（emoji），如 "🦀" */
  icon?: string
  /** 排序权重 */
  sortOrder?: number
}

/** 标签更新补丁 */
export interface UpdateTagPatch {
  /** 新标签名 */
  name?: string
  /** 新的父标签（null 移到根） */
  parentId?: number | null
  /** 新颜色（null 清除颜色） */
  color?: string | null
  /** 新图标（null 清除图标） */
  icon?: string | null
  /** 新排序权重 */
  sortOrder?: number
}