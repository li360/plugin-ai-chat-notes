/**
 * kmgr-api Tauri IPC 实现层
 * 通过 @tauri-apps/api 的 invoke 调用 Rust 后端命令
 */
import { invoke } from "@tauri-apps/api/core"
import type {
  BacklinkItem,
  Category,
  CategoryNode,
  DeleteMode,
  DirectoryEntry,
  Distribution,
  DistributionType,
  FileInfo,
  FolderInfo,
  FolderType,
  FilePackageResolve,
  FragmentInfo,
  FragmentParam,
  HealthCheckResult,
  ImportResult,
  KnowledgeBase,
  KnowledgeBaseInfo,
  LibraryEntry,
  LibraryInfo,
  LinkGraph,
  LinkRecord,
  PackageInfo,
  PackageScanResult,
  PackageSearchResult,
  PaginatedResult,
  PathClassify,
  PluginData,
  RegisterPackageParams,
  RescanResult,
  ApplyRescanParams,
  SearchResultItem,
  Setting,
  FileGeo,
  FileGeoPoint,
  UpsertFileGeoParams,
  UpsertFileGeoByPathParams,
  Stats,
  Tag,
  TagNode,
  SharedFragmentInfo,
  SharedFragmentContent,
  FragmentVersionInfo,
  PackageSharedRef,
  SharedRefParam,
  CreateSharedFragmentParams,
  DeleteSharedFragmentResult,
  SharedResourceInfo,
  PackageResourceRef,
  ResourceRefParam,
  CreateSharedResourceParams,
  DeleteSharedResourceResult,
  ResourceRefInfo,
  CssStyleInfo,
  CssStyleScope,
  SaveCssStyleParams,
  ActiveStyle,
  CssStyleScanResult,
  RelocateOutcome,
  BackupInfo,
  FileBackupInfo,
  FileOpEntry,
  FileVersionInfo,
  FileVersionContent,
  DiffLine,
  RecordFileVersionParams,
  MailFetchResult,
  MailAccount,
  ImapFolderInfo,
  ImapFolderMapping,
} from "./types"
import type {
  AddFilesParams,
  CreateCategoryParams,
  CreateTagParams,
  ImportDirectoryParams,
  InitializeParams,
  ListFilesParams,
  ReorderItem,
  SearchFilesParams,
  UpdateCategoryPatch,
  UpdateFilePatch,
  UpdateTagPatch,
} from "./params"
import type { KmgrApi } from "./api"

/**
 * 创建 KmgrApi 实例 — 每个方法对应一个 Tauri command
 */
export function createKmgrApi(): KmgrApi {
  return {
    // ======================== 知识库 ========================

    async initialize(params: InitializeParams): Promise<KnowledgeBase> {
      return invoke("initialize_kb", {
        name: params.name,
        path: params.path,
        path_original: params.pathOriginal,
      })
    },

    async open(path: string): Promise<KnowledgeBase> {
      return invoke("open_kb", { path })
    },

    async getInfo(): Promise<KnowledgeBaseInfo> {
      return invoke("get_kb_info")
    },

    // ======================== 库注册表（App 级） ========================

    async listLibraries(): Promise<LibraryEntry[]> {
      return invoke("list_libraries")
    },

    async addLibrary(entry: { name: string; path: string; type: "local" }): Promise<void> {
      return invoke("add_library", { entry })
    },

    async removeLibrary(path: string): Promise<void> {
      return invoke("remove_library", { path })
    },

    async getLibraryInfo(path: string): Promise<LibraryInfo> {
      return invoke("get_library_info", { path })
    },

    async getAppDataDir(): Promise<string> {
      return invoke("get_app_data_dir")
    },

    async getAppVersion(): Promise<string> {
      return invoke("get_app_version")
    },

    async openDbExternal(): Promise<void> {
      return invoke("open_db_external")
    },

    // ======================== 库内文件夹 ========================

    async listFolders(): Promise<FolderInfo[]> {
      return invoke("list_folders")
    },

    /// 分类路径归属 — 「库内」判定（0.26 新理念）：库内 = 任一注册文件夹内（含收件箱），不含库根
    async classifyPath(path: string): Promise<PathClassify> {
      return invoke("classify_path", { path })
    },

    async createFolder(params: { name: string; path: string; folderType?: FolderType; sortOrder?: number }): Promise<FolderInfo> {
      return invoke("create_folder", { params })
    },

    async updateFolder(id: number, patch: { name?: string; path?: string; folderType?: FolderType; sortOrder?: number }): Promise<FolderInfo> {
      return invoke("update_folder", { id, patch })
    },

    async deleteFolder(id: number): Promise<void> {
      return invoke("delete_folder", { id })
    },

    /// 移动文件夹（应用内移动）— 物理移动 + 事务化 DB 更新（v7 文件夹自治）
    async moveFolder(folderId: number, newPath: string): Promise<FolderInfo> {
      return invoke("move_folder", { folderId, newPath })
    },

    /// 重新定位文件夹（应用外移动后）— 仅改 DB 指针（v7 文件夹自治 S3）
    async relocateFolder(folderId: number, newPath: string, force?: boolean): Promise<RelocateOutcome> {
      return invoke("relocate_folder", { folderId, newPath, force: force ?? false })
    },

    /// 统计文件夹登记的包数量（relocate 强制确认弹窗显示「N 个包」）
    async countFolderPackages(folderId: number): Promise<number> {
      return invoke("count_folder_packages", { folderId })
    },

    /// 为缺失身份的文件夹补 `.gewu/folder.json` 并回填 folder_uuid（S4 迁移工具）
    async ensureFolderIdentities(): Promise<number> {
      return invoke("ensure_folder_identities")
    },

    /// 列出库根直属包（S4 库根纯索引清单视图）— `folder_id IS NULL` 的包
    async listRootPackages(): Promise<PackageInfo[]> {
      return invoke("list_root_packages")
    },

    /// 备份数据库到库根 `.gewu/backup-<时间戳>/`（S4 迁移工具前置保护）
    async backupDatabase(): Promise<string> {
      return invoke("backup_database")
    },

    /// 列出库根 `.gewu/backup-*` 备份目录（备份中心数据源，按时间倒序）
    async listBackups(): Promise<BackupInfo[]> {
      return invoke("list_backups")
    },

    // ======================== 文件级留档（回收站 / 版本历史，v0.26.5） ========================

    /// 删除保护 — 把文件/目录移入应用内回收站（.gewu/trash/）并记录
    async trashToLibrary(path: string): Promise<FileBackupInfo> {
      return invoke("trash_to_library", { path })
    },

    /// 修改保护 — 覆盖保存前把文本类旧文件复制到 .gewu/versions/ 并记录（新建/非文本返回 null）
    async backupFileVersion(path: string): Promise<FileBackupInfo | null> {
      return invoke("backup_file_version", { path })
    },

    /// 列出文件留档记录（kind: 省略/undefined=全部；"trash"/"version" 过滤）
    async listFileBackups(kind?: "trash" | "version" | null): Promise<FileBackupInfo[]> {
      return invoke("list_file_backups", { kind: kind ?? null })
    },

    /// 恢复文件留档（trash=移回原路径；version=内容写回覆盖当前文件）
    async restoreFileBackup(id: number): Promise<void> {
      return invoke("restore_file_backup", { id })
    },

    /// 永久删除文件留档（删磁盘 + 删记录，不可撤销）
    async deleteFileBackup(id: number): Promise<void> {
      return invoke("delete_file_backup", { id })
    },

    /// 清理过期文件留档（应用启动时自动调用）— 返回清理条数
    async cleanupExpiredBackups(): Promise<number> {
      return invoke("cleanup_expired_backups")
    },

    /// 读取文件操作日志（「设置 → 日志 → 文件操作」数据源）— 支持按操作类型/关键字过滤
    async readFileOpsLog(filter?: { op?: string; keyword?: string; limit?: number }): Promise<FileOpEntry[]> {
      return invoke("read_file_ops_log", {
        filter_op: filter?.op,
        keyword: filter?.keyword,
        limit: filter?.limit,
      })
    },

    async reorderFolders(items: { id: number; sortOrder: number }[]): Promise<void> {
      return invoke("reorder_folders", { input: { items } })
    },

    // ======================== 文件系统浏览 ========================

    async listDirectory(path: string, recursive?: boolean): Promise<DirectoryEntry[]> {
      return invoke("list_directory", { path, recursive })
    },

    async createFile(path: string, content?: string): Promise<void> {
      return invoke("create_file", { path, content })
    },

    async readTextFile(path: string): Promise<string> {
      return invoke("read_text_file", { path })
    },

    async readFileBytes(path: string): Promise<Uint8Array> {
      const base64: string = await invoke("read_file_bytes", { path })
      const binary = atob(base64)
      const bytes = new Uint8Array(binary.length)
      for (let i = 0; i < binary.length; i++) {
        bytes[i] = binary.charCodeAt(i)
      }
      return bytes
    },

    async writeTextFile(path: string, content: string): Promise<void> {
      return invoke("write_text_file", { path, content })
    },

    // ======================== 文件时间线（版本历史 + diff + 恢复） ========================

    async recordFileVersion(params: RecordFileVersionParams): Promise<FileVersionInfo | null> {
      return invoke("record_file_version", { params })
    },

    async listFileVersions(fileId: number): Promise<FileVersionInfo[]> {
      return invoke("list_file_versions", { fileId })
    },

    async getFileVersion(fileId: number, version: number): Promise<FileVersionContent> {
      return invoke("get_file_version", { fileId, version })
    },

    async getFileVersionDiff(
      fileId: number,
      version: number,
      currentContent?: string,
    ): Promise<DiffLine[]> {
      return invoke("get_file_version_diff", {
        fileId,
        version,
        currentContent: currentContent ?? null,
      })
    },

    async restoreFileVersion(fileId: number, version: number): Promise<FileVersionInfo> {
      return invoke("restore_file_version", { fileId, version })
    },

    async deleteFileVersion(fileId: number, version: number): Promise<void> {
      return invoke("delete_file_version", { fileId, version })
    },

    async pruneFileVersions(fileId: number, keepLatest: number): Promise<number> {
      return invoke("prune_file_versions", { fileId, keepLatest })
    },

    /// 全库批量清理（T14）— 每个仍存在的文件保留最近 N 个版本
    async pruneAllFileVersions(keepLatest: number): Promise<number> {
      return invoke("prune_all_file_versions", { keepLatest })
    },

    /// 在磁盘上创建目录（递归创建父目录）
    async createDirectory(path: string): Promise<void> {
      return invoke("create_directory", { path })
    },

    /// 在磁盘上重命名文件
    async renameFile(oldPath: string, newPath: string): Promise<void> {
      return invoke("rename_file", { oldPath, newPath })
    },

    /// 在磁盘上删除文件
    async deleteFile(path: string): Promise<void> {
      return invoke("delete_file", { path })
    },

    /// 复制文件或目录（支持递归复制目录）
    async copyPath(src: string, dest: string, overwrite?: boolean): Promise<void> {
      return invoke("copy_path", { src, dest, overwrite })
    },

    /// 移动文件或目录（支持跨磁盘）
    async movePath(src: string, dest: string): Promise<void> {
      return invoke("move_path", { src, dest })
    },

    /// 删除文件或目录（目录递归删除）
    async deletePath(path: string): Promise<void> {
      return invoke("delete_path", { path })
    },

    /// 移到回收站（可恢复，跨平台）
    async trashPath(path: string): Promise<void> {
      return invoke("trash_path", { path })
    },

    /// 目录移动后批量同步数据库索引路径
    async syncPathsAfterMove(oldPrefix: string, newPrefix: string): Promise<number> {
      return invoke("sync_paths_after_move", { oldPrefix, newPrefix })
    },

    /// 按文件系统路径查找 kmgr 文件记录
    async getFileByPath(path: string): Promise<FileInfo | null> {
      return invoke("get_file_by_path", { path })
    },

    // ======================== 文件导入 ========================

    async addFiles(params: AddFilesParams): Promise<FileInfo[]> {
      return invoke("add_files", {
        params: {
          items: params.files.map((f) => ({
            path: f.path,
            category_id: f.categoryId ?? null,
            tag_ids: f.tags ?? null,
          })),
        },
      })
    },

    async importDirectory(params: ImportDirectoryParams): Promise<ImportResult> {
      return invoke("import_directory", {
        params: {
          path: params.path,
          recursive: params.recursive,
          create_categories: params.createCategories,
          extensions: params.extensions ?? null,
          ignore_paths: params.ignorePaths ?? null,
        },
      })
    },

    async rescan(): Promise<RescanResult> {
      return invoke("rescan")
    },

    async detectChanges(): Promise<RescanResult> {
      return invoke("detect_changes")
    },

    async applyRescan(params: ApplyRescanParams): Promise<RescanResult> {
      return invoke("apply_rescan", { params })
    },

    // ======================== 文件读写 ========================

    async listFiles(params: ListFilesParams): Promise<PaginatedResult<FileInfo>> {
      return invoke("list_files", {
        params: {
          category_id: params.categoryId ?? null,
          tags: params.tags ?? null,
          tag_mode: params.tagMode ?? null,
          ext: params.ext ?? null,
          date_from: params.dateFrom ?? null,
          date_to: params.dateTo ?? null,
          sort: params.sort ?? null,
          page: params.page ?? 1,
          page_size: params.pageSize ?? 50,
        },
      })
    },

    async searchFiles(params: SearchFilesParams): Promise<SearchResultItem[]> {
      return invoke("search_files", {
        params: {
          query: params.query,
          scope: params.scope ?? "all",
          page: params.page ?? 1,
          page_size: params.pageSize ?? 50,
        },
      })
    },

    async getFile(id: number): Promise<FileInfo | null> {
      return invoke("get_file", { id })
    },

    async updateFile(id: number, patch: UpdateFilePatch): Promise<FileInfo> {
      return invoke("update_file", {
        id,
        patch: {
          category_id: patch.categoryId ?? null,
        },
      })
    },

    async removeFiles(ids: number[]): Promise<number> {
      return invoke("remove_files", { ids })
    },

    async getRecentFiles(limit: number): Promise<FileInfo[]> {
      return invoke("get_recent_files", { limit })
    },

    // ======================== 分类 ========================

    async listCategories(): Promise<Category[]> {
      return invoke("list_categories")
    },

    async getCategoryTree(): Promise<CategoryNode[]> {
      return invoke("get_category_tree")
    },

    async createCategory(params: CreateCategoryParams): Promise<Category> {
      return invoke("create_category", {
        params: {
          name: params.name,
          display_name: params.displayName ?? params.name,
          parent_id: params.parentId ?? null,
          sort_order: params.sortOrder ?? null,
        },
      })
    },

    async updateCategory(id: number, patch: UpdateCategoryPatch): Promise<Category> {
      return invoke("update_category", {
        id,
        patch: {
          name: patch.name ?? null,
          display_name: patch.displayName ?? null,
          sort_order: patch.sortOrder ?? null,
        },
      })
    },

    async deleteCategory(id: number, mode: DeleteMode): Promise<void> {
      return invoke("delete_category", { id, mode })
    },

    async reorderCategories(items: ReorderItem[]): Promise<void> {
      // Rust 端期望 Vec<(i64, i64)> 即元组数组 [[id, sort_order]]
      return invoke("reorder_categories", {
        items: items.map((i) => [i.id, i.sortOrder]),
      })
    },

    // ======================== 标签 ========================

    async listTags(): Promise<Tag[]> {
      return invoke("list_tags")
    },

    async getTagTree(): Promise<TagNode[]> {
      return invoke("get_tag_tree")
    },

    async createTag(params: CreateTagParams): Promise<Tag> {
      return invoke("create_tag", {
        params: {
          name: params.name,
          parent_id: params.parentId ?? null,
          color: params.color ?? null,
          icon: params.icon ?? null,
          sort_order: params.sortOrder ?? null,
        },
      })
    },

    async updateTag(id: number, patch: UpdateTagPatch): Promise<Tag> {
      return invoke("update_tag", {
        id,
        patch: {
          name: patch.name ?? null,
          parent_id: patch.parentId ?? null,
          color: patch.color ?? null,
          icon: patch.icon ?? null,
          sort_order: patch.sortOrder ?? null,
        },
      })
    },

    async deleteTag(id: number): Promise<void> {
      return invoke("delete_tag", { id })
    },

    async setFileTags(fileIds: number[], tagIds: number[]): Promise<void> {
      return invoke("set_file_tags", { fileIds, tagIds })
    },

    async removeFileTags(fileIds: number[], tagIds: number[]): Promise<void> {
      return invoke("remove_file_tags", { fileIds, tagIds })
    },

    async getFileTags(fileId: number): Promise<Tag[]> {
      return invoke("get_file_tags", { fileId })
    },

    // ======================== 统计 ========================

    async getStats(): Promise<Stats> {
      return invoke("get_stats")
    },

    async getDistribution(type: DistributionType): Promise<Distribution> {
      return invoke("get_distribution", { type })
    },

    // ======================== 配置 ========================

    async getSetting(key: string): Promise<Setting | null> {
      return invoke("get_setting", { key })
    },

    async setSetting(key: string, value: unknown): Promise<void> {
      return invoke("set_setting", { key, value })
    },

    async listSettings(): Promise<Setting[]> {
      return invoke("list_settings")
    },

    // ======================== 文件地理信息（地图模块） ========================

    async upsertFileGeo(params: UpsertFileGeoParams): Promise<void> {
      return invoke("upsert_file_geo", { params })
    },

    async upsertFileGeoByPath(params: UpsertFileGeoByPathParams): Promise<boolean> {
      return invoke("upsert_file_geo_by_path", { params })
    },

    async getFileGeo(fileId: number): Promise<FileGeo | null> {
      return invoke("get_file_geo", { fileId })
    },

    async listFileGeoPoints(): Promise<FileGeoPoint[]> {
      return invoke("list_file_geo_points")
    },

    async deleteFileGeo(fileId: number): Promise<void> {
      return invoke("delete_file_geo", { fileId })
    },

    // ======================== 插件数据 ========================

    async readPluginData(pluginId: string, key: string): Promise<PluginData | null> {
      return invoke("read_plugin_data", { pluginId, key })
    },

    async writePluginData(pluginId: string, key: string, value: unknown): Promise<void> {
      return invoke("write_plugin_data", { pluginId, key, value })
    },

    async listPluginData(pluginId: string): Promise<PluginData[]> {
      return invoke("list_plugin_data", { pluginId })
    },

    async deletePluginData(pluginId: string, key: string): Promise<void> {
      return invoke("delete_plugin_data", { pluginId, key })
    },

    // ======================== 包与双链（Phase 1） ========================

    async searchPackages(query: string): Promise<PackageSearchResult[]> {
      return invoke("search_packages", { query })
    },

    async getPackageByTitle(title: string): Promise<PackageInfo | null> {
      return invoke("get_package_by_title", { title })
    },

    async getPackageByPath(dirPath: string): Promise<PackageInfo | null> {
      return invoke("get_package_by_path", { dirPath })
    },

    /// 按绝对路径查找包（v7 语义，0.26 新理念）— 移动/删除 .pack 前定位 uuid 用
    async getPackageByAbsPath(absPath: string): Promise<PackageInfo | null> {
      return invoke("get_package_by_abs_path", { absPath })
    },

    /// 计算包磁盘绝对路径（v7 语义）— 前端「库根 + dirPath」拼接的统一替代入口
    async getPackageAbsPath(uuid: string): Promise<string | null> {
      return invoke("get_package_abs_path", { uuid })
    },

    async registerPackage(params: RegisterPackageParams): Promise<PackageInfo> {
      return invoke("register_package", { params })
    },

    /// 按绝对路径注册包 — 自动判定「库内」归属（0.26 新理念，2026-08-08）
    /// params.dirPath 传包目录绝对路径，Rust 端判定归属 + 校验库内 + 写 folder_id
    async registerPackageByAbs(params: RegisterPackageParams): Promise<PackageInfo> {
      return invoke("register_package_at_abs", { params })
    },

    /// 移动包（应用内移动）— 按绝对路径自动判定归属 + 计算相对路径（v7 文件夹自治）
    async movePackage(uuid: string, newPath: string): Promise<PackageInfo> {
      return invoke("move_package", { uuid, newPath })
    },

    async deletePackage(uuid: string): Promise<void> {
      return invoke("delete_package", { uuid })
    },

    async healthCheck(): Promise<HealthCheckResult> {
      return invoke("health_check")
    },

    async syncLinks(sourceUuid: string, links: LinkRecord[]): Promise<void> {
      return invoke("sync_links", { sourceUuid, links })
    },

    async getBacklinks(targetUuid: string): Promise<BacklinkItem[]> {
      return invoke("get_backlinks", { targetUuid })
    },

    async resolvePendingLinks(): Promise<number> {
      return invoke("resolve_pending_links")
    },

    async getLinkGraph(): Promise<LinkGraph> {
      return invoke("get_link_graph")
    },

    async scanPackages(): Promise<PackageScanResult> {
      return invoke("scan_packages")
    },

    async scanPackagesInDir(dirPath: string): Promise<PackageScanResult> {
      return invoke("scan_packages_in_dir", { dirPath })
    },

    async resolveFilePackage(filePath: string): Promise<FilePackageResolve | null> {
      return invoke("resolve_file_package", { filePath })
    },

    // ======================== 包片段元数据（P1-5.0 多片段拼接编辑） ========================

    async listPackageFragments(packageUuid: string): Promise<FragmentInfo[]> {
      return invoke("list_package_fragments", { packageUuid })
    },

    async setPackageFragments(packageUuid: string, fragments: FragmentParam[]): Promise<void> {
      return invoke("set_package_fragments", { packageUuid, fragments })
    },

    async reorderPackageFragments(packageUuid: string, orderedIds: string[]): Promise<void> {
      return invoke("reorder_package_fragments", { packageUuid, orderedIds })
    },

    // ======================== 共享片段（P0-2） ========================

    async createSharedFragment(params: CreateSharedFragmentParams): Promise<SharedFragmentInfo> {
      return invoke("create_shared_fragment", { params })
    },

    async updateSharedFragment(fragmentId: string, newContent: string): Promise<SharedFragmentInfo> {
      return invoke("update_shared_fragment", { fragmentId, newContent })
    },

    async getSharedFragment(fragmentId: string, version?: number | null): Promise<SharedFragmentContent | null> {
      return invoke("get_shared_fragment", { fragmentId, version: version ?? null })
    },

    async listSharedFragments(): Promise<SharedFragmentInfo[]> {
      return invoke("list_shared_fragments")
    },

    async listFragmentVersions(fragmentId: string): Promise<FragmentVersionInfo[]> {
      return invoke("list_fragment_versions", { fragmentId })
    },

    async getSharedFragmentRefs(fragmentId: string): Promise<PackageSharedRef[]> {
      return invoke("get_shared_fragment_refs", { fragmentId })
    },

    async setPackageSharedRefs(packageUuid: string, refs: SharedRefParam[]): Promise<void> {
      return invoke("set_package_shared_refs", { packageUuid, refs })
    },

    async replaceFileSharedRefs(
      packageUuid: string,
      sourceFile: string,
      refs: SharedRefParam[],
    ): Promise<void> {
      return invoke("replace_file_shared_refs", { packageUuid, sourceFile, refs })
    },

    async getPackageSharedRefs(packageUuid: string): Promise<PackageSharedRef[]> {
      return invoke("get_package_shared_refs", { packageUuid })
    },

    async setSharedRefLockedVersion(
      packageUuid: string,
      sourceFile: string,
      fragmentId: string,
      lockedVersion: number | null,
    ): Promise<void> {
      return invoke("set_shared_ref_locked_version", {
        packageUuid,
        sourceFile,
        fragmentId,
        lockedVersion,
      })
    },

    async deleteSharedFragment(fragmentId: string): Promise<DeleteSharedFragmentResult> {
      return invoke("delete_shared_fragment", { fragmentId })
    },

    async rollbackFragment(fragmentId: string, targetVersion: number): Promise<SharedFragmentInfo> {
      return invoke("rollback_fragment", { fragmentId, targetVersion })
    },

    // ======================== 共享资源（P0-4） ========================

    async registerSharedResource(params: CreateSharedResourceParams): Promise<SharedResourceInfo> {
      return invoke("register_shared_resource", { params })
    },

    async getSharedResource(hash: string): Promise<SharedResourceInfo | null> {
      return invoke("get_shared_resource", { hash })
    },

    async listSharedResources(): Promise<SharedResourceInfo[]> {
      return invoke("list_shared_resources")
    },

    async setPackageResourceRefs(packageUuid: string, refs: ResourceRefParam[]): Promise<void> {
      return invoke("set_package_resource_refs", { packageUuid, refs })
    },

    async replaceFileResourceRefs(
      packageUuid: string,
      sourceFile: string,
      refs: ResourceRefParam[],
    ): Promise<void> {
      return invoke("replace_file_resource_refs", { packageUuid, sourceFile, refs })
    },

    async getPackageResourceRefs(packageUuid: string): Promise<PackageResourceRef[]> {
      return invoke("get_package_resource_refs", { packageUuid })
    },

    async getResourceRefs(hash: string): Promise<ResourceRefInfo[]> {
      return invoke("get_resource_refs", { hash })
    },

    async deleteSharedResource(hash: string): Promise<DeleteSharedResourceResult> {
      return invoke("delete_shared_resource", { hash })
    },

    async repairResourceRefs(hash: string, newStoragePath: string): Promise<number> {
      return invoke("repair_resource_refs", { hash, newStoragePath })
    },

    async updateSharedResourceMeta(hash: string, newOriginalName: string): Promise<SharedResourceInfo> {
      return invoke("update_shared_resource_meta", { hash, newOriginalName })
    },

    // ======================== CSS 样式（P-CSS） ========================

    async saveCssStyle(params: SaveCssStyleParams): Promise<CssStyleInfo> {
      return invoke("save_css_style", { params })
    },

    async getCssStyle(scope: CssStyleScope, id: string): Promise<CssStyleInfo | null> {
      return invoke("get_css_style", { scope, id })
    },

    /// 按 scope + id 计算样式文件绝对路径 — v7 文件夹自治语义
    /// 读取/导出 CSS 内容时调用，替代「库根 + sourcePath」手工拼接（注册文件夹内包路径正确）
    async getCssStyleAbsPath(scope: CssStyleScope, id: string): Promise<string> {
      return invoke("get_css_style_abs_path", { scope, id })
    },

    async listPublicCssStyles(): Promise<CssStyleInfo[]> {
      return invoke("list_public_css_styles")
    },

    async listPackageCssStyles(packageUuid: string): Promise<CssStyleInfo[]> {
      return invoke("list_package_css_styles", { packageUuid })
    },

    async listStylesForPackage(
      packageUuid: string,
    ): Promise<[CssStyleInfo[], CssStyleInfo[]]> {
      return invoke("list_styles_for_package", { packageUuid })
    },

    async deleteCssStyle(scope: CssStyleScope, id: string): Promise<void> {
      return invoke("delete_css_style", { scope, id })
    },

    async setPackageActiveStyle(
      packageUuid: string,
      activeStyle: ActiveStyle | null,
    ): Promise<void> {
      // Tauri 命令接受 Option<ActiveStyle>：null → 清空 / 对象 → 设置
      return invoke("set_package_active_style", { packageUuid, activeStyle })
    },

    async getPackageActiveStyle(packageUuid: string): Promise<ActiveStyle | null> {
      return invoke("get_package_active_style", { packageUuid })
    },

    async scanPublicCssStyles(): Promise<CssStyleScanResult> {
      return invoke("scan_public_css_styles")
    },

    // ======================== 邮件收件箱（阶段 1） ========================

    async mailFetch(folderUuid: string): Promise<MailFetchResult> {
      return invoke("mail_fetch", { folderUuid })
    },

    async mailSaveResult(
      messageId: string,
      status: "saved" | "failed",
      filePath?: string | null,
      error?: string | null,
    ): Promise<void> {
      return invoke("mail_save_result", { messageId, status, filePath: filePath ?? null, error: error ?? null })
    },

    async mailAccountGet(folderUuid: string): Promise<MailAccount | null> {
      return invoke("mail_account_get", { folderUuid })
    },

    async mailAccountSave(params: {
      folderUuid: string
      host: string
      port: number
      ssl: boolean
      mailUser: string
      imapFolder: string
      fetchLimit: number
      unseenOnly: boolean
      sinceDays: number
      keyword: string
      imapFolders: ImapFolderMapping[]
    }): Promise<void> {
      return invoke("mail_account_save", {
        folderUuid: params.folderUuid,
        host: params.host,
        port: params.port,
        ssl: params.ssl,
        mailUser: params.mailUser,
        imapFolder: params.imapFolder,
        fetchLimit: params.fetchLimit,
        unseenOnly: params.unseenOnly,
        sinceDays: params.sinceDays,
        keyword: params.keyword,
        imapFolders: params.imapFolders,
      })
    },

    async mailAccountDelete(folderUuid: string): Promise<boolean> {
      return invoke("mail_account_delete", { folderUuid })
    },

    async mailAccountList(): Promise<MailAccount[]> {
      return invoke("mail_account_list")
    },

    async mailCredentialSet(folderUuid: string, password: string): Promise<void> {
      return invoke("mail_credential_set", { folderUuid, password })
    },

    async mailCredentialConfigured(folderUuid: string): Promise<boolean> {
      return invoke("mail_credential_configured", { folderUuid })
    },

    async mailTestConnection(params: {
      folderUuid: string
      host: string
      port: number
      ssl: boolean
      user: string
      imapFolder: string
      password?: string | null
    }): Promise<void> {
      return invoke("mail_test_connection", {
        folderUuid: params.folderUuid,
        host: params.host,
        port: params.port,
        ssl: params.ssl,
        user: params.user,
        imapFolder: params.imapFolder,
        password: params.password ?? null,
      })
    },

    async mailListImapFolders(params: {
      folderUuid: string
      host: string
      port: number
      ssl: boolean
      user: string
      password?: string | null
    }): Promise<ImapFolderInfo[]> {
      return invoke("mail_list_imap_folders", {
        folderUuid: params.folderUuid,
        host: params.host,
        port: params.port,
        ssl: params.ssl,
        user: params.user,
        password: params.password ?? null,
      })
    },

    // ======================== 工具 ========================

    async fetchPageTitle(url: string): Promise<string | null> {
      return invoke("fetch_page_title", { url })
    },
  }
}