# kmgr-api 场景清单

> 本文档是 kmgr-api 类型契约的设计输入。从场景出发 → 明确数据需求 → 推导 API，确保 API 紧密贴合业务而非凭空设计。
>
> **优先级说明**
>
> - 🔴 当前必做：MVP 阶段必须实现，API 设计覆盖
> - 🟡 未来关注：当前仅在设计上保留扩展空间，不实现
> - **设计考量**：即使当前不做，方案上也要预留扩展点（字段、接口、数据结构）

***

## 场景一：知识库管理

| #   | 场景       | 用户描述                                 | 优先级     | 设计考量                                                            |
| --- | -------- | ------------------------------------ | ------- | --------------------------------------------------------------- |
| 1.1 | 初始化知识库   | "我是新用户，第一次打开。创建我的第一个知识库，选个本地目录存放数据。" | 🔴 当前必做 | KnowledgeBase 需预留 `type: "local"` 字段                            |
| 1.2 | 打开已有知识库  | "切换到另一个知识库（另一个 SQLite 文件）。"          | 🔴 当前必做 | <br />                                                          |
| 1.3 | 添加本地文件   | "把一个项目文件夹拖进来，索引其中所有 .ts/.md/.rs 文件。" | 🔴 当前必做 | 文件路径用绝对路径，预设常见扩展名白名单                                            |
| 1.4 | 批量导入目录   | "导入整个目录树，保持目录结构作为分类层级。"              | 🔴 当前必做 | 与 1.3 共用接口，参数控制是否递归                                             |
| 1.5 | 变更感知（重扫） | "我在外部新增/修改/删除了文件，知识库应能感知变化。"         | 🔴 当前必做 | 返回 { added, modified, removed } 三列表                             |
| 1.6 | 远程文件夹同步  | "我想索引一个远程服务器 / NAS / 云存储上的目录。"       | 🟡 未来关注 | FileInfo 预留 `origin: "local" \| "remote"`，API 预留 `remoteUrl` 参数 |
| 1.7 | 知识库共享    | "把我的知识库分享给其他人协作维护。"                  | 🟡 未来关注 | 需考虑权限模型、冲突解决；当前不设计具体协议                                          |
| 1.8 | 知识库备份/恢复 | "导出知识库到 .zip，或从备份恢复。"                | 🟡 未来关注 | API 预留 `backup(path)` / `restore(path)` 方法签名                    |

***

## 场景二：分类组织

| #   | 场景        | 用户描述                            | 优先级     | 设计考量                                              |
| --- | --------- | ------------------------------- | ------- | ------------------------------------------------- |
| 2.1 | 查看分类      | "在文件浏览器中看到全部分类（树形结构）。"          | 🔴 当前必做 | 返回平铺列表 + 树形结构两个视图                                 |
| 2.2 | 创建分类      | "右键创建分类'工作/项目A'（支持层级路径）。"       | 🔴 当前必做 | 支持 `parentPath: "工作"` 或 `parentId`                |
| 2.3 | 拖拽移动文件    | "把 file.ts 从'未分类'拖到'工作/项目A'。"   | 🔴 当前必做 | 更新 FileInfo.categoryId                            |
| 2.4 | 重命名分类     | "双击分类名'项目A'，改名'项目Alpha'。"       | 🔴 当前必做 | <br />                                            |
| 2.5 | 删除分类      | "删除'归档'分类：提示是移动文件到其他分类，还是一起删除。" | 🔴 当前必做 | `deleteCategory(id, mode: "detach" \| "cascade")` |
| 2.6 | 拖拽排序      | "拖拽调整分类在同一层级中的显示顺序。"            | 🔴 当前必做 | sortOrder 字段                                      |
| 2.7 | 导入时自动创建分类 | "导入目录时，自动按目录结构创建分类层级。"          | 🔴 当前必做 | 与 1.4 联动，分类名取目录名                                  |
| 2.8 | 智能分类建议    | "AI 根据文件内容建议分类归属。"              | 🟡 未来关注 | AI 插件消费 category API，核心不感知                        |

***

## 场景三：标签管理

| #   | 场景     | 用户描述                               | 优先级     | 设计考量                               |
| --- | ------ | ---------------------------------- | ------- | ---------------------------------- |
| 3.1 | 查看标签   | "查看所有标签（平铺 + 树形）。"                 | 🔴 当前必做 | <br />                             |
| 3.2 | 创建标签   | "创建一个红色标签 'rust'。"                 | 🔴 当前必做 | Tag 含 color、icon 可选字段              |
| 3.3 | 标签层级   | "创建标签树：语言 → TypeScript、语言 → Rust。" | 🔴 当前必做 | parentId 自引用                       |
| 3.4 | 给文件打标签 | "选中 3 个文件，批量打上 'rust' 标签。"         | 🔴 当前必做 | `setFileTags(fileIds[], tagIds[])` |
| 3.5 | 拆标签    | "从某个文件移除 'rust' 标签（不删除标签本身）。"      | 🔴 当前必做 | 与 3.4 同一接口，覆盖即可                    |
| 3.6 | 编辑标签   | "修改标签颜色、名称、图标。"                    | 🔴 当前必做 | <br />                             |
| 3.7 | 删除标签   | "删除不再使用的标签（从所有文件解除关联）。"            | 🔴 当前必做 | 级联删除 FileTag 关联                    |
| 3.8 | 智能标签建议 | "AI 分析文件内容，自动建议标签。"                | 🟡 未来关注 | AI 插件消费 tag API，核心不感知              |

***

## 场景四：查找知识

| #   | 场景       | 用户描述                                            | 优先级     | 设计考量                        |
| --- | -------- | ----------------------------------------------- | ------- | --------------------------- |
| 4.1 | 按分类浏览    | "点'工作/项目A'分类，列出该分类下所有文件。"                       | 🔴 当前必做 | 支持分页、排序                     |
| 4.2 | 全文搜索     | "Ctrl+P 搜索 'async trait'，列出匹配文件及片段。"            | 🔴 当前必做 | 搜索范围：文件名 + 内容片段，返回 snippet  |
| 4.3 | 标签筛选     | "筛选同时有 'rust' 和 'async' 标签的文件。"                 | 🔴 当前必做 | tags 参数支持 AND/OR 模式         |
| 4.4 | 最近文件     | "底部栏显示最近操作/打开过的 5 个文件。"                         | 🔴 当前必做 | `getRecentFiles(limit)`     |
| 4.5 | 按扩展名过滤   | "只看 .rs 文件。"                                    | 🔴 当前必做 | ext 参数                      |
| 4.6 | 按时间范围过滤  | "查看最近一周添加的文件。"                                  | 🔴 当前必做 | dateFrom / dateTo 参数        |
| 4.7 | 高级组合查询   | "分类='工作' AND 标签='rust' AND 扩展名='.rs' AND 最近一周。" | 🔴 当前必做 | 所有 filter 参数可组合使用           |
| 4.8 | 全文语义搜索   | "搜索 '如何做错误处理' 能匹配内容相关的文件（不依赖关键词）。"              | 🟡 未来关注 | 需嵌入模型，AI 插件实现               |
| 4.9 | 知识关系图谱浏览 | "可视化浏览文件之间的引用/关联关系。"                            | 🟡 未来关注 | 需先建立文件关联数据，核心预留 `relations` |

***

## 场景五：统计概览

| #   | 场景     | 用户描述                         | 优先级     | 设计考量                          |
| --- | ------ | ---------------------------- | ------- | ----------------------------- |
| 5.1 | 基础总览   | "底部状态栏：共 N 个文件、M 个分类、K 个标签。" | 🔴 当前必做 | `getStats()` 返回摘要             |
| 5.2 | 分类分布   | "饼图/条形图：各类别下文件数量。"           | 🔴 当前必做 | `getDistribution("category")` |
| 5.3 | 扩展名分布  | "饼图：.ts 占 40%、.md 占 30%……"   | 🔴 当前必做 | `getDistribution("ext")`      |
| 5.4 | 标签使用统计 | "哪些标签用得最多？哪些标签从未使用？"         | 🔴 当前必做 | `getDistribution("tag")`      |
| 5.5 | 时间趋势   | "最近半年每月新增文件数量柱状图。"           | 🟡 未来关注 | `getTrend(duration)`          |
| 5.6 | 活跃度分析  | "最近一周操作最频繁的文件/目录。"           | 🟡 未来关注 | 需操作日志，当前预留统计事件                |

***

## 场景六：配置

| #   | 场景      | 用户描述                             | 优先级     | 设计考量                      |
| --- | ------- | -------------------------------- | ------- | ------------------------- |
| 6.1 | 基础配置    | "设置默认语言、界面主题偏好。"                 | 🔴 当前必做 | key-value 模式              |
| 6.2 | 忽略规则    | "扫描时忽略 node\_modules、.git、dist。" | 🔴 当前必做 | `scan.ignorePaths` 设置项    |
| 6.3 | 文件类型白名单 | "只索引 .ts/.md/.rs/.json 文件。"      | 🔴 当前必做 | `scan.fileExtensions` 设置项 |
| 6.4 | 知识库信息   | "查看当前知识库路径、数据库大小。"               | 🔴 当前必做 | `getKnowledgeBaseInfo()`  |
| 6.5 | 插件管理    | "启用/禁用/卸载插件。"                    | 🟡 未来关注 | 依赖插件系统完善后再设计              |

***

## 数据模型汇总

```
KnowledgeBase
  ├── id: number
  ├── name: string
  ├── path: string (本地路径)
  ├── type: "local"              ← 🔴 当前使用，🟡 未来扩 "remote"
  ├── ownerId: string | null     ← 🟡 个人标识，共享场景下标识归属
  ├── version: number            ← 🟡 版本号，共享更新时递增，当前默认 1
  ├── sharedAt: string | null    ← 🟡 上次共享发布时间
  ├── shareExpiresAt: string | null  ← 🟡 共享有效期截止时间
  ├── createdAt: string
  └── updatedAt: string

FileInfo
  ├── id: number
  ├── name: string
  ├── path: string (绝对路径)
  ├── ext: string
  ├── size: number (bytes)
  ├── categoryId: number | null
  ├── origin: "local"             ← 🔴 当前仅 local，🟡 预留 remote
  ├── validFrom: string | null    ← 🟡 知识生效时间（如法条施行日）
  ├── validUntil: string | null   ← 🟡 知识失效时间（如政策废止日）
  ├── createdAt: string
  ├── modifiedAt: string
  └── accessedAt: string           ← 🔴 记录最近打开，对应 4.4 最近文件

Category
  ├── id: number
  ├── name: string (唯一标识，如 "project-a")
  ├── displayName: string (展示名，如 "项目A")
  ├── parentId: number | null
  ├── sortOrder: number
  ├── isSystem: boolean
  ├── canDelete: boolean
  └── fileCount: number            ← 聚合字段，不存库但查库实时计算

Tag
  ├── id: number
  ├── name: string (唯一)
  ├── parentId: number | null
  ├── color: string | null (如 "#ff4757")
  ├── icon: string | null (emoji)
  ├── sortOrder: number
  └── fileCount: number

FileTag (多对多关联)
  ├── fileId: number
  └── tagId: number

Setting
  ├── key: string
  ├── value: string (JSON 序列化)
  └── updatedAt: string

Stats
  ├── totalFiles: number
  ├── totalCategories: number
  ├── totalTags: number
  └── totalSize: number

Distribution
  ├── type: "category" | "ext" | "tag"
  └── items: { key: string; label: string; count: number; pct: number }[]
```

***

## 关联关系

```
KnowledgeBase 1──n FileInfo
KnowledgeBase 1──n Category
KnowledgeBase 1──n Tag
Category     1──n FileInfo        (通过 FileInfo.categoryId)
Category     self-ref             (通过 parentId)
Tag          self-ref             (通过 parentId)
FileInfo     n──n Tag             (通过 FileTag)
```

***

## 编辑指南

- 新增场景请按模板追加："{序号} {场景名} | {用户描述} | {优先级} | {设计考量}"
- 变更优先级请改 🔴 ↔ 🟡 标记
- 删除场景请划删除线 ~~like this~~，保留一周后移除
- 新增数据模型字段请同时在模型汇总中补充

