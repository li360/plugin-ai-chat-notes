# kmgr-api 子项目

**目录:** `packages/kmgr-api/`
**状态:** ✅ 已完成（类型契约 + invoke 封装层）
**依赖:** `@tauri-apps/api`（仅 invoke 模块，类型契约部分零依赖）

---

## 目标

定义知识管理 API 的 TypeScript 类型契约，并提供 Tauri IPC 的 invoke 封装层。作为前端 UI 与 Rust 核心引擎之间的类型安全桥梁。

---

## 两层结构

### 类型契约层（纯类型，零运行时）

```
src/
├── types.ts   ← 核心数据类型（KnowledgeBase、FileInfo、Category、Tag、Stats 等）
├── params.ts  ← API 参数类型（ListFilesParams、SearchFilesParams、CreateCategoryParams 等）
├── api.ts     ← KmgrApi 接口定义（纯类型，不含实现）
└── index.ts   ← 统一导出
```

### invoke 封装层（依赖 @tauri-apps/api）

```
src/
└── invoke.ts  ← createKmgrApi() 工厂函数，调用 Tauri invoke 实现 KmgrApi 接口
```

---

## 核心理念

`KmgrApi` 接口定义在前端，实现由 Tauri IPC 提供。这允许：

- **纯前端开发**：Demo 插件可 mock `KmgrApi`，无需启动 Rust 后端
- **Tauri 桌面**：`createKmgrApi()` 通过 IPC 调用 Rust 核心
- **类型安全**：所有参数和返回值均有 TypeScript 类型约束

---

## API 分组

| 组 | 方法 | 说明 |
|----|------|------|
| 知识库 | `initialize`、`open`、`getInfo` | 初始化、打开、获取信息 |
| 文件 | `addFiles`、`importDirectory`、`rescan`、`listFiles`、`searchFiles`、`getFile`、`updateFile`、`removeFiles`、`getRecentFiles` | 文件 CRUD + 搜索 |
| 分类 | `listCategories`、`getCategoryTree`、`createCategory`、`updateCategory`、`deleteCategory`、`reorderCategories` | 分类管理 |
| 标签 | `listTags`、`getTagTree`、`createTag`、`updateTag`、`deleteTag`、`setFileTags`、`removeFileTags`、`getFileTags` | 标签管理 |
| 统计 | `getStats`、`getDistribution` | 统计概览 |
| 配置 | `getSetting`、`setSetting`、`listSettings` | 配置管理 |
| 包与双链 | `searchPackages`、`getPackageByTitle`、`getPackageByPath`、`registerPackage`、`updatePackagePath`、`deletePackage`、`healthCheck`、`syncLinks`、`getBacklinks`、`resolvePendingLinks`、`scanPackages`、`scanPackagesInDir`、`resolveFilePackage` | 包 CRUD + 双链 + 扫描 + 健康检查 |
| **共享片段（P0-2）** | `createSharedFragment`、`updateSharedFragment`、`getSharedFragment`、`listSharedFragments`、`listFragmentVersions`、`getSharedFragmentRefs`、`setPackageSharedRefs`、`deleteSharedFragment`、`rollbackFragment` | 9 方法，逻辑身份 + 版本链 |

---

## 与其他子项目的关系

```
kmgr-core (Rust)  ← 实现 API 逻辑
      ↑
tauri-app (Rust)  ← Tauri commands 包装
      ↑ Tauri IPC
kmgr-api/invoke   ← createKmgrApi() 封装层
      ↑
workspace/        ← setKmgrApi/getKmgrApi 管理实例
      ↑
ui-framework/     ← PluginContainer 注入 pluginContext.kmgr
      ↑
plugin-*/         ← 插件通过 ctx.kmgr 调用 API
```

---

## 验收标准

- [x] 定义核心类型：KnowledgeBase、FileInfo、Category、Tag、Stats、Distribution 等
- [x] 定义参数类型：ListFilesParams、SearchFilesParams、CreateCategoryParams 等
- [x] 定义 KmgrApi 接口（8 组 60+ 方法，含共享片段 9 方法 + 包片段元数据 3 方法）
- [x] 实现 createKmgrApi() invoke 封装层
- [x] Rust 端 serde 序列化与 TS 类型对齐（ListSort、DistributionType 等）
- [x] 共享片段（P0-2.2）— 7 类型 + 9 invoke 方法 + RegisterPackageParams 扩展 sharedRefs
- [x] 包片段元数据（P1-5.1）— 2 类型（FragmentInfo/FragmentParam）+ 3 invoke 方法 + RegisterPackageParams 扩展 fragments
- [x] TypeScript 编译通过