# Plugin Protocol 子项目

**目录:** `packages/plugin-protocol/`
**状态:** ✅ 接口已定义（含 KmgrApi 注入）
**依赖:** `kmgr-api`（纯类型）

---

## 目标

定义插件系统所需的全部接口、类型和通信协议。作为 workspace 和各个 plugin 子项目的共同契约。零运行时依赖，仅包含 TypeScript 类型和纯函数工具。

---

## 核心概念

### 三层关系

```
plugin-protocol/  ← 接口契约（本包）
    ↑ 依赖
workspace/        ← 编排层：注册插件、管理槽位、路由事件
    ↑ 注入
ui-framework/     ← 渲染层：容器渲染插件组件
    ↑ 装载
plugin-*/         ← 插件实现：实现 PluginManifest + PluginComponent
```

### 通信模型

采用 **事件总线 (EventBus)** 模式：

```
容器 A (文件浏览器)                   容器 B (编辑器)
   │                                     │
   │  emit("file:select", {path})        │  on("file:select", handler)
   │                                     │
   └─────────── EventBus ────────────────┘
                      │
              workspace 预先注册了
              "file:select" → "file:open" 的路由
```

---

## 类型清单

| 文件 | 内容 |
|------|------|
| `plugin.ts` | `PluginManifest`、`PluginContext`、`PluginComponent`、`PluginRegistration`、`LayoutHints`、`StatusBarItem`、`ShortcutBinding`、`Command`、`ContextMenuItem`、`MenuItemGroup`、`Logger`、`LogEntry`、`LogLevel`、`EditorLiveState` |
| `events.ts` | `EventBus`（接口+工厂函数）、`CoreEvents`（核心事件载荷类型） |
| `workspace.ts` | `ContainerSlot`、`EventLink`、`FileAssociation`、`WorkspaceConfig`、`WorkspaceState` |
| `index.ts` | 统一导出（仅 type export） |

### 关键接口

```typescript
// 插件声明
interface PluginManifest {
  id: string              // "file-explorer"
  name: string            // "文件浏览器"
  icon?: string           // emoji
  component: PluginComponent
  emits: string[]         // ["file:select"]
  handles: string[]       // ["file:open"]
  layoutHints?: LayoutHints
  statusBarItems?: StatusBarItem[]
  shortcuts?: ShortcutBinding[]
  menuItems?: MenuItemGroup[]
}

// 插件上下文
interface PluginContext {
  containerId: string
  emit: <T>(event: string, payload: T) => void
  on: <T>(event: string, handler: (payload: T) => void) => () => void
  kmgr?: KmgrApi  // 知识库 API，仅在 Tauri 环境中可用
  sharedState?: {  // 跨插件共享状态，键命名规范 pluginId:key
    get: <T>(key: string) => T | undefined
    set: (key: string, value: unknown) => void
  }
}

// 命令
interface Command {
  id: string
  label: string
  icon?: string
  category?: string
  shortcut?: string
  handler: () => void
}
```

---

## 核心事件

| 事件名 | 载荷 | 方向 | 说明 |
|--------|------|------|------|
| `file:select` | `{ path: string, name: string, ext: string }` | 插件→插件 | 文件被选中 |
| `file:open` | `{ path: string, name: string, ext: string }` | 插件→插件 | 打开文件 |
| `editor:live-changed` | `EditorLiveState` | 编辑器→AI 面板 | 未保存缓冲区 + 选区变化 |
| `ai:rewrite-apply` | `{ requestId, path, start, end, original, text }` | AI 面板→编辑器 | 请求替换选区 |
| `ai:rewrite-applied` / `ai:rewrite-failed` | `{ requestId, path }` / `{ requestId, reason }` | 编辑器→AI 面板 | 替换结果 |
| `toast:show` | `{ type: "info"\|"success"\|"warning"\|"error", message: string }` | 插件→框架 | 显示 Toast 通知 |
| `contextmenu:open` | `{ items: ContextMenuItem[], x: number, y: number }` | 插件→框架 | 弹出右键菜单 |
| `dialog:open` | `{ type, title, message, confirmLabel?, cancelLabel?, variant?, onResult }` | 插件→框架 | 弹出确认/警告弹窗 |
| `overlay:open` | `{ pluginId: string }` | 插件→框架 | 打开覆盖层 |
| `overlay:close` | `null` | 插件→框架 | 关闭覆盖层 |
| `statusbar:update` | `{ id: string, value: string }` | 插件→框架 | 动态更新状态栏项值 |
| `menu:update` | `{ groupId, itemId, patch: { disabled?, label?, shortcut? } }` | 插件→框架 | 动态更新菜单项状态 |
| `menu:changed` | `null` | workspace→UI | 菜单状态已变更，触发重渲染 |
| `workspace:slot:changed` | `{ containerId: string, pluginId: string \| null }` | workspace→插件 | 容器槽位变更通知 |
| `workspace:slot:added` | `{ containerId: string, pluginId: string, title: string, source: "shift" \| "lock-restore" }` | workspace→UI | 容器实例新增（shift+点击或锁定的动态容器刷新还原） |
| `workspace:slot:removed` | `{ containerId: string }` | workspace→UI | 容器实例被关闭移除 |
| `workspace:slot:lock-changed` | `{ containerId: string, locked: boolean }` | workspace→UI | 容器锁定状态变更 |
| `workspace:links:changed` | `EventLink[]` | workspace→外部 | 事件链路变更（持久化用） |
| `log:entry` | `LogEntry` | workspace→插件 | 日志条目（供日志面板消费） |

---

## 容器间交互命名空间（未来扩展，当前仅约定）

插件跨容器交互（如拖拽、跨容器复制）使用 `inter:` 命名空间。当前阶段仅约定事件名，具体载荷类型留待拖拽需求阶段定义。

| 事件名 | 载荷（约定） | 说明 |
|--------|------|------|
| `inter:drag:start` | `DragPayload`（待定义） | 拖拽开始（DOM 层之外的业务通知） |
| `inter:drag:drop` | `{ source, target, items }` | 拖拽落到目标容器 |
| `inter:copy:request` | `{ source, target, items }` | 请求复制 |
| `inter:copy:complete` | `{ source, target, count }` | 复制完成 |

**说明：**

- HTML5 拖拽本身通过 `dataTransfer` 跨容器传递数据，EventBus 仅用于业务协调（如复制完成后通知源/目标刷新列表）
- 源插件可从 `ctx.containers` 查询所有容器，用于判断合法落点
- 跨容器事件 payload 建议携带 `__targetContainer` 字段以定向寻址，避免广播污染

---

## 多实例路由约定

- 源插件 emit 时若携带 `openIn: "new"`，workspace 将克隆目标容器的 slot 和 EventLink，生成新实例（ID 格式 `cN#2`）
- workspace 路由时注入 `__targetContainer`，标识事件最终命中的容器 ID
- 接收方插件应优先按 `__targetContainer` 过滤，仅响应发往本容器的事件
- 为兼容旧插件，`__targetContainer` 缺失时回退到原生容器响应（如 "c4"）
- 同类型容器上限为 2 个，第 3 次 shift+点击改为刷新第二个实例

---

## 依赖关系

| 谁依赖 | 依赖方式 |
|--------|----------|
| `workspace/` | import 所有类型，使用 `createEventBus` |
| `plugin-*/` | import `PluginManifest`、`PluginContext`、`Logger` 等类型 |
| `ui-framework/` | 无需直接依赖（通过 workspace 注入） |
| `kmgr-api/` | 被本包依赖（提供 `KmgrApi` 类型） |

---

## 验收标准

- [x] 定义 `PluginManifest` 接口（含 id / name / icon / component / emits / handles / layoutHints / statusBarItems / shortcuts / menuItems）
- [x] 定义 `PluginContext` 接口（含 containerId / emit / on / kmgr）
- [x] 定义 `EventBus` 接口和工厂函数
- [x] 定义 `ContainerSlot`、`EventLink`、`FileAssociation` 类型
- [x] 定义 `WorkspaceConfig` / `WorkspaceState` 类型
- [x] 定义 `Logger`、`LogEntry`、`LogLevel` 类型
- [x] 定义 `Command`、`StatusBarItem`、`ShortcutBinding`、`ContextMenuItem`、`MenuItemGroup` 类型
- [x] 定义 `CoreEvents` 全部 13 个事件载荷类型
- [x] 零运行时依赖，纯类型包
- [x] TypeScript 编译通过