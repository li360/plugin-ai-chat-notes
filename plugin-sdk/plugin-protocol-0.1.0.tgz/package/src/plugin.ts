import type { ComponentType } from "react"
import type { KmgrApi, PluginData } from "kmgr-api"

/** 日志级别 */
export type LogLevel = "debug" | "info" | "warn" | "error"

/** 单条日志记录 */
export interface LogEntry {
  /** 时间戳（ISO 格式） */
  timestamp: string
  /** 日志级别 */
  level: LogLevel
  /** 来源标识，如 "file-explorer"、"workspace" */
  source: string
  /** 日志消息 */
  message: string
  /** 附加数据 */
  args?: unknown[]
}

/** 日志接口 — 由 workspace 实现，注入给插件使用 */
export interface Logger {
  debug(source: string, message: string, ...args: unknown[]): void
  info(source: string, message: string, ...args: unknown[]): void
  warn(source: string, message: string, ...args: unknown[]): void
  error(source: string, message: string, ...args: unknown[]): void
  /** 获取缓存的最近日志条目（用于日志面板首次打开时回填） */
  getLogEntries(): LogEntry[]
}

/** 编辑器文件上下文 — workspace 注入给编辑器插件使用 */
export interface EditorFileContext {
  /** 当前打开的文件（content 由 workspace 预加载，文本文件为 string，二进制文件为 Uint8Array） */
  file: { path: string; name: string; ext: string; content: string | Uint8Array } | null
  /** 保存文件内容 — 接受文本或二进制，由 workspace 根据原始文件类型路由写入 */
  save: (content: string | Uint8Array) => Promise<void>
  /** 标记是否有未保存的修改 */
  markDirty: (dirty: boolean) => void
  /** 是否有未保存的修改 */
  isDirty: boolean
  /** 是否在 Tauri 环境中 */
  isTauri: boolean
}

/** 编辑器实时状态 — 编辑器插件发布到 sharedState `editor:live:<containerId>`。
 *  供 AI 面板等非编辑器插件读取未保存缓冲区与选区；内容随输入更新。 */
export interface EditorLiveState {
  containerId: string
  path: string
  name: string
  content: string
  selection: { start: number; end: number; text: string }
  dirty: boolean
}

/** 插件 Props — 插件组件收到的上下文 */
export interface PluginBrowserApi {
  /** 打开 http/https URL。external = 系统默认浏览器；embedded = GeWu 内嵌浏览器窗口。
   *  宿主会校验协议（拒绝 file/javascript 等）并拒绝带凭据的 URL。 */
  open(url: string, opts?: { mode?: "external" | "embedded" }): Promise<void>
}

export interface PluginContext {
  /** 所属容器 ID */
  containerId: string
  /** 发出事件 */
  emit: <T = unknown>(event: string, payload: T) => void
  /** 订阅事件 */
  on: <T = unknown>(event: string, handler: (payload: T) => void) => () => void
  /** 知识库 API — 仅在 Tauri 环境中可用，插件需声明 kmgr:read/write capability */
  kmgr?: KmgrApi
  /** 浏览器打开 API — 插件不应直接 invoke browser 命令 */
  browser?: PluginBrowserApi
  /** 插件数据便捷 API — workspace 绑定当前插件 ID，插件无需传 pluginId；依赖 kmgr 可用 */
  pluginData?: PluginDataApi
  /** 编辑器上下文 — workspace 为 isEditor 插件注入，非编辑器插件为 undefined */
  editor?: EditorFileContext
  /** 工作区容器清单（只读快照）— 用于多实例场景发现对端容器，如拖拽落点选择、shift 行为判断 */
  containers?: ReadonlyArray<ContainerInfo>
  /** 共享状态 — 跨插件状态查询，键命名规范 pluginId:key（如 file-list:currentPath） */
  sharedState?: {
    get: <T = unknown>(key: string) => T | undefined
    set: (key: string, value: unknown) => void
  }
  /** 文件历史导航 — workspace 为编辑器/查看器插件注入，支持"返回上一个文件" */
  fileHistory?: FileHistoryApi
}

/** 项目元数据 — `.proj` 目录中 `.projmeta.json` 的框架视角通用字段
 *
 *  `.proj` 是「类型化项目容器」：框架只解析下列通用字段；
 *  类型专属配置放在与 `type` 同名的顶层段中（如 type:"gallery" 时的 `gallery` 字段），
 *  由声明对应 projectTypes 的视图插件自行解析，框架原样读取透传、不校验。 */
export interface ProjectMeta {
  /** 项目稳定 ID（proj- 前缀 + 随机串），新建时生成 */
  id: string
  /** meta 格式版本，当前为 1 */
  version: number
  /** 项目类型标识 — 对应项目视图插件 manifest.projectTypes 中的声明，如 "gallery" */
  type: string
  /** 可选：显式指定项目视图插件 id；缺省按 type 路由。指向禁用/未安装插件时回退 type。 */
  viewPlugin?: string
  /** 项目显示名 — 缺省时框架/插件回退为目录名 */
  title?: string
  /** 创建时间（ISO 8601） */
  createdAt?: string
  /** 最近修改时间（ISO 8601） */
  updatedAt?: string
  /** 类型专属配置段 — 键名与 type 相同，结构由对应视图插件定义，框架不解析 */
  [typeConfig: string]: unknown
}

/** 容器信息 — workspace 提供给插件查询当前所有容器的只读视图 */
export interface ContainerInfo {
  /** 容器 ID（原生如 "c4"，多实例如 "c4#2"） */
  containerId: string
  /** 容器标题 */
  title: string
  /** 当前装载的插件 ID，null 表示空容器 */
  pluginId: string | null
  /** 是否为用户锁定的持久化容器（动态创建且用户主动锁定） */
  locked?: boolean
}

/** 容器选项组件 Props — 在容器标题栏 ⚙️ 入口弹出的面板中渲染本容器专属配置
 *  框架渲染面板外壳（插件信息/管理），插件通过 optionsComponent 提供配置分区内容。
 *  配置读写由插件自管（pluginData），框架不感知配置内容；变更后通过 emit 通知主组件重载 */
export interface ContainerOptionsProps {
  /** 所属容器 ID */
  containerId: string
  /** 发出事件 — 配置变更后通知主组件重载 */
  emit: <T = unknown>(event: string, payload: T) => void
  /** 订阅事件 */
  on: <T = unknown>(event: string, handler: (payload: T) => void) => () => void
  /** 知识库 API — 仅 Tauri 环境可用 */
  kmgr?: KmgrApi
  /** 插件数据便捷 API — 已绑定当前插件 ID，用于读写本插件配置 */
  pluginData?: PluginDataApi
}

/**
 * 路由事件 payload 公共字段约定
 *
 * 源插件 emit 时可携带 `openIn` 指示 workspace 的路由策略：
 *   - "current"（默认）：复用现有目标容器
 *   - "new"：请求新开一个目标容器实例（shift+点击场景）
 *
 * PluginContext.emit 会自动注入 `__sourceContainer`，标识事件来源容器 ID。
 * bindLink 据此过滤：c3 的 link 只处理 c3 发出的事件，避免 c3#2 的事件被 c3 的 link 误响应。
 *
 * workspace 路由后会注入 `__targetContainer`，标识事件最终命中的容器 ID。
 * 接收方插件应优先按 `__targetContainer` 过滤，仅响应发往本容器的事件。
 * 为兼容旧插件，`__targetContainer` 缺失时回退到原生容器响应（如 "c4"）。
 */
export interface RoutedPayload {
  /** "new" 表示请求在新容器实例中打开；"current" 或缺省走默认路由 */
  openIn?: "new" | "current"
  /** 事件来源容器 ID — PluginContext.emit 自动注入，workspace 内部用于 link 路由过滤 */
  __sourceContainer?: string
  /** 路由目标容器 ID — workspace 注入，插件只读 */
  __targetContainer?: string
}

/**
 * 创建多实例事件过滤器 — 插件订阅事件时复用，避免每个插件各自实现过滤逻辑
 *
 * 过滤规则：
 * - 有 __targetContainer：仅匹配的容器响应（workspace 路由后的事件）
 * - 无 __targetContainer：
 *   - 动态实例（containerId 含 #）忽略原始事件（等 workspace 路由）
 *   - 原生实例不响应 openIn:"new"（等 workspace 路由后再来）
 *
 * @param containerId 当前容器 ID
 * @returns (payload) => boolean，true 表示当前容器应响应此事件
 *
 * @example
 * const shouldHandle = createMultiInstanceFilter(containerId)
 * on("file:open", (payload) => {
 *   if (!shouldHandle(payload)) return
 *   // ... 处理事件
 * })
 */
export function createMultiInstanceFilter(containerId: string): (payload: RoutedPayload) => boolean {
  const isDynamic = containerId.includes("#")
  return (payload: RoutedPayload) => {
    if (payload.__targetContainer !== undefined) {
      // 路由事件：仅匹配的容器响应
      return payload.__targetContainer === containerId
    }
    // 原始事件：动态实例忽略；原生实例不响应 openIn:"new"
    if (isDynamic) return false
    if (payload.openIn === "new") return false
    return true
  }
}

/** 文件历史导航 — workspace 注入，支持编辑器/查看器"返回上一个文件"
 *  每个容器独立维护历史栈，file:open 成功路由时自动 push（去重 + 前进检测）
 *  goBack 弹出当前文件并重新触发 file:open 打开上一个，去重逻辑天然避免循环 */
export interface FileHistoryApi {
  /** 是否可返回上一个文件（历史栈长度 >= 2） */
  canGoBack: () => boolean
  /** 返回上一个文件 — 弹出当前文件，重新触发 file:open 打开历史栈上一个路径
   *  若不可返回（栈长度 < 2）则无操作 */
  goBack: () => void
}

/** 插件数据便捷 API — workspace 在创建 PluginContext 时用当前插件 ID 绑定
 *
 * 推荐插件使用此接口而非直接调用 ctx.kmgr.readPluginData(id, key)，
 * 避免硬编码插件 ID，且便于未来 Phase 4 沙箱隔离时统一代理。
 */
export interface PluginDataApi {
  /** 读取当前插件的数据项 — 不存在返回 null */
  read<T = unknown>(key: string): Promise<T | null>
  /** 写入当前插件的数据项 — 不存在则创建，存在则更新 */
  write(key: string, value: unknown): Promise<void>
  /** 列出当前插件的所有数据项 — 按 key 排序 */
  list(): Promise<PluginData[]>
  /** 删除当前插件的某个数据项 */
  delete(key: string): Promise<void>
}

/** 插件组件类型 */
export type PluginComponent = ComponentType<PluginContext>

/**
 * 主题贡献点 — 纯 CSS 主题插件声明
 *
 * 主题插件无需 component（不占容器），启用后框架把 stylesheet 指向的 CSS 文件内容
 * 注入为 <style data-gewu-theme="id">，通过 html[data-theme="id"] 选择器生效。
 * CSS 只能覆盖 design-tokens 的 CSS 变量，不执行任何 JS。
 */
export interface ThemeContribution {
  /** 主题 ID — 即 data-theme 值，如 "midnight"；建议带插件风格前缀避免冲突 */
  id: string
  /** 主题显示名称（直接展示，不经过 i18n） */
  name: string
  /** 主题图标 — emoji 字符串，缺省由 UI 给通用调色板图标 */
  icon?: string
  /** 样式文件相对插件目录的路径，如 "theme.css"（manifest.json 打包形态使用） */
  stylesheet?: string
  /** 样式文本 — 由框架加载 stylesheet 后填充，manifest.json 中不出现 */
  cssText?: string
}

/** 状态栏项 — 插件向底部状态栏注入的信息条目 */
export interface StatusBarItem {
  /** 唯一标识，如 "editor:cursor" */
  id: string
  /** 标签文本，如 "行" */
  label: string
  /** 值文本，如 "42" */
  value: string
  /** 对齐方向，默认 "left" */
  align?: "left" | "right"
  /** 排序优先级（数字越小越靠前），默认 100 */
  priority?: number
}

/** 命令 — 命令面板中可搜索执行的命令项 */
export interface Command {
  /** 唯一标识，如 "workspace:new-container" */
  id: string
  /** 显示文本 */
  label: string
  /** 图标 — 支持 emoji 字符串（如 "📦"）或 icon-library 的 IconName（如 "package"），渲染层自动识别 */
  icon?: string
  /** 分类，如 "工作区"、"文件"，可选 */
  category?: string
  /** 快捷键提示文本，如 "Ctrl+N"，仅展示不绑定 */
  shortcut?: string
  /** 执行回调 */
  handler: () => void
}

/** 快捷键作用域 — global 始终生效 / container 仅激活容器时生效 */
export type ShortcutScope = "global" | "container"

/** 快捷键绑定 — 声明键盘组合键与处理函数的映射 */
export interface ShortcutBinding {
  /** 唯一标识，如 "file:new" */
  id: string
  /** 按键组合，如 "Ctrl+N"、"Ctrl+Shift+F" */
  keys: string
  /** 描述文本，用于快捷键提示 */
  description?: string
  /** 触发回调 */
  handler: () => void
  /** 命令面板显示文本，设置后在命令面板中可见 */
  label?: string
  /** 命令面板图标 — emoji（如 "📦"）或 IconName（如 "package"），渲染层自动识别 */
  icon?: string
  /** 命令面板分类，设置后在命令面板中可见 */
  category?: string
  /** 作用域 — global 始终生效 / container 仅激活容器时生效。默认 "global" */
  scope?: ShortcutScope
  /** 是否在文本输入框（input/textarea/contentEditable）激活时触发
   *  默认 false：输入框中不拦截浏览器原生行为（如 Ctrl+C 复制文本）
   *  设为 true 时强制拦截（如编辑器的 Ctrl+S 在 textarea 中也要触发保存） */
  activeInInput?: boolean
  /** 关联容器 ID — scope="container" 时必填，否则注册被拒绝
   *  scope="global" 时忽略此字段 */
  containerId?: string
}

/** 右键菜单项 — 插件动态发出 contextmenu:open 时提供的菜单条目 */
export interface ContextMenuItem {
  /** 唯一标识 */
  id: string
  /** 显示文本 */
  label: string
  /** 图标 — emoji（如 "📂"）或 IconName（如 "folder"），渲染层自动识别，可选 */
  icon?: string
  /** 是否禁用（灰显不可点击） */
  disabled?: boolean
  /** 是否为分隔线（label 忽略，渲染一条横线） */
  separator?: boolean
  /** 是否为危险操作（删除等），显示红色文字 */
  danger?: boolean
  /** 子菜单（可选），点击后展开子菜单 */
  children?: ContextMenuItem[]
  /** 快捷键提示文本，如 "Ctrl+C"，显示在 label 右侧 */
  shortcut?: string
  /** 点击回调（关闭菜单并执行动作） */
  onClick?: () => void
}

/** 菜单组 — 插件声明向顶部菜单栏贡献的一组菜单项 */
export interface MenuItemGroup {
  /** 唯一标识，如 "file-explorer:file" */
  id: string
  /** 菜单按钮文字，如 "文件" */
  label: string
  /** 关联容器 ID — 仅该容器活跃时显示此菜单组；不设则始终可见 */
  containerId?: string
  /** 菜单项列表 */
  items: ContextMenuItem[]
}

/** 插件布局提示 — 声明本插件对容器的空间偏好 */
export interface LayoutHints {
  /** 建议宽度权重（相对于其它容器，如 0.3 = 占 30%），默认 1.0 均分 */
  preferredWeight?: number
  /** 最小宽度（px），默认 180 */
  minWidth?: number
  /** 最大宽度（px），不设则不限制 */
  maxWidth?: number
}

/** 文件新建模板 — 插件声明自己可创建的文件类型 */
export interface FileTemplate {
  /** 扩展名，如 ".md" */
  extension: string
  /** 显示名称，如 "Markdown" */
  name: string
  /** 图标 — emoji（如 "📝"）或 IconName（如 "file-text"），渲染层自动识别 */
  icon: string
  /** 新建文件的默认内容，不设则为空 */
  content?: string
}

/** 插件声明 — 插件的唯一入口 */
export interface PluginManifest {
  /** 插件唯一标识，如 "file-explorer" */
  id: string
  /** 显示名称 */
  name: string
  /** 图标（emoji 或 SVG import） */
  icon?: string
  /** 插件组件 — 纯 CSS 主题插件（声明了 themes）允许缺省；其余插件必填 */
  component?: PluginComponent
  /** 插件会发出的事件列表 */
  emits: string[]
  /** 插件能处理的事件列表 */
  handles: string[]
  /** 布局提示 — 声明本插件对容器的空间偏好 */
  layoutHints?: LayoutHints
  /** 状态栏项 — 本插件向底部状态栏注入的信息条目 */
  statusBarItems?: StatusBarItem[]
  /** 快捷键 — 本插件声明的键盘快捷键 */
  shortcuts?: ShortcutBinding[]
  /** 菜单栏 — 本插件向顶部菜单栏贡献的菜单组 */
  menuItems?: MenuItemGroup[]
  /** 文件模板 — 本插件支持的新建文件类型 */
  templates?: FileTemplate[]
  /** 是否为编辑器插件 — workspace 预加载文件内容并注入 editor 上下文 */
  isEditor?: boolean
  /** 编辑器插件声明的首选文件扩展名，如 [".md", ".markdown"]。
   *  声明后 workspace 会优先将匹配扩展名的文件路由到此编辑器。
   *  不声明则为兜底编辑器，处理所有未匹配的类型。 */
  preferredExtensions?: string[]
  /** 文件图标贡献：扩展名 → icon-library 的图标名（如 { ".srt": "file-text" }）。
   *  仅影响文件列表/搜索结果展示；缺省回退宿主内置映射。 */
  fileIcons?: Record<string, string>
  /** 项目视图插件声明可打开的项目类型（对应 .projmeta.json 的 type 字段），
   *  如 ["gallery"]。用户打开 .proj 目录时，workspace 按 type 路由到声明该类型
   *  的插件，并投递 project:open 事件（载荷含目录路径与解析后的 meta）。
   *  项目视图插件不是 isEditor：不接收文件预加载内容，自行通过 kmgr 读写项目文件。
   *  同一类型有多个插件声明时，首个已激活插件生效。 */
  projectTypes?: string[]
  /** 插件版本号（语义化版本，如 "0.1.0"）— 分发系统使用，运行时不关心 */
  version?: string
  /** 插件描述 — 显示在插件管理面板 */
  description?: string
  /** 插件作者 */
  author?: string
  /** 源码仓库地址 — 分发系统用于检查更新（GitHub 地址可零配置推导更新清单） */
  repository?: string
  /** 自定义更新清单地址（update.json）— 设置后优先于 repository 推导 */
  updateUrl?: string
  /** 最低主程序版本（语义化版本，如 "0.29.0"）— 不满足则跳过加载/拒绝安装 */
  minAppVersion?: string
  /** 声明所需权限，如 ["kmgr:read", "kmgr:write"] — workspace 据此决定是否注入 kmgr 等 API */
  capabilities?: string[]
  /** 主题贡献点 — 纯 CSS 主题插件通过此字段贡献主题，声明后 component 可缺省 */
  themes?: ThemeContribution[]
  /** 容器选项组件 — 在容器标题栏 ⚙️ 入口弹出面板的"常规"Tab 中渲染。
   *  未声明则"常规"Tab 显示占位提示。配置读写由插件自管，框架不感知内容。 */
  optionsComponent?: ComponentType<ContainerOptionsProps>
  /** 样式选项组件 — 显示在"样式"Tab 中，用于外观/排版相关配置。
   *  未声明则不显示"样式"Tab。 */
  styleOptionsComponent?: ComponentType<ContainerOptionsProps>
  /** 帮助内容 — 显示在"关于"Tab 中，Markdown 格式字符串。
   *  用于展示插件使用说明、支持的语法、快捷操作等。 */
  helpContent?: string
}

/** 插件注册 — workspace 注册后返回的完整信息 */
export interface PluginRegistration {
  manifest: PluginManifest
  /** 激活状态 */
  active: boolean
  /** 插件来源 — "builtin" 内置插件（默认），"external" 由 plugin-distribution 加载的外部插件 */
  source?: "builtin" | "external"
}

// ======================== 编辑器暂存片段 ========================

/** 暂存片段类型 — 当前支持纯文本和图片，预留 rich 富文本扩展位 */
export type StagedSnippetType = "text" | "image"

/** 编辑器暂存片段 — 跨编辑器实例共享的复用片段
 *  - 一期：纯文本片段，光标处插入
 *  - 二期：图片片段（base64 dataURL 内嵌 markdown）
 *  - 三期：常用库持久化（用户主动 pin 到 SQLite） */
export interface StagedSnippet {
  /** 唯一标识 — 时间戳 + 随机串，避免同毫秒并发冲突 */
  id: string
  /** 片段类型 */
  type: StagedSnippetType
  /** 显示名称（用户可命名，默认从内容前 30 字符截取） */
  name: string
  /** 浮窗预览文本 — 文本取前 50 字符；图片为缩略图 dataURL */
  preview: string
  /** 实际内容 — 文本原文 / 图片 base64 dataURL（含 mime 前缀） */
  content: string
  /** 图片 MIME 类型（仅 type=image 时有效，如 "image/png"） */
  mime?: string
  /** 字节大小 — 用于显示和大小限制校验 */
  size: number
  /** 创建时间 ISO 字符串 */
  createdAt: string
  /** 是否已加入常用库（持久化到 pluginData） */
  pinned: boolean
  /** 常用库分类 — 用户自定义，便于分组管理 */
  category?: string
}