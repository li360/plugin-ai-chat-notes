import type { PluginRegistration } from "./plugin"

/** 容器槽位 — 定义哪个容器装载哪个插件 */
export interface ContainerSlot {
  /** 容器 ID，对应 ContentArea 中的容器 */
  containerId: string
  /** 容器标题 */
  title: string
  /** 装载的插件 ID，null 表示空容器 */
  pluginId: string | null
}

/** 事件链路 — 定义容器间的通信关联 */
export interface EventLink {
  /** 源容器 ID */
  fromContainer: string
  /** 源事件名 */
  fromEvent: string
  /** 目标容器 ID */
  toContainer: string
  /** 目标事件名 */
  toEvent: string
  /** 匹配条件 — payload 必须满足的键值对（用于文件类型路由等场景） */
  match?: Record<string, string>
  /** 转发前先将目标容器切换到指定插件 */
  toPlugin?: string
}

/** 文件关联 — 文件类型与处理插件的映射，派生自 EventLink */
export interface FileAssociation {
  /** 文件扩展名，如 ".ts" */
  ext: string
  /** 处理该类型的插件 ID 列表（第一个为默认，其余为备选） */
  pluginIds: string[]
  /** 目标容器 ID */
  toContainer: string
}

/** 工作区配置 — 定义初始容器布局和插件关联 */
export interface WorkspaceConfig {
  /** 容器槽位列表 — 包含原生 slot 和还原的锁定动态 slot */
  slots: ContainerSlot[]
  /** 事件链路列表 — 包含原生 link 和还原的锁定动态 link */
  links: EventLink[]
  /** 启动时需还原为锁定状态的动态容器 ID 列表（来自上次持久化的 lockedSlotIds）
   *  这些 containerId 必须存在于 slots 中，且不视为 native（仍可解锁/移除） */
  lockedSlotIds?: string[]
}

/** 工作区状态 — 运行时的工作区快照 */
export interface WorkspaceState {
  /** 当前容器槽位 */
  slots: ContainerSlot[]
  /** 已注册的插件映射 */
  plugins: Map<string, PluginRegistration>
  /** 事件链路 */
  links: EventLink[]
}