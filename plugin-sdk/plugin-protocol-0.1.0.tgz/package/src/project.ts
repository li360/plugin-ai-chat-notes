/**
 * 类型化项目容器（.proj）协议常量
 *
 * 框架与项目视图插件共享这些常量，避免各处硬编码。
 */

/** 项目目录扩展名 — 以该扩展名结尾的目录被视为「项目对象」而非普通文件夹 */
export const PROJ_EXTENSION = ".proj"

/** 项目元数据文件名 — 位于 .proj 目录根部，是项目的唯一真相文件 */
export const PROJ_META_FILENAME = ".projmeta.json"

/** 项目 ID 前缀 — 新建项目时生成，如 proj-a1b2c3d4 */
export const PROJ_ID_PREFIX = "proj-"

/** 当前 .projmeta.json 格式版本 */
export const PROJ_META_VERSION = 1

/**
 * 判断目录名是否为项目目录（.proj 结尾，大小写不敏感）
 *
 * @param name 目录名（不含路径），如 "设计案例.proj"
 * @returns 是项目目录返回 true
 */
export function isProjDirName(name: string): boolean {
  return name.toLowerCase().endsWith(PROJ_EXTENSION)
}

/**
 * 生成新项目 ID — proj- 前缀 + 8 位十六进制随机串
 *
 * @returns 形如 proj-a1b2c3d4 的 ID
 */
export function generateProjectId(): string {
  const hex = () => Math.floor(Math.random() * 0x100000000).toString(16).padStart(8, "0")
  return `${PROJ_ID_PREFIX}${hex()}`
}
