import type { ContextMenuItem } from "./plugin"

/** 事件总线接口 */
export interface EventBus {
  /** 发送事件 */
  emit<T = unknown>(event: string, payload: T): void
  /** 订阅事件，返回取消订阅函数 */
  on<T = unknown>(event: string, handler: (payload: T) => void): () => void
  /** 取消所有订阅 */
  clear(): void
}

/** 核心事件载荷类型 */
export interface CoreEvents {
  /** 文件选择事件 */
  "file:select": { path: string; name: string; ext: string }
  /** 文件打开事件 — workspace 在路由时预加载 content（Tauri 环境）
   *  content 类型：文本文件为 string，二进制文件为 Uint8Array（经分块异步解码）
   *  缺失时（纯前端或读取失败）为 undefined，消费方应自行处理 */
  "file:open": { path: string; name: string; ext: string; content?: string | Uint8Array; isTauri?: boolean }
  /** 项目选择事件 — file-list 在用户点击 .proj 对象时发出，workspace 读取并解析
   *  .projmeta.json 后按 type 路由到对应项目视图插件（path 为 .proj 目录绝对路径） */
  "project:select": { path: string; name: string }
  /** 项目打开事件 — workspace 路由后投递给项目视图插件；meta 为解析后的项目元数据，
   *  类型专属配置段（与 type 同名的顶层键）由插件自行解释 */
  "project:open": { path: string; name: string; meta: import("./plugin").ProjectMeta }
  /** 知识组织筛选事件 — organizer 发出，file-list 消费进入筛选模式
   *  mode="category"/"tag"：按分类/标签筛选文件；mode="clear"：退出筛选恢复目录浏览 */
  "organizer:filter-files": {
    mode: "category" | "tag" | "clear"
    /** 分类或标签 ID（mode="clear" 时省略） */
    id?: number
    /** 分类或标签展示名（用于 file-list 筛选指示器，如"工作"） */
    name?: string
  }
  /** 打开覆盖层 — 由插件发出，OverlayLayer 消费。
   *  mode="modal"（默认）居中弹窗；mode="side" 右侧贴边面板（不遮挡编辑器交互） */
  "overlay:open": { pluginId: string; mode?: "modal" | "side" }
  /** 关闭覆盖层 — 由插件发出，OverlayLayer 消费 */
  "overlay:close": null
  /** 容器插件切换通知 — 由 workspace 发出 */
  "workspace:slot:changed": { containerId: string; pluginId: string | null }
  /** 状态栏更新 — 由插件发出，动态更新状态栏项的值 */
  "statusbar:update": { id: string; value: string }
  /** 请求宿主打开 URL；宿主校验 http/https，external=系统浏览器，embedded=内嵌浏览器 */
  "browser:open": { url: string; mode?: "external" | "embedded" }
  /** 右键菜单 — 由插件发出，ContextMenuLayer 消费并渲染 */
  "contextmenu:open": { items: ContextMenuItem[]; x: number; y: number }
  /** 菜单项状态更新 — 由插件发出，workspace 消费，动态 patch 菜单项的 disabled/label/shortcut */
  "menu:update": { groupId: string; itemId: string; patch: { disabled?: boolean; label?: string; shortcut?: string } }
  /** 菜单状态已变更 — 由 workspace 发出，通知 UI 重渲染 */
  "menu:changed": null
  /** 确认弹窗 — 由插件发出，DialogLayer 消费并渲染模态框 */
  "dialog:open": {
    type: "confirm" | "alert"
    title: string
    message: string
    confirmLabel?: string
    cancelLabel?: string
    variant?: "default" | "danger"
    onResult: (confirmed: boolean) => void
  }
  /** 日志条目 — 由 workspace.logger 发出，供日志面板消费 */
  "log:entry": import("./plugin").LogEntry
  /** 编辑器实时状态 — 编辑器组件发布，AI 面板等消费；不写入 emit/handles 清单 */
  "editor:live-changed": import("./plugin").EditorLiveState
  /** AI 改写应用 — 面板发出，编辑器执行替换；original 用于校验内容未漂移 */
  "ai:rewrite-apply": {
    requestId: string
    path: string
    start: number
    end: number
    original: string
    text: string
  }
  /** 编辑器确认替换完成 */
  "ai:rewrite-applied": { requestId: string; path: string }
  /** 编辑器拒绝替换（内容已变化 / 找不到文件） */
  "ai:rewrite-failed": { requestId: string; reason: string }
}

/** 创建事件总线实例 */
export function createEventBus(): EventBus {
  const listeners = new Map<string, Set<Function>>()

  function emit<T = unknown>(event: string, payload: T): void {
    const handlers = listeners.get(event)
    if (!handlers) return
    handlers.forEach((fn) => {
      try {
        fn(payload)
      } catch (err) {
        console.error(`[EventBus] 事件 "${event}" 的处理器抛出异常:`, err)
      }
    })
  }

  function on<T = unknown>(event: string, handler: (payload: T) => void): () => void {
    if (!listeners.has(event)) {
      listeners.set(event, new Set())
    }
    listeners.get(event)!.add(handler)
    return () => {
      listeners.get(event)?.delete(handler)
    }
  }

  function clear(): void {
    listeners.clear()
  }

  return { emit, on, clear }
}